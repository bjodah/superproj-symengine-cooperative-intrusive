# 15 — Investigation Plan: Nanobind Shutdown Leaks Across SymEngine Layers

This plan is for a junior engineer to methodically investigate the remaining process-exit leak warnings seen after the compat suite completes.

It is an investigation plan, not a fix design. The first goal is to localize the leak precisely enough that a later implementation plan can be small and evidence-based.

---

## 1. Problem Statement

Current observed symptom from:

```bash
pytest -q nbsymengine_compat/tests
```

on 2026-06-12:

* tests pass
* Python exits with nanobind leak warnings

Typical warning shape:

* leaked instances of `nbsymengine._core.Basic`
* leaked instances of `nbsymengine._core.Integer`
* leaked types such as `nbsymengine._core.Basic`, `nbsymengine._core.Integer`, `nbsymengine._core.Number`
* leaked bound functions such as `__add__`, `__mul__`, `__hash__`, `get_args`, `is_zero`

This strongly suggests an ownership / shutdown-order issue in or near the nanobind binding layer, but the root cause may still be influenced by:

* `symengine` C++ ownership rules
* `nbsymengine` nanobind holder/type registration
* `nbsymengine_compat` Python wrapper caches and module globals

---

## 2. Success Criteria

The investigation is complete when all of the following are true:

1. we can reproduce the leak with a minimal script smaller than the full compat test suite
2. we know which layer first introduces the leak:
   * `symengine`
   * `nbsymengine`
   * `nbsymengine_compat`
   * or an interaction between them
3. we know whether the leak is:
   * instance-only
   * type/function registration-only
   * or both
4. we have at least one high-confidence root-cause hypothesis supported by experiments
5. we can name the file(s) most likely needing code changes

Do **not** jump to a fix before reaching that point.

---

## 3. Working Assumption

Treat the current leak warning as a real bug until proven otherwise.

Do **not** assume:

* “nanobind always leaks a little”
* “this is only a compat-layer problem”
* “the leaked function/type objects are harmless noise”

Those assumptions will cause false conclusions.

---

## 4. High-Level Strategy

Work in this order:

1. reproduce the leak in the smallest possible subprocess
2. separate `nbsymengine` core leaks from `nbsymengine_compat` wrapper leaks
3. determine whether importing the module is enough, or object creation is required
4. determine whether specific object families trigger the leak:
   * `Basic`
   * `Integer`
   * singleton constants
   * matrices
   * sets
5. inspect ownership and global caches only after the reproduction is minimized

This order matters. If you inspect C++ too early, you will waste time.

---

## 5. Hypothesis Matrix

Keep multiple hypotheses alive until the experiments rule them out.

### H1. Pure nanobind type-registration shutdown bug in `nbsymengine`

Possibility:

* binding code registers types/functions in a way that leaves strong references alive at interpreter teardown

What would support H1:

* importing `nbsymengine._core` alone triggers leaked types/functions
* the same leak appears without `nbsymengine_compat`
* the leak reproduces in the minimal/manual extension harness too

Likely files:

* `nbsymengine/src/core_module.cpp`
* shared nanobind support headers/helpers

### H2. Leaked `Basic` / `Integer` instances are kept alive by Python globals or caches in `nbsymengine_compat`

Possibility:

* wrapper caches, singleton objects, module constants, or metaclass machinery hold objects until shutdown

What would support H2:

* `nbsymengine._core` alone is clean
* importing `nbsymengine_compat.symengine_py_compat` causes the leak
* deleting wrapper caches or module globals before process exit changes the warning

Likely files:

* `nbsymengine_compat/src/nbsymengine_compat/_wrappers.py`
* `nbsymengine_compat/src/nbsymengine_compat/_constants.py`
* `nbsymengine_compat/src/nbsymengine_compat/_matrices.py`

### H3. The leak is caused by singleton/module-constant shutdown order

Possibility:

* globals such as `pi`, `E`, `true`, `false`, `S.EmptySet`, or caches survive into interpreter teardown and keep nanobind objects alive while type cleanup is already running

What would support H3:

* a script that only imports the module leaks
* manually clearing module globals before exit reduces or removes the leak
* the leaked instance types correspond to module-level constants

Likely files:

* `nbsymengine_compat/src/nbsymengine_compat/_constants.py`
* `nbsymengine_compat/src/nbsymengine_compat/_wrappers.py`

### H4. The leak is in `symengine`/`nb_intrusive` ownership semantics, surfaced by nanobind

Possibility:

* the holder type for `RCP<const Basic>` does not release exactly once at shutdown
* reference counts stay non-zero because the C++ ownership graph or singleton lifetime is wrong

What would support H4:

* the same leak appears in minimal `nbsymengine` tests that bypass compat entirely
* leaked instances persist even after Python references are explicitly cleared and `gc.collect()` is forced
* refcount instrumentation in C++ shows an extra retained `RCP`

Likely files:

* `symengine` intrusive/refcount code
* `symengine` singleton/object-lifetime code
* `nbsymengine` holder binding glue

### H5. Cross-module interaction between `nbsymengine` and the compat wrapper is the trigger

Possibility:

* neither layer leaks badly in isolation, but wrapper caching plus nanobind type/object registration leaks when both are used

What would support H5:

* `nbsymengine._core` import alone is cleaner than `nbsymengine_compat`
* using raw `_core` objects directly is cleaner than wrapped compat objects
* the leak size changes materially when compat wrapping is exercised

---

## 6. Reproduction Ladder

Always run reproductions in a fresh subprocess. Shutdown leaks are process-lifetime bugs.

Create a temporary notebook or scratch file if needed, but prefer one-shot commands first.

### Step 1. Import-only probes

Run these as separate subprocesses and record stderr exactly.

```bash
python -c 'import nbsymengine._core'
python -c 'from nbsymengine import _core; _core.integer(1)'
python -c 'import nbsymengine_compat.symengine_py_compat'
python -c 'from nbsymengine_compat.symengine_py_compat import Integer; Integer(1)'
```

Interpretation:

* if import-only already leaks, suspect module globals / type registration
* if object creation is required, suspect instance lifetime or caches

### Step 2. Object-family probes

Test one family at a time:

```bash
python -c 'from nbsymengine_compat.symengine_py_compat import Symbol; Symbol("x")'
python -c 'from nbsymengine_compat.symengine_py_compat import Integer; Integer(1)'
python -c 'from nbsymengine_compat.symengine_py_compat import EmptySet; EmptySet()'
python -c 'from nbsymengine_compat.symengine_py_compat import DenseMatrix; DenseMatrix([[1]])'
python -c 'from nbsymengine_compat.symengine_py_compat import Interval; Interval(0, 1)'
```

Goal:

* identify the smallest constructor that triggers the warning

### Step 3. Core-vs-compat comparison

For each trigger found above, compare:

* raw `_core` construction
* compat wrapper construction

Example:

```bash
python -c 'from nbsymengine import _core; _core.integer(1)'
python -c 'from nbsymengine_compat.symengine_py_compat import Integer; Integer(1)'
```

If raw `_core` leaks too, the bug is probably below compat.

### Step 4. Explicit cleanup probes

For the smallest leaking script, add:

```python
import gc
del obj
gc.collect()
```

Then try progressively stronger cleanup:

* clear local containers
* clear wrapper caches
* delete imported module references
* call `gc.collect()` multiple times

If manual cleanup changes the warning, that is a strong clue.

---

## 7. Specific Experiments To Run

### Experiment A. Does `_WRAP_CACHE` matter?

In `nbsymengine_compat/src/nbsymengine_compat/_wrappers.py`, the compat layer keeps a weak-value wrap cache.

Check whether the minimal leak still occurs if the script does:

```python
from nbsymengine_compat import _wrappers
_wrappers._WRAP_CACHE.clear()
```

before exit.

Interpretation:

* if no change, cache is probably not the main cause
* if leak count changes, inspect wrapper caching and object resurrection paths closely

### Experiment B. Do module-level constants matter?

Write a minimal script that imports compat, then explicitly deletes:

* `pi`
* `E`
* `I`
* `true`
* `false`
* `S`

and forces GC.

Interpretation:

* if leak count drops, module globals or singleton wrappers are involved

### Experiment C. Does plain `_core` leak without compat?

Run a focused subprocess test under `nbsymengine/tests` that imports `_core`, creates one integer, and exits.

If that already leaks, stop blaming compat first.

### Experiment D. Compare with the minimal/manual ownership test module

The project already has a smaller ownership test module on the `nbsymengine` side. Use it as a control.

Questions:

* does the minimal test module leak the same type/function objects?
* does it leak instances too?
* is the warning smaller than the full `_core` module warning?

Interpretation:

* if the minimal module also leaks, the bug is likely near shared holder/type-registration code

### Experiment E. Does one specific singleton trigger the leak?

Test:

```bash
python -c 'from nbsymengine_compat.symengine_py_compat import S; S.EmptySet'
python -c 'from nbsymengine_compat.symengine_py_compat import S; S.One'
python -c 'from nbsymengine_compat.symengine_py_compat import S; S.Pi'
```

Interpretation:

* if one singleton family is disproportionately bad, inspect how that singleton is created and cached

### Experiment F. Does SymPy bridging change the result?

Some compat paths cross through SymPy.

Test two scripts:

* one using only native integer/symbol constructors
* one using `coeff`, `_sympy_()`, or SymPy conversion paths

If only SymPy-bridge paths leak, inspect conversion caches and back-conversion wrappers.

---

## 8. C++-Side Inspection Checklist

Only start this after the minimal reproducer is known.

### In `nbsymengine`

Inspect:

* `core_module.cpp`
* holder bindings for `Basic`, `Integer`, `Number`
* nanobind class definitions for singleton-returning functions
* module-global/static objects that may outlive Python teardown

Questions:

* are any `nb::class_` or `nb::handle` objects stored statically?
* are any lambdas capturing Python objects and stored beyond module init?
* are returned singleton objects cached in static C++ state with Python references attached?

### In `symengine`

Inspect:

* `nb_intrusive` holder behavior
* `RCP<const Basic>` conversions
* singleton creation/destruction rules
* any custom deleter / intrusive inc-ref / dec-ref paths

Questions:

* is every Python-owned wrapper paired with exactly one C++ release?
* are singleton `Basic`/`Integer` instances expected to survive until process teardown?
* do those singleton lifetimes interact badly with nanobind leak accounting?

### In `nbsymengine_compat`

Inspect:

* `_WRAP_CACHE`
* module constants
* singleton wrapper creation
* caches in `_constants.py`, `_wrappers.py`, `_matrices.py`

Questions:

* are wrappers kept alive by globals longer than intended?
* do metaclass or singleton helpers create reference cycles?
* do any module-level objects hold raw `_core` instances indirectly?

---

## 9. Instrumentation Suggestions

Use lightweight instrumentation first.

### Python-side instrumentation

Add temporary debug prints or logging for:

* cache sizes at process end
* types of objects still present in caches
* referrers from `gc.get_referrers(...)` for a known leaked wrapper

Useful tools:

* `gc.collect()`
* `gc.get_objects()`
* `gc.get_referrers()`
* `weakref.finalize`

### C++-side instrumentation

If Python-side evidence points downward, temporarily add logging for:

* construction/destruction of wrapped `Basic` / `Integer`
* holder inc-ref / dec-ref operations
* module init / teardown ordering

Keep this instrumentation behind a debug macro or local patch. Do not land noisy logging permanently.

---

## 10. Suggested Directory For Temporary Investigation Assets

If short-lived scripts are needed, keep them easy to delete later.

Recommended temporary locations:

* `nbsymengine/tests/leaks/`
* `nbsymengine_compat/tests/leaks/`
* or a scratch script outside tracked files until the reproducer stabilizes

Once a reproducer is valuable, convert it into a committed subprocess test.

---

## 11. Decision Tree

Use this decision tree to avoid wandering:

1. If `import nbsymengine._core` alone leaks:
   * start with `nbsymengine`
   * then inspect `symengine` holder/refcount code

2. If `_core` alone is clean but `nbsymengine_compat` leaks:
   * inspect compat globals, caches, and singleton wrappers first

3. If both leak, but compat leaks more:
   * there may be a base leak in `nbsymengine` plus extra retention in compat

4. If only specific object families leak:
   * focus on those constructors and their return/caching paths

5. If explicit cleanup removes the leak:
   * focus on Python lifetime/caching, not core holder semantics

6. If explicit cleanup does nothing:
   * focus on nanobind registration/static state or C++ refcount imbalance

---

## 12. Deliverables From The Investigation

The engineer working this plan should produce:

1. a minimal leaking subprocess script
2. a short table of experiments run and observed leak output
3. a conclusion naming the most likely owning layer
4. a shortlist of candidate files/functions to patch
5. a recommendation for the next implementation plan

Do not finish with “needs more investigation” unless every experiment above was actually attempted and recorded.

---

## 13. Immediate Next Step

Start with the four import/object probes in Section 6 and write down the exact stderr for each run.

That will usually eliminate at least half of the hypothesis space in the first hour.
