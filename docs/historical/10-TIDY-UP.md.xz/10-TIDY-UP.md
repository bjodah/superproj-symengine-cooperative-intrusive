# 10 — Tidy Up: Directory Consolidation and Auto-Generation

This plan outlines the consolidation of the `nbsymengine` directory structure to eliminate duplication, reduce nesting complexity, and minimize handwritten code by transitioning the remaining waived math functions to the automatic code generator.

---

## 1. Goal

1. **Minimize Handwritten Code:** Transition the 13 inverse and hyperbolic functions currently in the `WAIVED` set in [test_function_coverage.py](file:///work/nbsymengine/bindings/python_nanobind/tests/test_function_coverage.py) to [simple_functions.json](file:///work/nbsymengine/bindings/python_nanobind/simple_functions.json), allowing `gen_simple_functions.py` to bind them automatically.
2. **Clean up Directory Structure:** Simplify the deep and convoluted nesting inside the `nbsymengine` submodule (currently split into `bindings/python_nanobind/` and `python-bindings/`) into a unified layout.

---

## 2. Directory Consolidation

### Current Structure (77 files/directories)
```
nbsymengine/
├── bindings/
│   └── python_nanobind/
│       ├── CMakeLists.txt              # Build bindings (in-tree entry point)
│       ├── simple_functions.json       # Config for generated math functions
│       ├── gen_simple_functions.py     # Script to generate simple functions
│       ├── generate.py                 # litgen invocation script
│       ├── generate.yaml               # litgen configuration
│       ├── litgen_extensions/          # litgen customization hooks
│       ├── src/                        # C++ module sources (core/manual)
│       ├── support/                    # C++ nanobind/symengine adapter
│       └── tests/                      # RCP & generator tests
└── python-bindings/
    ├── CMakeLists.txt                  # Build bindings (standalone entry point)
    ├── pyproject.toml                  # Python package configuration
    ├── nbsymengine/                    # Python package sources
    └── tests/                          # Python API / compatibility tests
```

### Proposed Consolidated Structure
```
nbsymengine/
├── CMakeLists.txt                      # Unified CMakeLists.txt (handles both in-tree & standalone)
├── pyproject.toml                      # Moved to submodule root
├── README.md                           # Combined project README
├── nbsymengine/                        # Python package sources
│   ├── __init__.py
│   ├── lambdify.py
│   └── py.typed
├── src/                                # C++ extension sources
│   ├── core_module.cpp
│   └── manual_module.cpp
├── support/                            # C++ nanobind/symengine adapter
│   └── nanobind_symengine.h

├── generator/                          # Binding generation tools & configs
│   ├── generate.py
│   ├── generate.yaml
│   ├── gen_simple_functions.py
│   ├── simple_functions.json
│   ├── api_inventory.yaml
│   └── litgen_extensions/
├── scripts/                            # Maintenance & CI scripts
│   ├── check_generated_policy.sh
│   ├── extract_inventory.py
│   └── make_sdist.sh
├── tests/                              # Unified test suite (merged)
│   ├── conftest.py
│   ├── test_boolean_relational.py
│   ├── test_core_bindings.py
│   ├── test_function_coverage.py
│   ├── test_generated_rcp.py
│   ├── test_generated_smoke.py
│   ├── test_import.py
│   ├── test_lambdify_direct.py
│   ├── test_manual_ownership.py
│   ├── test_sets_solve.py
│   ├── test_singleton_leaks.py
│   ├── test_singleton_shutdown.py
│   └── test_threading_stress.py
└── docs/                               # Developer manuals
    ├── BENCHMARKS.md
    ├── GENERATOR.md
    └── ROLLOUT.md
```

---

## 3. Minimizing Handwritten Code

The 13 inverse and hyperbolic functions are currently excluded from binding coverage via the `WAIVED` dictionary in `test_function_coverage.py`. We will move them to `simple_functions.json` to be automatically generated as `unary_basic` functions:

1. **Functions to Transition:** `cot`, `csc`, `sec`, `acot`, `asec`, `acsc`, `coth`, `asinh`, `acosh`, `atanh`, `acoth`, `asech`, `acsch`.
2. **Action in [simple_functions.json](file:///work/nbsymengine/bindings/python_nanobind/simple_functions.json):** Add entries of the form `{"cpp": "cot", "kind": "unary_basic"}`.
3. **Action in [test_function_coverage.py](file:///work/nbsymengine/bindings/python_nanobind/tests/test_function_coverage.py):** Remove these 13 keys from the `WAIVED` dictionary.

---

## 4. Key Restructuring Refactors

### A. Unified CMakeLists.txt
We will merge the in-tree build (`bindings/python_nanobind/CMakeLists.txt`) and the standalone build (`python-bindings/CMakeLists.txt`) into a single root `nbsymengine/CMakeLists.txt`.
- It will check if the `symengine` target exists (`if (TARGET symengine)`).
- **If TARGET symengine (In-Tree):** Run the full build including code generators (`litgen`, simple functions), tests (`add_test`), and test-only modules (`symengine_manual_ext`).
- **If NOT TARGET symengine (Standalone/sdist):** Use pre-generated code files shipped in the sdist, build the bundled `symengine` source with the `nb_intrusive` backend, compile the `_core` module, and define installation targets.

### B. pyproject.toml & Packaging
- Relocate `pyproject.toml` to the root of `nbsymengine/`.
- Update scikit-build settings (`wheel.packages = ["nbsymengine"]`).
- Update relative paths for CMake inputs and source locations.

### C. Build and CI Script Updates
- **Root CMakeLists.txt ([CMakeLists.txt](file:///work/CMakeLists.txt)):**
  Change `add_subdirectory(nbsymengine/bindings/python_nanobind)` to `add_subdirectory(nbsymengine)`.
- **CI Build Script ([.ci/ci-01-build-and-test.sh](file:///work/.ci/ci-01-build-and-test.sh)):**
  Update the paths to test files (e.g. `test_lambdify_direct.py`) and variables referencing `nbsymengine/python-bindings` to `nbsymengine`.
- **`make_sdist.sh` ([make_sdist.sh](file:///work/nbsymengine/bindings/python_nanobind/scripts/make_sdist.sh)):**
  Simplify directory copies because the source repository layout now aligns with the output sdist layout.

---

## 5. Verification Plan

1. **Generator Execution:**
   - Execute the code generator: `python generator/generate.py generator/generate.yaml`.
   - Verify that `generated/symengine_pydef.cpp` and `generated/symengine.pyi` are correctly updated and contain bindings for the 13 new functions.
2. **Build Verification (In-Tree & Standalone):**
   - Perform full in-tree compile via `ninja` and verify that the 13 new functions compile cleanly.
   - Run standalone build via `pip install ./nbsymengine`.
3. **Test Suite Verification:**
   - Run the unified test suite: `pytest nbsymengine/tests`. Ensure all tests pass.
   - Verify that the coverage checks in `test_function_coverage.py` pass with zero failures and that the new functions are successfully exposed on the Python package.
4. **Downstream/CI Checks:**
   - Run the superproject test suite via `ctest`.
   - Run the compatibility tests in `nbsymengine_compat` to ensure no regressions.
