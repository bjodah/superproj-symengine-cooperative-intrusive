# 12 — Plan: Deduplicate Python Binding Implementations in nbsymengine

This plan covers a targeted deduplication of the two hand-written C++ binding entry points in `nbsymengine`:
* [core_module.cpp](file:///work/nbsymengine/src/core_module.cpp) — the main nanobind extension module (`_core`)
* [manual_module.cpp](file:///work/nbsymengine/src/manual_module.cpp) — the minimal ownership-validation module (`symengine_manual_ext`)

The intent is to remove repeated low-level binding scaffolding without accidentally changing Python-visible behavior or destabilizing shutdown/ownership semantics.

---

## 1. Goal

1. **Remove repeated mechanics:** Share the duplicated intrusive nanobind initialization, root `Basic` binding scaffold, and singleton-detach shutdown logic.
2. **Keep behavior explicit:** Any Python-visible behavior change must be intentional, documented, and covered by tests.
3. **Preserve module isolation:** `_core` and `symengine_manual_ext` must still own independent static state and remain safe when imported in the same process.

---

## 2. Critical Review of the Current Draft

The original draft identified the right duplication hotspots, but it was too eager to lock in one concrete implementation. These are the main corrections:

### A. Do not overload `nanobind_symengine.h` with module-lifecycle code
[nanobind_symengine.h](file:///work/nbsymengine/support/nanobind_symengine.h) currently has a narrow role: SymEngine intrusive-ref helpers plus the nanobind `RCP<T>` caster. Pulling module initialization, singleton registration, `atexit` behavior, and extra SymEngine header dependencies into that file would blur responsibilities and make every user of the caster header pay for unrelated includes.

**Adjustment:** Put the deduplicated module-init helpers in a new header dedicated to binding-module scaffolding, for example:
* `nbsymengine/src/module_common.h`, or
* `nbsymengine/support/nanobind_module_common.h`

Either is fine; the important point is to keep caster infrastructure separate from module startup/shutdown logic.

### B. Separate shared mechanics from behavior-bearing API
`nb::intrusive_init(...)` and the singleton detach cleanup are purely mechanical duplication. The `Basic` binding is not: it defines visible Python behavior such as `__repr__`, `__eq__`, and `get_args()`.

The current draft mixed those together and proposed sharing all of them in one step. That is riskier than necessary.

**Adjustment:** Refactor in this order:
1. share intrusive-hook setup
2. share singleton cleanup
3. only then share `Basic` binding once the desired behavior is locked by tests

### C. Do not silently widen behavior under the banner of deduplication
Two visible differences exist today:
* `_core.Basic.__eq__` returns `nb::not_implemented()` for unsupported RHS types
* `symengine_manual_ext.Basic.__eq__` returns `False`
* `_core.Basic` also defines `__repr__`, while `symengine_manual_ext.Basic` currently does not

Aligning these may be the right outcome, but it is a behavior change, not merely a cleanup.

**Adjustment:**
* Standardize `manual_module.cpp` `__eq__` to match `_core` because Python fallback semantics are better there.
* Treat `__repr__` parity as a separate explicit decision. It can be folded into this refactor, but only if tests are added first or updated intentionally.

### D. Keep singleton registration extensible
The two modules currently use different singleton seed lists. `_core` includes additional symbolic constants and booleans not present in `manual_module.cpp`.

The earlier draft assumed one merged superset was automatically correct. That may be true, but the plan should not depend on that assumption.

**Adjustment:** Share the cleanup algorithm and the common seed list, but keep an explicit extension point so each module can append extra singletons if needed. If later verification shows the superset is safe and desirable in both modules, that can be collapsed afterward.

### E. Verification must explicitly cover interpreter shutdown
A refactor around `detach_python()`, `Py_REFCNT`, and `atexit` is not adequately verified by “build and run pytest” alone. Shutdown regressions often only show up in subprocess exit paths.

**Adjustment:** Add a subprocess-based import/materialize/exit smoke test to the verification plan.

---

## 3. Overlap Analysis

These are the duplicated areas worth sharing.

### A. Intrusive Hook Registration
Both modules install the same GIL-guarded intrusive refcount hooks:

```cpp
nb::intrusive_init(
    [](PyObject *o) noexcept {
        if (!Py_IsInitialized()) return;
        nb::gil_scoped_acquire g;
        Py_INCREF(o);
    },
    [](PyObject *o) noexcept {
        if (!Py_IsInitialized()) return;
        nb::gil_scoped_acquire g;
        Py_DECREF(o);
    });
```

### B. Root `Basic` Binding Scaffold
Both modules construct the intrusive `Basic` root class, register the `set_self_py()` ownership bridge, and bind the same small base API (`__str__`, `__hash__`, `get_args()`, plus partially overlapping equality/representation behavior).

### C. Singleton Registry and `atexit` Cleanup
Both modules:
* keep a translation-unit-local `static std::vector<RCP<const Basic>> g_singletons`
* seed that vector once
* register the same shutdown algorithm that calls `detach_python()`, restores enough C++ refs via `inc_ref()`, and drops all Python refs with `Py_DECREF`

This is the highest-value deduplication target because it is long, subtle, and easy to drift out of sync.

---

## 4. Recommended Design

### A. Use a header-only helper, but keep per-module state local
The right shape is still a header-only helper. That avoids introducing another compiled translation unit and preserves the existing property that each extension module gets its own copy of the helper code.

However, the per-module singleton registry must remain local to each binding module:

```cpp
static std::vector<RCP<const Basic>> g_singletons;
```

The shared helper should operate on that registry; it should not own shared global state.

### B. Shared API shape
The helper should stay focused on module scaffolding, not general SymEngine casting support. A reasonable interface is:

```cpp
namespace SymEngine::python::module_common {

inline void initialize_intrusive_hooks();

inline nb::class_<Basic> bind_basic_common(nb::module_ &m);

inline void seed_common_singletons(std::vector<RCP<const Basic>> &out);

inline void register_singleton_cleanup(std::vector<RCP<const Basic>> *singletons);

} // namespace SymEngine::python::module_common
```

Notes:
* `bind_basic_common()` should only bind the behavior intentionally shared by both modules.
* `register_singleton_cleanup()` should take a pointer to the TU-local registry. That makes the captured object identity explicit and avoids hand-wavy reference-lifetime reasoning in the plan.
* `seed_common_singletons()` should populate only the subset both modules clearly need. `_core` can append extras afterward if required.

### C. Shared `Basic` behavior
The common `Basic` binder should include:
* intrusive ownership setup via `nb::intrusive_ptr<Basic>(...)`
* `__str__`
* `__hash__`
* `get_args()`
* `__eq__` with `_core` semantics: return `nb::not_implemented()` for unsupported RHS types

`__repr__` should only be added to the common binder if we intentionally choose parity here. If the goal is minimum-risk deduplication, leaving `__repr__` module-specific is acceptable.

### D. Module-specific extension points
After the common binder returns the `nb::class_<Basic>` object:
* `_core` extends it with `compare`, arithmetic dunders, and any other richer API
* `symengine_manual_ext` keeps only the minimal ownership-validation surface

After `seed_common_singletons()`:
* `_core` may append `I`, `Inf`, `ComplexInf`, `Nan`, `boolTrue`, `boolFalse`, or any future extras if tests show they are needed
* `symengine_manual_ext` can stay with the common subset unless a real use case appears

---

## 5. Concrete Refactoring Steps

### Step 0: Lock the intended behavior with tests
Before deduplicating `Basic`, add or update focused tests in [test_manual_ownership.py](file:///work/nbsymengine/tests/test_manual_ownership.py) and/or [test_core_bindings.py](file:///work/nbsymengine/tests/test_core_bindings.py):

1. Verify unsupported equality operands use Python fallback semantics:
   * `Basic.__eq__(x, object())` returns `NotImplemented`, or
   * an equivalent observable behavior test proves fallback works
2. If `__repr__` parity is part of this refactor, add a test for it first
3. Add a subprocess smoke test that:
   * imports the module(s)
   * materializes several singleton-backed objects
   * exits cleanly with status 0

This prevents the cleanup refactor from “passing tests” while breaking exit-time behavior.

### Step 1: Add a dedicated shared helper header
Create a new header dedicated to binding-module scaffolding, not casting. It should contain:
* the intrusive hook installer
* the common `Basic` binder
* the shared singleton seeding helper
* the shared `atexit` cleanup registration

Keep the long ownership/shutdown explanation comment in this helper so there is one authoritative copy of the algorithm.

### Step 2: Refactor `manual_module.cpp` first
This is the smaller and safer migration target.

1. Keep `static std::vector<RCP<const Basic>> g_singletons;`
2. Replace the local `nb::intrusive_init(...)` block with the shared helper
3. Replace the local `Basic` binding with `auto basic = ...bind_basic_common(m);`
4. Replace the local singleton seeding and `atexit` registration with the shared helper
5. Keep the rest of the module minimal and unchanged

Doing this first validates the shared scaffolding against the simpler module before touching `_core`.

### Step 3: Refactor `core_module.cpp`
After the manual module works:

1. Keep its own TU-local `g_singletons`
2. Switch intrusive-hook setup to the shared helper
3. Build `Basic` via the shared helper, then continue chaining `_core`-specific methods (`compare`, arithmetic dunders, etc.)
4. Seed the common singleton subset, then append any `_core`-specific extras explicitly if still needed
5. Replace the local `atexit` block with the shared cleanup helper

### Step 4: Cleanup comments and drift
After both modules build and tests pass:
* remove duplicated long-form shutdown comments from both `.cpp` files
* leave a short call-site comment pointing back to the shared helper
* ensure the plan/status docs mention any intentional behavior changes, especially around `Basic.__eq__` or `__repr__`

---

## 6. Non-Goals

This refactor should **not** do the following:

* move the shared logic into a new compiled `.cpp` linked into both extension targets
* alter module names or packaging layout
* change generated litgen output or the `#include "symengine_pydef.cpp"` flow
* expand the manual module’s API surface beyond explicitly chosen parity fixes
* redesign ownership semantics; this is a deduplication refactor, not a new ownership model

---

## 7. Verification Plan

### A. Build
Use the existing build directory for `nbsymengine` and rebuild both extension targets:

```bash
cmake --build <existing-nbsymengine-build-dir>
```

### B. Focused native tests
Run the tests most likely to catch regressions in this refactor:

```bash
pytest nbsymengine/tests/test_manual_ownership.py
pytest nbsymengine/tests/test_core_bindings.py
```

### C. Full native suite

```bash
pytest nbsymengine/tests
```

### D. Compatibility suite
Because `nbsymengine_compat` is a downstream consumer of `_core`, run:

```bash
pytest nbsymengine_compat/tests
```

### E. Shutdown smoke test
Run a subprocess-based smoke test that imports the built extension module(s), touches singleton-backed objects, and exits normally. This should be part of automated verification, not just a manual sanity check.

Success criteria:
* both modules still build
* the focused tests pass
* the compat suite does not regress
* subprocess exit is clean, with no shutdown crash or ownership/leak symptom introduced by the refactor
