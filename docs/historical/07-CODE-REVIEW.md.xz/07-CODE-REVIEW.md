# 07 — Code Review: commit `dfe7e0d` (Better Codegen)

**Commit:** `dfe7e0db5254a2b27a59c7341485a013fc8a3f9b` — *"feat: replace hand-written
binding code with codegen from simple_functions.json"* (in submodule `nbsymengine`).
**Reviewer scope:** verifies the commit against the plan in
`docs/plans/06-IMPL-PLAN-BETTER-CODEGEN.md`, checks behavior preservation, build
wiring, and remaining work.

## Verdict

**Approve with follow-ups.** The commit faithfully implements the plan: a single
declarative `simple_functions.json` (57 entries) feeds a stdlib-only renderer
(`gen_simple_functions.py`) that emits the C++ `.inc`; `core_module.cpp` now
`#include`s it in place of ~270 deleted hand-written lines; the `.pyi` stubs are
injected from the same table; and a `type_codes.inc` coverage test is added.

I generated the `.inc` from the committed JSON and compared it against the deleted
hand-written code: **the bindings are functionally equivalent** (same Python names,
arg names, arg order, deref semantics, return types, default args). The coverage
test passes (`4 passed`). Build/policy wiring is preserved (the `.inc` is a build
artifact and is not git-tracked).

The follow-ups below are all minor; none block merge, but **C1** and **D1** should
be fixed before the next release, and a **full build + test run is still owed**
(see "Work left to do").

---

## What was verified

- ✅ Generated C++ for all 4 Phase-1 kinds (`unary_basic`, `binary_basic`,
  `binary_boolean`) and all Phase-3 kinds (`integer_unary`, `integer_binary`,
  `status_optional_unary`, `list_integer_to_basic`) matches the removed code
  function-for-function, including the tricky cases:
  `totient`/`carmichael` (no deref) vs `nextprime` (`*a`); `gcd`/`lcm` (`*a, *b`);
  `powermod` second arg `Number` not `Integer`; `factor` `B1=1.0`;
  `factor_pollard_*` `unsigned`/`10u`/`5u` defaults; `multiplicative_order`/
  `nthroot_mod` (no deref).
- ✅ Functions deliberately left hand-written (one-of-a-kind shapes) are untouched
  and not duplicated: `mod`/`quotient` (zero guards), `crt`, `gcd_ext`,
  `quotient_mod`, `prime_factor_multiplicities`, `integer_nthroot`, `binomial`,
  `fibonacci`/`lucas`, matrix/lambdify, etc.
- ✅ No duplicate registration risk: the relocated functions are removed from
  `core_module.cpp`; the ntheory names remain in `generate.yaml` `fn_exclude` so
  litgen does not re-bind them. (Trig/relational names were never in `fn_exclude`
  — litgen does not bind them anyway — so the Phase-1 set needs no exclusion.)
- ✅ Coverage test parses `type_codes.inc`, skips conditional-build blocks, and
  asserts every curated math-function class is either in the JSON or `WAIVED`
  with a reason. Passes.
- ✅ `.inc` not tracked in git; `generated/.gitignore` (`*`) covers it; the JSON +
  renderer are tracked inputs. sdist script stages both and pre-bakes the `.inc`.

---

## Findings

### C1 — Type-stub fidelity regression *(minor, should fix)*

`stub_lines()` types **every** parameter as `Basic`, ignoring the `arg_types`
field that the C++ renderer honors. The hand-written stubs were more precise.
Concretely, the generated `.pyi` now says:

```python
def factor(n: Basic, B1: Basic = 1.0) -> Basic | None: ...                       # was B1: float
def factor_pollard_pm1_method(n: Basic, B: Basic = 10, retries: Basic = 5) -> ...  # was B/retries: int
def factor_pollard_rho_method(n: Basic, retries: Basic = 5) -> ...                 # was retries: int
```

A type checker will now reject a legitimate `factor(n, B1=2.0)` (float not
assignable to `Basic`), and the `= 1.0`/`= 10` defaults are inconsistent with the
declared `Basic` type. **Fix:** in `stub_lines`, map `arg_types` to Python types
(`double → float`, `unsigned`/`int → int`, `Integer`/`Number`/absent → `Basic`)
— the renderer already carries `arg_types`, so this is a small change mirroring the
C++ side. Add a regression check that the regenerated `.pyi` keeps `float`/`int`
for these three functions.

### D1 — `excluded_names()` is dead code; Phase 2/D not implemented *(minor)*

`gen_simple_functions.excluded_names()` is defined but **never called**.
`generate.py` still reads `fn_exclude` only from `generate.yaml` (lines 398–400),
and the ntheory names (`gcd`, `lcm`, `nextprime`, …) remain hand-listed there.
So the plan's goal of making the JSON the *single* source — including the litgen
exclusion list — is **not** met for the ntheory family: adding such a function
still requires editing `generate.yaml` too. **Fix (pick one):**
(a) wire `fn_excludes += gen_simple_functions.excluded_names(_SIMPLE_ENTRIES)` in
`generate()` and delete the now-redundant names from `generate.yaml`; or
(b) if keeping the yaml authoritative, delete `excluded_names()` so there is no
misleading dead API. Option (a) matches the plan's intent.

### B1 — sdist `.inc` path is computed before the sdist dir reassignment *(minor, fragile)*

`SYMENGINE_NB_SIMPLE_INC` is set (CMakeLists ~line 80) against the **binary**
`generated/` dir, *before* the sdist branch reassigns `SYMENGINE_NB_GENERATED_DIR`
to the **source** `generated/` dir. Consequences in an sdist build:
- the compile uses `…/source/generated/symengine_simple_funcs.inc` (the copy
  `make_sdist.sh` pre-bakes), while
- the unconditional `add_custom_command` regenerates an **unused** copy into the
  binary dir, and `add_dependencies(_core symengine_nb_simple_funcs)` forces that
  decorative regeneration.

It works **only because** `make_sdist.sh` pre-bakes the `.inc`; if that step were
dropped, the build would fail (`#include` not found) even though the custom command
"succeeded". **Fix:** define `SYMENGINE_NB_SIMPLE_INC` *after* the sdist branch (so
it follows `SYMENGINE_NB_GENERATED_DIR`), and choose one strategy — either always
regenerate (drop the pre-bake) or always pre-bake (drop the unconditional command
in the sdist case). Source-checkout builds are unaffected (both paths are the
binary dir there).

### M1 — `_arrow_col` whitespace machinery is pointless and slightly wrong *(cosmetic)*

`_arrow_col()` plus the `polygamma` special-case exist only to reproduce the
original's `->` column alignment in generated C++. It does not even match the
original — `uppergamma`/`lowergamma` come out with one extra leading space before
`->`. Since this is generated code that nobody hand-edits, the alignment effort
buys nothing and adds a per-name special case that will mis-align any future
binary function. **Recommend** deleting `_arrow_col` and emitting a fixed, simple
indentation.

### M2 — coverage test keys on `cpp`, not the normalized `py` *(latent)*

`test_function_coverage._load_json_py_names()` collects `entry["cpp"]`. Every
current entry omits `py` (so `py == cpp`), but the schema allows `py != cpp`; if
someone sets it, the coverage check silently validates the wrong name. **Fix:**
load via `gen_simple_functions.load()` and read the normalized `py`.

### Nits

- `_format_params`/`_format_call_args` take a `deref` argument that is ignored for
  non-`Integer` types; correct, but the branching is subtle — a short comment
  would help.
- Commit message says "57 math functions" for Phase 1; Phase 1 is 37 entries (57
  is the total across Phase 1+3). Cosmetic.
- `GENERATOR.md` was **not** updated: it still documents only the litgen
  regeneration flow and does not mention `simple_functions.json` /
  `gen_simple_functions.py` or how to regenerate the `.inc` by hand. Add a short
  section (the standalone command is
  `python3 gen_simple_functions.py --input simple_functions.json --output generated/symengine_simple_funcs.inc`).

---

## Work left to do

1. **Run a real build + the test suites** (not done in this review — no compile was
   performed). Required gates: a clean source-checkout build of `_core`, an sdist
   build via `scripts/make_sdist.sh` + install, and the existing pytest suites
   (`tests/test_generated_smoke.py`, `tests/test_generated_rcp.py`, and the
   `python-bindings` tests that exercise `sin`, `Eq`, `gcd`, `factor`,
   `prime_factors`, …). The `.inc` is functionally equivalent to the deleted code,
   so this is expected to pass, but it must be confirmed.
2. **Fix C1** (stub types for `factor`/`factor_pollard_*`) — honor `arg_types` in
   `stub_lines`; add a stub regression assertion.
3. **Resolve D1** — either wire `excluded_names()` into `generate.py` and trim
   `generate.yaml`, or delete the dead function. Prefer wiring it (completes the
   plan's single-source-of-truth goal).
4. **Fix B1** — make the sdist `.inc` path/strategy consistent so the build-time
   dependency is real rather than decorative.
5. **Tidy M1/M2 + nits** — drop `_arrow_col`; key the coverage test on `py`;
   update `GENERATOR.md`.

## Optional next step (was Phase 4 opt-in in plan 06)

The `WAIVED` set lists 17 unbound functions that already exist in
`type_codes.inc` (`cot`, `csc`, `sec`, `acot`, `asec`, `acsc`, `coth`, `asinh`,
`acosh`, `atanh`, `acoth`, `asech`, `acsch`, plus `kronecker_delta`,
`levi_civita`, `primepi`, `primorial`). The 13 simple inverse/hyperbolic ones are
now **one-line JSON additions each** (the whole point of this refactor) — add them
with behavioral round-trip tests and remove them from `WAIVED`. `kronecker_delta`,
`levi_civita`, `primepi`, `primorial` need bespoke handling and can stay waived.
</content>
