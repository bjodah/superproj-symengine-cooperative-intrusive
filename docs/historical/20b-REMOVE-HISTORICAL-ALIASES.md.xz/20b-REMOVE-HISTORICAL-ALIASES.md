# 20b - Remove Historical `nb_intrusive` Aliases Report

**Date:** 2026-06-16
**Status:** Completed
**Author:** Antigravity

This report documents the implementation of the plan in [docs/plans/20-REMOVE-HISTORICAL-ALIASES.md](file:///work/docs/plans/20-REMOVE-HISTORICAL-ALIASES.md).

## 1. Summary of Changes

All objectives of the plan have been successfully implemented across the submodules and the super-project:

### Part A — Drop the Deprecated Alias

- **A1. SymEngine CI Matrix (`symengine` submodule):**
  - Updated all 8 matrix entries in [symengine/.github/workflows/ci.yml](file:///work/symengine/.github/workflows/ci.yml) to use `SYMENGINE_RCP_BACKEND: cooperative_intrusive` instead of `nb_intrusive`.
  - Renamed all related comment headers (ASAN, UBSAN, TSAN, install-consume, optional deps, sdist/wheel smoke test) and the step `- name: Test cooperative_intrusive install and consume`.
- **A2. Compat CI (`nbsymengine_compat` submodule):**
  - Updated [nbsymengine_compat/.github/workflows/ci.yml](file:///work/nbsymengine_compat/.github/workflows/ci.yml) around line 32 to configure symengine with `-DSYMENGINE_RCP_BACKEND=cooperative_intrusive`.
- **A3. Super-Project CI Scripts:**
  - Removed legacy `"nb_intrusive"` spelling checks in [/.ci/ci-common.sh](file:///work/.ci/ci-common.sh) (`ci_apply_rcp_choice()`) and [/.ci/ci-02-build-and-test-nbsymengine.sh](file:///work/.ci/ci-02-build-and-test-nbsymengine.sh).
- **A4. Remove the Alias Branch (`symengine` submodule):**
  - Deleted the `elseif (SYMENGINE_RCP_BACKEND STREQUAL "nb_intrusive")` check in [symengine/CMakeLists.txt](file:///work/symengine/CMakeLists.txt), making configuring with `nb_intrusive` fail fast.

### Part B — Name Normalization (Live References)

Updated all live comments, docstrings, and documentation references from `nb_intrusive` / `WITH_SYMENGINE_NB_INTRUSIVE_RCP` to `cooperative_intrusive` / `WITH_SYMENGINE_COOPERATIVE_INTRUSIVE_RCP`:
- **B1.** [symengine/symengine/add.cpp](file:///work/symengine/symengine/add.cpp) comment: Updated macro name in comment to `WITH_SYMENGINE_COOPERATIVE_INTRUSIVE_RCP`.
- **B2.** [symengine/CLAUDE.md](file:///work/symengine/CLAUDE.md): Replaced stale `-DWITH_SYMENGINE_NB_INTRUSIVE_RCP=ON` with `-DSYMENGINE_RCP_BACKEND=cooperative_intrusive`.
- **B3.** [nbsymengine/src/rcp_ownership_test_module.cpp](file:///work/nbsymengine/src/rcp_ownership_test_module.cpp): Replaced `-DSYMENGINE_RCP_BACKEND=nb_intrusive` with `-DSYMENGINE_RCP_BACKEND=cooperative_intrusive`.
- **B4.** [nbsymengine/tests/test_manual_ownership.py](file:///work/nbsymengine/tests/test_manual_ownership.py): Replaced `nb_intrusive mode` with `cooperative_intrusive mode` in docstring.
- **B5.** [nbsymengine/tests/test_threading_stress.py](file:///work/nbsymengine/tests/test_threading_stress.py): Replaced `nb_intrusive backend` with `cooperative_intrusive backend` in docstring.
- **B6.** [nbsymengine_compat/README.md](file:///work/nbsymengine_compat/README.md): Replaced build parameter `-DSYMENGINE_RCP_BACKEND=nb_intrusive` with `-DSYMENGINE_RCP_BACKEND=cooperative_intrusive`.
- **B7.** [benchmarks/LAMBDIFY_RESULTS.md](file:///work/benchmarks/LAMBDIFY_RESULTS.md): Replaced `-DSYMENGINE_RCP_BACKEND=nb_intrusive` with `-DSYMENGINE_RCP_BACKEND=cooperative_intrusive`.
- **B8.** [AGENTS.md](file:///work/AGENTS.md) (and its symlink `CLAUDE.md`): Updated the description of the `symengine` submodule to refer to `"cooperative_intrusive" (originally "nb_intrusive")`.
- **Other live updates:**
  - [nbsymengine/docs/ROLLOUT.md](file:///work/nbsymengine/docs/ROLLOUT.md): Updated reference to the old macro `WITH_SYMENGINE_NB_INTRUSIVE_RCP` to `WITH_SYMENGINE_COOPERATIVE_INTRUSIVE_RCP`.

### Predecessor Plan Touch-ups

- Added resolution footnotes in [docs/plans/19-PERL-EXTENSION.md](file:///work/docs/plans/19-PERL-EXTENSION.md) to the deferred items: "`nb_intrusive` name normalization" and "Deprecated alias".

---

## 2. Verification Results

All verification steps outlined in Section 8 of the plan have been successfully executed and passed:

### 2.1 Canonical backend still builds and tests pass (Section 8.1)
Configuring, building, and running tests for the `cooperative_intrusive` backend with Perl XS enabled succeeded:
- **Build/Test command:**
  ```bash
  cmake -S /work -B /tmp/build-rmalias -G Ninja \
    -DBUILD_PERL_XS=ON -DSYMENGINE_RCP_BACKEND=cooperative_intrusive \
    -DBUILD_TESTS=ON -DBUILD_BENCHMARKS=OFF
  cmake --build /tmp/build-rmalias -j8
  ctest --test-dir /tmp/build-rmalias --output-on-failure \
    -R 'perl_symengine|test_cooperative_intrusive_rcp|test_rcp'
  ```
- **Result:** `100% tests passed, 0 tests failed out of 3` (Passed tests: `perl_symengine`, `test_rcp`, and `test_cooperative_intrusive_rcp`).

### 2.2 Old spelling now fails fast (Section 8.2)
Configuring with the old name `nb_intrusive` correctly fails fast with a `FATAL_ERROR`:
- **Result:**
  ```
  CMake Error at symengine/CMakeLists.txt:568 (message):
    SYMENGINE_RCP_BACKEND='nb_intrusive' is invalid; use one of: symengine,
    teuchos, cooperative_intrusive
  ```

### 2.3 Python ownership/threading tests (Section 8.3 & Full CI Suite)
The full CI suite `./.ci/run-ci-steps.sh` was run locally, compiling and testing debug, glibcxxdbg, ASAN, and TSAN configurations:
- **Result:** `=== CI steps completed successfully ===`
  - Core C++ debug/glibcxxdbg builds completed and tests passed.
  - `nbsymengine` tests, `nbsymengine_compat` tests, and Python leak tests all completed successfully.
  - TSAN/ASAN lanes successfully validated `cooperative_intrusive` backend's thread-safety and behavior.

### 2.4 No live references remain (Section 8.4)
- Grepping for `"nb_intrusive"` returns **no live (normative) references**. The
  remaining matches are all intentional per the plan's §3 decision rule:
  - The discoverability parenthetical in [AGENTS.md](file:///work/AGENTS.md)
    (`"cooperative_intrusive" (originally "nb_intrusive")`).
  - This plan [docs/plans/20-REMOVE-HISTORICAL-ALIASES.md](file:///work/docs/plans/20-REMOVE-HISTORICAL-ALIASES.md)
    and this report, which necessarily discuss the old term.
  - **Dated records left untouched by design:** the `Date: 2026-06-08` capture in
    [BENCHMARKS_RESULTS.md](file:///work/BENCHMARKS_RESULTS.md) and the completed
    plans/reports under `docs/plans/{10,12b,15,16,17b,18}`,
    `docs/historical/02`, and `docs/reports/16b`.
- Grepping for `"WITH_SYMENGINE_NB_INTRUSIVE_RCP"` yields **0 results** in live
  code/config (only this plan and report mention it descriptively).

---

## 3. Commit Plan / Git Status

All changes have been implemented in their respective branches/repositories and are ready to be committed per the checklist in Section 9:
1. **`symengine`** (branch `rcp-nanobind-2`):
   - A1 + A4 + B1 + B2 (CMake, Github Workflows CI, add.cpp comment, CLAUDE.md)
2. **`nbsymengine`** (branch `main`):
   - B3 + B4 + B5 + ROLLOUT.md (rcp_ownership_test_module.cpp comment, test docstrings, ROLLOUT.md)
3. **`nbsymengine_compat`** (branch `main`):
   - A2 + B6 (Github Workflows CI, README.md)
4. **Super-project** (`/work`, branch `main`):
   - A3 + B7 + B8 + Plan 19 touch-ups + Plan 20 + this report + submodule pointer bumps.
