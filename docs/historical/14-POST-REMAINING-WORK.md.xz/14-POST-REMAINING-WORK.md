# 14 — Post Remaining Work Review

**Date:** 2026-06-12  
**Scope:** Review the implementation claimed in `docs/plans/13-REMAINING-WORK.md`, fix any remaining non-leak issues, and decide whether follow-up belongs under `docs/plans/` or `docs/reports/`.

## Outcome

The consultant's work was mostly correct: the reported failure set is gone and the compat suite is now green apart from the existing nanobind shutdown leak warnings.

After review, only **minor** non-leak issues remained. Those are now fixed, so this document is a **report**, not a new implementation plan.

Current compat baseline:

```bash
pytest -q nbsymengine_compat/tests
```

Result on 2026-06-12:

* **295 passed**
* **4 skipped**
* **107 xfailed**
* **nanobind leak warnings still emitted at process exit**

---

## What The Consultant Got Right

The main body of the implementation matches the spirit of `13-REMAINING-WORK.md`:

* the original 20 real test failures are resolved
* matrix wrapper/raw boundary handling is substantially improved
* container-returning ntheory helpers now wrap nested results
* `init_printing()` toggle semantics are restored and test state is reset
* `Basic.coeff(...)` exists again at the compat layer
* `ImageSet(...)` accepts scalar compat inputs
* a subprocess-based leak regression target was added

The consultant's reported headline improvement was real.

---

## Mistakes Found In Review

### 1. Lowercase set factory exports were still raw `_core` callables

The consultant fixed the class constructors (`FiniteSet`, `Interval`, `ConditionSet`, `ImageSet`) but left the lowercase public exports as direct aliases to nanobind functions:

* `finiteset`
* `interval`
* `conditionset`
* `imageset`
* `set_union`
* `set_intersection`
* `set_complement`
* and the zero-arg set singletons such as `reals`, `integers`, etc.

Because `nbsymengine_compat/symengine_py_compat.py` re-exports everything from `_wrappers.py`, this meant the public shim still had broken entry points that bypassed compat coercion.

Concrete failure reproduced during review:

```python
from nbsymengine_compat.symengine_py_compat import imageset, Symbol, Interval
x = Symbol("x")
imageset(x, 1, Interval(0, 1))
```

This raised a nanobind argument-conversion `TypeError` instead of behaving like the legacy shim.

### 2. The new generic matrix delegation path duplicated a weaker wrapper helper

`DenseMatrixWrapper.__getattr__` introduced a local recursive wrapper that handled only:

* `list`
* `tuple`
* `dict` values

It did **not** match the shared `_wrap_nested(...)` behavior added in `_wrappers.py`, which also handles:

* `set`
* `frozenset`
* wrapped dict keys

That inconsistency could have allowed raw `_core` objects to escape again through generic matrix method delegation.

### 3. “All 7 phases implemented” overstated completion

The implementation did cover the functional test failures, but the acceptance criteria in `13-REMAINING-WORK.md` also required leak-free shutdown. That is still open.

The added subprocess leak test is useful, but it is currently `xfail`, so it records the known problem rather than resolving it.

---

## Fixes Applied During Review

The following minor fixes were applied immediately:

### A. Route lowercase set factories through compat wrappers

The public lowercase exports in `nbsymengine_compat/src/nbsymengine_compat/_wrappers.py` now call compat-aware constructors/functions instead of raw `_core` callables.

This restores coercion/wrapping behavior for:

* scalar inputs
* wrapped compat objects
* returned set values

### B. Reuse the shared `_wrap_nested(...)` helper in matrix delegation

`nbsymengine_compat/src/nbsymengine_compat/_matrices.py` now reuses the central recursive wrapper helper instead of maintaining a narrower local copy.

### C. Add a regression test for the lowercase set factory path

A new legacy-shim test now covers the exact public API path that was still broken:

* `interval(...)`
* `finiteset(...)`
* `set_union(...)`
* `set_intersection(...)`
* `set_complement(...)`
* `conditionset(...)`
* `imageset(...)`

---

## Files Changed During Review

* `nbsymengine_compat/src/nbsymengine_compat/_wrappers.py`
* `nbsymengine_compat/src/nbsymengine_compat/_matrices.py`
* `nbsymengine_compat/tests/test_legacy_shim.py`

---

## Verification

Verified after the review fixes:

```bash
pytest -q nbsymengine_compat/tests
```

Observed result:

* **295 passed**
* **4 skipped**
* **107 xfailed**

The only remaining top-level defect observed in this scope is the nanobind shutdown leak warning:

* leaked instances of `_core.Basic` / `_core.Integer`
* leaked type objects for `_core.Basic` / `_core.Integer` / `_core.Number`
* leaked bound nanobind functions at interpreter shutdown

---

## Conclusion

No substantial non-leak implementation backlog remains from `13-REMAINING-WORK.md`.

The remaining work is now concentrated in shutdown/refcount diagnostics across:

* `symengine`
* `nbsymengine`
* `nbsymengine_compat`

That follow-up is tracked separately in:

* `docs/plans/15-INVESTIGATION-LEAKS.md`
