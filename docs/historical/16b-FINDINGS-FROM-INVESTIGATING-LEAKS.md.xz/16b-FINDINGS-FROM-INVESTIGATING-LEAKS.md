# 16b — Findings From Investigating the Nanobind Shutdown Leak Warnings

**Date:** 2026-06-12
**Input plan:** `docs/plans/16-INVESTIGATION-PLAN-LEAKS.md` (as revised on the same date, adding hypothesis "H-guard")
**Status:** Investigation complete. Both leak shapes are root-caused with minimal repros, direct instrumentation evidence, and a crash backtrace. No fixes have been landed; all instrumentation was reverted and the baseline was re-verified afterwards.

---

## 1. Executive Summary

There is no reference-counting *arithmetic* bug, no Python/C++ cycle, and no
compat-layer cache problem. There are exactly **two distinct leak shapes**, and
both stem from the same design tension: the intrusive inc/dec hooks in
`nbsymengine/support/nanobind_module_common.h` cannot distinguish *"interpreter
is finalizing but still usable"* from *"interpreter is gone"*.

**Shape 1 — swallowed decrefs during finalization (explains the `sin(x)` repro).**
CPython sets `runtime->initialized = 0` *before* `finalize_modules()` clears
module dicts. When a C++ expression object is destroyed during that window, its
destructor releases transferred Python references through the intrusive
`dec_ref` hook — whose first line is `if (!Py_IsInitialized()) return;`. The
`Py_DECREF` is silently swallowed, the child wrapper's refcount is stranded
above zero, and nanobind's `Py_AtExit` leak check reports it. Proven by
instrumentation (Section 5).

**Shape 2 — pinned wrappers on un-registered static singletons (explains the
pytest-suite warnings).** Several code paths return the genuine C++ static
singletons `SymEngine::minus_one` and `SymEngine::NegInf`. Attaching a Python
wrapper to a static transfers the static RCP's reference into a `Py_INCREF`,
pinning the wrapper for the life of the process. The atexit singleton-detach
machinery handles the registered `g_singletons` correctly — but `minus_one` and
`NegInf` are **missing from the registry**. They are exactly the 2 instances
(`Integer` + `Basic`) reported after `pytest -q nbsymengine_compat/tests`.
Proven by net-transferred-ref instrumentation (Section 6).

**The guard is load-bearing.** Removing it (matching nanobind's documented hook
bodies) eliminates Shape 1 warnings but converts Shape 2 into a hard
**segfault**: the static's destructor runs after `Py_FinalizeEx`, the unguarded
hook calls `PyGILState_Ensure()` on a dead interpreter, and the process crashes
in `__run_exit_handlers` (backtrace in Section 7).

The previous leading hypothesis ("late top-level reachability") is **refuted**
as an explanation: a merely-bound top-level object is deallocated by dict
clearing before nanobind's check runs, and a plain Python container root
(`keep=[x]`) produces no warning.

---

## 2. Baseline (Phase 1)

All runs on 2026-06-12 against the current build (Python 3.13, Release).

| # | Command (`python -c ...`) | Result |
|---|---|---|
| 1 | `from nbsymengine import _core` | clean |
| 2 | `…; x=_core.integer(1)` | clean |
| 3 | `…; x=_core.symbol("x")` | clean |
| 4 | `…; x=_core.symbol("x"); s=_core.sin(x)` | **leaked 1 instance: `Symbol`** (+2 types, +24 functions) |
| 5 | `…; x=…; s=_core.sin(x); del s; del x` | clean |
| 6 | manual ext: `x=symbol; s=add(x,1); p=pow(s,2)` | **leaked 4 instances: `Symbol`, `Add`, 2×`Integer` — no `Pow`** |
| 7 | manual ext, same + `del p; del s; del x` | clean |

```
pytest -q nbsymengine_compat/tests   # 295 passed, 4 skipped, 107 xfailed
nanobind: leaked 2 instances!
 - leaked instance … of type "nbsymengine._core.Integer"
 - leaked instance … of type "nbsymengine._core.Basic"
nanobind: leaked 3 types!     (Basic, Number, Integer)
nanobind: leaked 30 functions!
```

Already at baseline, two census details contradict H-late and match H-guard:

* row 4 leaks the **child** (`Symbol`), not the still-bound expression (`Sin`);
* row 6 leaks everything the bound objects *referenced*, but not `Pow` itself.

---

## 3. Discriminating Behavioral Matrix (Phases 2–3, Experiments 9–10)

Every prediction of H-guard from the revised plan held, with zero exceptions:

| Case | Prediction (H-guard) | Observed |
|---|---|---|
| `x=symbol("x"); keep=[x]; del x` | clean (pure Python root, no hook) | **clean** |
| `x=…; s=sin(x); del x` | 1 `Symbol` (name not needed) | **1 Symbol** |
| `x=…; s=sin(x); del s` | clean (Sin destroyed while alive) | **clean** |
| `x=…; s=sin(x); keep=[s]; del s; del x` | 1 `Symbol` | **1 Symbol** |
| `s=sin(symbol("x"))` (only `s` bound) | 1 `Symbol` | **1 Symbol** |
| `sys.getrefcount(x)` after `s=sin(x)` | 3 (name + transferred ref + arg) | **3**, drops to 2 after `del s` |

`atexit` probe: with `x` and `s` left bound, both names are still present in
`__main__.__dict__` at atexit time, `gc.get_referrers(x)` shows **only** the
module dict — the second reference (refcount 3 vs. one visible referrer) is the
raw `Py_INCREF` transferred from the C++ `Sin`, invisible to the GC.

Manual-module fan-out (`x=symbol; s=add(x,1); p=pow(s,2); del p`): `~Pow` runs
while the interpreter is alive, so its children release cleanly; the still-bound
`Add` then strands *its* children at shutdown → leaked exactly `Symbol` +
`Integer(1)`, no `Add`, no `Pow`. Observed exactly that.

GC facts established along the way:

* `_core` instances are **not GC-tracked** (`gc.is_tracked() == False`,
  invisible to `gc.get_objects()`); no `tp_traverse` exists, and none is needed
  for these two shapes — **no cycle is involved anywhere**.
* `gc.collect()` (×3) plus deleting all test modules does **not** change either
  leak shape, as expected for both mechanisms.

---

## 4. Singleton Machinery Check (Phase 6)

* `z=m.pi(); o=m.one()` (manual ext) — clean. The registered-singleton
  detach at atexit works.
* `z=m.pi(); x=m.symbol("x"); s=m.add(x, m.one())` — leaks **only** the
  `Symbol`. The `one` singleton is detached at Python-atexit (its counter is
  reset to C++-owned mode), so the later `~Add` dec_ref of `one` is a plain
  atomic decrement and never touches Python. Working as designed.

The singleton *mechanism* is sound; the problem in Shape 2 is purely that the
**registry is incomplete** (Section 6).

---

## 5. Shape 1 Proven: the `Py_IsInitialized()` Guard Swallows Decrefs (Phase 6b)

Temporary instrumentation in the dec_ref hook (logging instead of silently
returning when `Py_IsInitialized()==0`), rebuilt for `symengine_manual_ext`:

```
$ PYTHONPATH=/work/build python -c 'import symengine_manual_ext as m; x=m.symbol("x"); s=m.add(x,m.integer(1)); p=m.pow(s,m.integer(2))'
[hook] dec_ref SWALLOWED for wrapper 0x… (Py_IsInitialized()==0, type=symengine_manual_ext.Integer)
[hook] dec_ref SWALLOWED for wrapper 0x… (Py_IsInitialized()==0, type=symengine_manual_ext.Add)
nanobind: leaked 4 instances!  (Integer, Symbol, Add, Integer)
```

Mechanism, fully accounted for:

1. Dict clearing decrefs `p` to 0 → `tp_dealloc` → `~Pow` → dec_ref of its two
   children (`Add`, `Integer(2)`) → **2 swallowed decrefs** → both stranded.
2. The stranded `Add` never deallocates, so its own children (`Symbol`,
   `Integer(1)`) never even receive a dec_ref → **2 transitive leaks**.
3. 2 swallowed + 2 transitive = the 4 reported instances. The clean variant
   (`del` everything) logs **zero** swallowed decrefs.

This also empirically confirms the CPython ordering without reading source:
`Py_IsInitialized()` returns 0 while module dicts are being cleared
(`Py_FinalizeEx`: atexit funcs → `initialized = 0` → `finalize_modules()` →
`Py_AtExit` callbacks → return; C++ static destructors run later, at `exit()`).

The leaked-type/function warnings are downstream of leaked instances: a leaked
instance keeps its type alive, the type keeps its bound functions alive, and
nanobind only *prints* type/function reports when instances actually leaked.

---

## 6. Shape 2 Proven: Unregistered Static Singletons Pin Their Wrappers

The pytest-suite leak (1 `Integer` + 1 `Basic`) persists with the guard
*removed*, so it is not Shape 1. Bisection over the compat suite localized it to
`tests/converted/test_functions.py` (both instances) and
`tests/converted/test_pickling.py` (the `Integer` only), and then to individual
tests: `test_lambertw`, `test_erf`, `test_sign` (Integer); `test_floor`,
`test_ceiling` (Basic).

Temporary instrumentation (a per-wrapper net counter of C++-held transferred
references, queryable while the interpreter is alive) identified the objects
directly after a full test run + module deletion + `gc.collect()`:

```
net=1 refcount=1 type=Integer repr=-1     ← SymEngine::minus_one
net=1 refcount=1 type=Basic   repr=-oo    ← SymEngine::NegInf (Infty is unbound → Basic wrapper)
```

`refcount == net` means the **only** thing keeping each wrapper alive is the
C++ static's transferred reference. All other pinned singletons in the dump
(`0`, `1`, `pi`, `E`, `EulerGamma`, `I`, `oo`, `zoo`, `nan`, `True`, `False`,
set singletons) are in `g_singletons` and get detached at atexit; `minus_one`
and `NegInf` are **not in the registry** (`core_module.cpp` seeds the common 13
plus `I, Inf, ComplexInf, Nan, boolTrue, boolFalse`).

Minimal `_core`-only repros (each leaks even after `del`):

```bash
python -c 'from nbsymengine import _core; s=_core.sign(_core.integer(-7)); del s'           # 1 Integer (= -1)
python -c 'from nbsymengine import _core; v=_core.floor(_core.neg(_core.oo())); del v'      # 1 Basic   (= -oo)
python -c 'from nbsymengine import _core; v=_core.ceiling(_core.neg(_core.oo())); del v'    # 1 Basic   (= -oo)
```

(`neg(oo)` itself returns a *fresh* `Infty`; it is `floor`/`ceiling`/`sign`-style
canonicalization inside SymEngine that returns the genuine statics.)

The "leaked `Basic`" spelling is itself a clue preserved here for the fix work:
`Infty` has no nanobind binding in `_core`, so the wrapper falls back to the
base `Basic` type.

---

## 7. The Guard Is Load-Bearing: Removal Trades Warnings for a Segfault

With the guard removed (hook bodies as in nanobind's intrusive docs):

* Shape 1 disappears entirely — minimal repros and the manual module are clean.
* The compat suite still reports the 2 Shape-2 instances **and then the process
  segfaults** after the leak report (previously masked in pipelines; exit code
  139 confirmed for both pytest and a direct runner):

```
#0 0x…                                  ← crash
#1 PyGILState_Ensure ()
#2 <unguarded dec_ref hook>             (_core.so)
#3 nanobind::intrusive_counter::dec_ref()
#4 <C++ static destructor>              (_core.so; symengine is statically linked)
#5 __run_exit_handlers                  ← *after* Py_FinalizeEx returned
```

The static `RCP` for `minus_one`/`NegInf` is destroyed at process exit, its
counter is still in Python-owned mode (never detached), and the hook touches a
dead interpreter. The guard exists to prevent exactly this; it is just far too
broad, also covering the (safe, GIL-held) `finalize_modules` window.

A separately discovered trigger: merely holding `b = gc.get_objects()` at
top level crashes the unguarded build the same way, while the guarded build is
clean — useful as a future regression probe for any guard rework.

**`Py_IsFinalizing()` cannot replace the guard.** An embedded-interpreter probe
(`Py_Initialize` → `Py_FinalizeEx` → query) shows `Py_IsFinalizing()` remains
**true after finalization completes** (`initialized=0 finalizing=1`), so it
cannot distinguish "during finalize_modules (decref safe)" from "after
Py_FinalizeEx (decref fatal)".

---

## 8. Answers to the Plan's Section-12 Questions

1. **What is still live at shutdown?** Minimal repro: the `Symbol` wrapper.
   Suite: the wrappers of `SymEngine::minus_one` and `SymEngine::NegInf`.
2. **What keeps it live?** Shape 1: a transferred `Py_INCREF` held by a C++
   parent whose releasing `Py_DECREF` was swallowed by the guard during
   `finalize_modules`. Shape 2: the transferred reference of a C++ static RCP.
3. **Intentional or accidental?** Both are accidental retention at the binding
   layer; neither is a test-hygiene issue. (`del`-before-exit only *masks*
   Shape 1 and does nothing for Shape 2.)
4. **Does the manual module match?** Yes — identical mechanism, larger census,
   including the no-`Pow` signature predicted by H-guard.
5. **Any genuine cross-language cycle?** No. Wrappers are not even GC-tracked,
   and every leak is explained by acyclic ownership plus shutdown ordering.
6. **Any gross refcount mismatch?** No. Counting is exact in every experiment
   (swallowed decrefs are accounted one-for-one; `getrefcount` probes match
   predictions).
7. **Is singleton cleanup relevant?** It works correctly for registered
   singletons and is the reason `oo`/`zoo`/`nan`/`I`/`True`/`False` do *not*
   leak. Its registry is incomplete — that incompleteness *is* Shape 2.
8. **Does the guard swallow decrefs during finalize_modules?** Yes — directly
   observed via instrumentation.
9. **What kind of fix?** A shutdown-policy fix in the binding layer plus a
   registry completion. Not `tp_traverse`/`tp_clear`, not an ownership-model
   redesign, not `set_leak_warnings(false)`.

**Does `nb_intrusive` need deeper suspicion?** No. The counter semantics
(`counter.inl`-compatible state machine, ref transfer at `set_self_py`,
identity reuse via `self_py()`) behaved exactly as documented in every
experiment. Suspicion should be confined to the two shutdown-window policies
above.

---

## 9. Recommended Next Steps (in order)

1. **Complete the singleton registry (small, safe, fixes Shape 2 today).**
   Add `SymEngine::minus_one` and `SymEngine::NegInf` to `g_singletons` in
   `core_module.cpp` (and the manual module for parity), then audit
   `symengine/constants.h` for every exported static that any binding path can
   return (`two`, `Catalan`, `GoldenRatio`, rational statics if any). After
   this, `pytest -q nbsymengine_compat/tests` should be warning-free, because
   the suite's leaks are Shape 2 only. Consider also binding `Infty` so a
   future regression reports a precise type name instead of `Basic`.
2. **Replace the `Py_IsInitialized()` guard with a "Python is dead" flag
   (fixes Shape 1 without reintroducing the segfault).** Register a `Py_AtExit`
   callback at module init that flips a static flag; the hooks proceed unless
   the flag is set. `Py_AtExit` callbacks run at the very end of
   `Py_FinalizeEx` — after `finalize_modules` (so ordinary teardown decrefs
   work) and before C++ static destructors (so the post-mortem path stays
   protected). `Py_IsFinalizing()` is *not* a viable alternative (Section 7).
   Validate with: the `sin(x)` repro, the `gc.get_objects()` crash probe, and
   an embedded double-init torture test if sub-interpreter use is ever planned.
3. **Convert the repros into committed subprocess regression tests** and
   un-`xfail` the existing shutdown-leak test once 1–2 land:
   `sign(integer(-7))`, `floor(neg(oo))`, `sin(symbol)` with names left bound,
   and the `gc.get_objects()`-held-at-exit probe (asserting exit code 0).
4. **(Optional, upstream-facing.)** The guard-vs-finalize_modules tension is
   generic to nanobind's intrusive sample hooks; once the Py_AtExit-flag
   pattern is validated here, consider proposing it for nanobind's intrusive
   docs, in line with the super-project goal of keeping the symengine patch
   generic for other refcounted-language bindings.

## 10. Methodological note for future bisections

One false trail is worth recording: pytest `--collect-only -q` prints node IDs
relative to its *rootdir* (`nbsymengine_compat/`), not the invoking CWD. Feeding
those IDs back to pytest from `/work` silently selected **zero tests**, which
made every subset look "clean" and briefly suggested an absurd "all 28 tests
are individually necessary" threshold effect. Always sanity-check that a
bisection's negative arm actually *ran* the tests (e.g. assert on the collected
count) before trusting it.
