#!/usr/bin/env bash
cat <<'PLAN'
18 - Plan: Add ASAN To CI Suite

Date: 2026-06-14
Audience: Superproject maintainer / implementer
Status: Ready for implementation

1. Goal

Add an AddressSanitizer lane to the superproject CI in a way that:

- reuses the existing variant plumbing in `.ci/ci-common.sh`
- uses the dedicated ASAN Python toolchain, not the default `apt-deb` Python
- exercises both the core SymEngine build and the nanobind binding build
- avoids pretending that every default-lane Python test is ready for ASAN today
- keeps the change set small and local to the shell orchestration

2. Facts From The Current Repository

- `.ci/run-ci-steps.sh` currently runs:
  - core `debug`
  - core `glibcxxdbg`
  - `nbsymengine` `debug`
  - `nbsymengine_compat` tests on the debug build
  - `nbsymengine` `glibcxxdbg`
  - leak probe
  - core `tsan`
  - `nbsymengine` `tsan`
- `.ci/ci-common.sh` already has an `asan)` branch in `ci_set_variant_flags`.
- `.ci/ci-01-build-and-test.sh` already has ASAN-specific `ctest` exclusions.
- `.ci/ci-02-build-and-test-nbsymengine.sh` does not special-case `asan`; today it would treat ASAN like a full non-TSAN Python lane.
- `.ci/ci-03-build-and-test-nbsymengine_compat.sh` installs `nbsymengine_compat[test]`, which currently pulls `scipy`.
- `.ci/ci-04-leak-test.sh` intentionally triggers a leak and therefore should not be reused as an ASAN/LSAN check.

3. Facts From The Current CI Image

These are present in this environment today:

- latest libc++ ASAN sysroot:
  - `/opt-2/libcxx21-asan/`
- latest CPython ASAN install:
  - `/opt-3/cpython-v3.13.13-asan/`

Important detail:

- the ASAN Python install does not provide a generic `bin/python`
- it does provide versioned executables such as:
  - `bin/python3.13`
  - `bin/python3.13d`
  - `bin/pip3.13`
- `python3.13` reports debug ABI metadata:
  - `abiflags=d`
  - `SOABI=cpython-313d-x86_64-linux-gnu`
  - `LDLIBRARY=libpython3.13d.so`

This means the ASAN lane must use explicit discovered executables and must not assume the default-lane layout.

4. Scope Decision

Add a minimal but meaningful ASAN lane now:

- run `ci-01` with `SYMENGINE_VARIANT=asan`
- run `ci-02` with `SYMENGINE_VARIANT=asan`
- skip `ci-03` in the ASAN lane for now
- skip `ci-04` in the ASAN lane permanently unless it is redesigned

Reasoning:

- `ci-01` already has partial ASAN support and is the cheapest place to catch core-library memory bugs
- `ci-02` exercises the nanobind ownership boundary, which is exactly where ASAN is valuable for `nb_intrusive`
- `ci-03` currently depends on `nbsymengine_compat[test]`, which includes `scipy`; that is the wrong dependency cliff for the first ASAN rollout
- `ci-04` is an intentional leak probe and conflicts with a sanitizer lane whose job is to fail on leaks

5. End State

After implementation, the CI matrix should look like this:

- default Python lane:
  - core `debug`
  - core `glibcxxdbg`
  - `nbsymengine` `debug`
  - `nbsymengine_compat` on the debug build
  - `nbsymengine` `glibcxxdbg`
  - leak probe on the debug build
- ASAN Python lane:
  - core `asan`
  - `nbsymengine` `asan`
- TSAN Python lane:
  - core `tsan`
  - `nbsymengine` `tsan`

Recommended execution order inside `.ci/run-ci-steps.sh`:

1. default lane
2. ASAN lane
3. TSAN lane

Reason:

- ASAN failures are usually easier to triage than TSAN failures
- if there is a raw memory bug, it is better to surface that before the more expensive TSAN pass

6. File-By-File Plan

6.1 `.ci/ci-common.sh`

Keep the existing structure and extend it rather than redesigning it.

Changes:

1. Add ASAN Python discovery.

   Prefer discovery over hardcoding, because the current image already uses versioned install roots:

   ```bash
   export CI_ASAN_PYTHON_ROOT="$(compgen -G "/opt*/cpython*-asan/" | sort -rV | head -1 || true)"
   ```

2. Resolve the actual Python and pip executables from that root.

   Use explicit executables. Do not assume `bin/python` exists.

   Recommended logic:

   ```bash
   export CI_ASAN_PYTHON="$(compgen -G "${CI_ASAN_PYTHON_ROOT}/bin/python3.*" \
       | grep -E '/python3\.[0-9]+$' \
       | sort -rV | head -1 || true)"
   export CI_ASAN_PIP="$(compgen -G "${CI_ASAN_PYTHON_ROOT}/bin/pip3.*" \
       | sort -rV | head -1 || true)"
   ```

   Notes:

   - intentionally prefer `python3.13` over `python3.13d`
   - in this image `python3.13` already carries the debug ABI (`SOABI=cpython-313d-...`)
   - using the non-`d` executable avoids baking one specific file naming convention into CI

3. Extend `ci_use_python_toolchain()` with an `asan` target.

   It should export:

   - `CI_PYTHON_ROOT`
   - `CI_PYTHON`
   - `CI_PIP`

4. Extend `ci_ensure_python_toolchain()`.

   If `SYMENGINE_VARIANT=asan`, it should auto-select the `asan` toolchain the same way `tsan` currently selects the TSAN toolchain.

5. Tighten the existing `asan)` compiler and linker flags.

   Recommended direction:

   - keep `clang` / `clang++`
   - keep the external libc++ ASAN sysroot
   - add `-fno-omit-frame-pointer`
   - prefer `-O1 -g` over `-Og` for sanitizer-friendlier codegen
   - keep `-DHAVE_GCC_ABI_DEMANGLE=no`

   Example target shape:

   ```bash
   export CXXFLAGS="-std=c++20 -fsanitize=address -O1 -g -fno-omit-frame-pointer \
     -fno-optimize-sibling-calls -fsized-deallocation \
     -stdlib++-isystem ${LIBCXX_ASAN_ROOT}/include/c++/v1 -ferror-limit=5 -stdlib=libc++"
   export LDFLAGS="-fsanitize=address -Wl,-rpath,${LIBCXX_ASAN_ROOT}/lib \
     -L${LIBCXX_ASAN_ROOT}/lib -lc++ -lc++abi -stdlib=libc++"
   ```

6. Export runtime sanitizer options for the ASAN lane.

   Add a small helper or extend `ci_set_variant_flags()` so that `asan` exports:

   ```bash
   export ASAN_OPTIONS="symbolize=1:detect_leaks=1:check_initialization_order=1"
   ```

   Optional:

   - append `:external_symbolizer_path=$(command -v llvm-symbolizer)` when available
   - do not hardcode `/usr/lib/llvm-12/...`; the image is not on LLVM 12 anymore

7. Keep ASAN failure behavior strict.

   Do not add `|| true`, warning-only branches, or blanket `detect_leaks=0`.

6.2 `.ci/run-ci-steps.sh`

This is where most of the work belongs.

Changes:

1. Resolve the ASAN toolchain roots up front.

   Keep the current libc++ discovery pattern, but make it match the user-provided working form:

   ```bash
   export LIBCXX_ASAN_ROOT="$(compgen -G "/opt*/libcxx*-asan/" | sort -rV | head -1 || true)"
   ```

   That should replace the narrower `libcxx??-asan` glob.

2. Add an ASAN toolchain preparation phase.

   Example shape:

   ```bash
   echo "=== Preparing ASAN Python Lane ==="
   ci_use_python_toolchain asan
   ci_pip install munch srcml_caller libcst nanobind pytest sympy
   ```

   Deliberately do not install `scipy` here.

3. Add the ASAN execution phase between the default lane and the TSAN lane.

   Recommended stages:

   ```bash
   ci_use_python_toolchain asan

   echo "=== 7. Core C++ ASAN build ==="
   env SYMENGINE_VARIANT=asan "${SCRIPT_DIR}/ci-01-build-and-test.sh" /tmp/bld-se-asan /tmp/symen-asan

   echo "=== 8. nbsymengine ASAN build ==="
   env SYMENGINE_VARIANT=asan "${SCRIPT_DIR}/ci-02-build-and-test-nbsymengine.sh" /tmp/bld-nbse-asan
   ```

4. Renumber the existing TSAN stage labels after inserting ASAN.

5. Fail early if the ASAN toolchain is missing in CI.

   Recommended rule:

   - if `CI` is set and either `LIBCXX_ASAN_ROOT` or `CI_ASAN_PYTHON_ROOT` is empty, abort with a clear error
   - if `CI` is not set, it is acceptable to support an opt-out such as `CI_ENABLE_ASAN=no`, but that is optional

   The important part is that real CI must not silently skip the ASAN lane.

6. `.woodpecker.yaml` does not need a functional change for this task.

   It already delegates to `.ci/run-ci-steps.sh`.

6.3 `.ci/ci-01-build-and-test.sh`

This file already has the right broad shape.

Changes:

1. Keep the existing ASAN-specific `ctest` exclusion list unless implementation proves that some exclusions can be removed.

   Current list:

   - `test_bipartite`
   - `test_hopcroft_karp`
   - `test_case004`
   - `test_case006`
   - `test_case007`
   - `test_parser`

2. Make sure the script inherits the ASAN runtime environment from `.ci/ci-common.sh`.

3. Do not add Python-side tests here.

4. Keep the source directory as `symengine/`; this lane is still "core library only".

6.4 `.ci/ci-02-build-and-test-nbsymengine.sh`

This file needs one explicit ASAN policy decision.

Current problem:

- anything except `tsan` is treated as a full Python lane
- that means ASAN would currently try to:
  - editable-install `symengine.py`
  - run `nbsymengine/tests/test_lambdify_direct.py`
  - run `benchmarks/tests/`

That is too much for the first ASAN rollout.

Change the test policy to three branches, not two:

1. `tsan`
   - keep the existing minimal CTest subset
   - keep skipping pytest

2. `asan`
   - run the full nanobind CTest set:

     ```bash
     ctest --output-on-failure -R '^nanobind_'
     ```

   - run one direct Python smoke suite that uses the built extension without requiring the legacy binding:

     ```bash
     PYTHONPATH="${SYMENGINE_BUILD}:${PYTHONPATH:-}" "$CI_PYTHON" -m pytest -x \
       "${SUPERPROJECT_ROOT}/nbsymengine/tests/test_lambdify_direct.py" --tb=short -q
     ```

   - do not editable-install `symengine.py`
   - do not run `benchmarks/tests/`

3. `debug` / `glibcxxdbg`
   - keep the current richer pytest behavior

Reasoning:

- the ASAN lane still exercises the Python/C++ ownership boundary
- it avoids dependency and wheel problems from `scipy`
- it avoids introducing a second compiled extension (`symengine.py`) into the first sanitizer rollout

6.5 `.ci/ci-03-build-and-test-nbsymengine_compat.sh`

No code change is required for the initial ASAN rollout.

Explicitly do not call this script from the ASAN lane yet.

Reason:

- `nbsymengine_compat[test]` currently depends on `scipy`
- the first ASAN goal is to cover the C++ core plus nanobind boundary, not to solve every downstream packaging issue at once

Optional follow-up after the lane is stable:

- split the compat extras into a lighter no-`scipy` test extra
- then evaluate whether an ASAN compat subset is worth the runtime

6.6 `.ci/ci-04-leak-test.sh`

Do not reuse this in the ASAN lane.

Reason:

- the script intentionally leaks
- an ASAN/LSAN lane should treat that as a real failure
- mixing the intentional leak probe into the sanitizer lane would either make the lane fail by design or force disabling leak detection, which defeats the point

Keep `ci-04` on the default debug build only.

7. Concrete Discovery Rules

Use these shell patterns in the implementation:

```bash
LIBCXX_ASAN_ROOT="$(compgen -G "/opt*/libcxx*-asan/" | sort -rV | head -1 || true)"
CI_ASAN_PYTHON_ROOT="$(compgen -G "/opt*/cpython*-asan/" | sort -rV | head -1 || true)"
CI_ASAN_PYTHON="$(compgen -G "${CI_ASAN_PYTHON_ROOT}/bin/python3.*" | grep -E '/python3\.[0-9]+$' | sort -rV | head -1 || true)"
CI_ASAN_PIP="$(compgen -G "${CI_ASAN_PYTHON_ROOT}/bin/pip3.*" | sort -rV | head -1 || true)"
```

Validation checks:

```bash
test -d "${LIBCXX_ASAN_ROOT}"
test -d "${CI_ASAN_PYTHON_ROOT}"
test -x "${CI_ASAN_PYTHON}"
test -x "${CI_ASAN_PIP}"
```

8. Verification Plan

8.1 Script-Level Checks

Run these in order:

```bash
. .ci/ci-common.sh
ci_use_python_toolchain asan
"$CI_PYTHON" -c 'import sys, sysconfig; print(sys.executable); print(sysconfig.get_config_var("SOABI"))'
env SYMENGINE_VARIANT=asan .ci/ci-01-build-and-test.sh /tmp/bld-se-asan /tmp/symen-asan
env SYMENGINE_VARIANT=asan .ci/ci-02-build-and-test-nbsymengine.sh /tmp/bld-nbse-asan
```

Success criteria:

- `ci-01` configures, builds, and runs its restricted ASAN CTest set
- `ci-02` configures, builds, passes `^nanobind_` CTests, and passes `test_lambdify_direct.py`

8.2 Full Orchestrator Check

Then run:

```bash
bash .ci/run-ci-steps.sh
```

Success criteria:

- existing default and TSAN behavior is preserved
- the ASAN lane runs without changing `.woodpecker.yaml`
- any ASAN finding fails the job directly

8.3 Regression Check For Toolchain Selection

Specifically verify:

- default lane still uses `/opt-3/cpython-v3.13-apt-deb/bin/python`
- ASAN lane uses the discovered `cpython-...-asan` executable
- TSAN lane still uses `/opt-3/cpython-v3.14.4-tsan/bin/python3.14`

9. Risks And Mitigations

Risk: Python executable discovery picks `python3.13d` instead of `python3.13`.

Mitigation:

- filter for `/python3.<minor>$` first
- keep a clear failure message if discovery returns empty

Risk: ASAN stack traces are unsymbolized.

Mitigation:

- set `ASAN_OPTIONS=symbolize=1`
- optionally attach `external_symbolizer_path` from `command -v llvm-symbolizer`

Risk: first rollout gets stuck on SciPy or legacy-binding packaging instead of sanitizer findings.

Mitigation:

- skip `ci-03`
- skip `symengine.py` editable-install in `ci-02` for `asan`

Risk: local developers without the ASAN toolchain cannot run the full orchestrator.

Mitigation:

- acceptable in CI
- optional follow-up: add a local opt-out flag, but do not let real CI skip silently

10. Non-Goals

This task should not:

- redesign the full CI matrix
- add UBSAN in the same change
- make `nbsymengine_compat` fully ASAN-ready
- make `symengine.py` build part of the ASAN lane
- relax sanitizer failures into warnings

11. Implementation Order

1. Extend ASAN Python toolchain discovery in `.ci/ci-common.sh`
2. Add `asan` handling to `ci_use_python_toolchain()` and `ci_ensure_python_toolchain()`
3. Tighten ASAN compile/link/runtime flags in `.ci/ci-common.sh`
4. Insert the ASAN preparation and execution stages into `.ci/run-ci-steps.sh`
5. Special-case `asan` test selection in `.ci/ci-02-build-and-test-nbsymengine.sh`
6. Run the script-level verification commands
7. Run the full orchestrator

12. Recommended Follow-Up After The First ASAN Merge

If the initial lane is stable, the next sensible expansion is:

1. split compat test extras so `scipy` is optional
2. evaluate a minimal `ci-03` ASAN subset
3. consider a combined `asan+ubsan` lane only after plain ASAN is clean

PLAN
