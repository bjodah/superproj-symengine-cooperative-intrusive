# 22a - Cross-Runtime Ownership Matrix

This report pairs PHP and Perl coverage by `cooperative_intrusive` backend
invariant so runtime integration failures can be distinguished from core backend
failures.

See also: `docs/plans/22-FURTHER-EXTENSION-IMPROVEMENTS.md`.

| Invariant | PHP coverage | Perl coverage | Gap / action |
| --- | --- | --- | --- |
| Extension loads with cooperative backend | `symengine.php/tests/001-load.phpt` - `Extension loads and reports version` | `symengine.pl/t/00-load.t` - `version is defined` | None |
| Basic expression creation works | `symengine.php/tests/010-basic-ops.phpt` - `Basic operations: integer, symbol, add, sub, div, mul, neg, pow, str, eq` | `symengine.pl/t/01-basic.t` - `symbol stringifies`, `integer stringifies`, `add works`, `mul works`, `pow works`, `neg works`, `sin works` | PHP now covers `sub`, `div`, and `neg`; only `sin` remains intentionally deferred |
| Singleton identity reuse | `symengine.php/tests/020-identity-reuse.phpt` - `Identity reuse: repeated wrapping of same singleton returns same PHP object` | `symengine.pl/t/02-identity.t` - `pi wrappers point at the same C++ singleton`; `symengine.pl/t/04-cooperative.t` - `repeated pi() calls reuse one Perl wrapper` | None for `pi`; PHP already covers `zero`, `one`, and `pi` |
| Canonical expression returns existing wrapper | `symengine.php/tests/025-canonical-identity-reuse.phpt` - `Canonical identity reuse: add(x, 0) returns the existing PHP wrapper` | `symengine.pl/t/04-cooperative.t` - `add(x, 0) yields the same C++ object`, `an already-externalized object reuses its existing Perl wrapper`, `reusing the wrapper takes exactly one more Perl reference`, `dropping the reused wrapper restores the reference count` | Added in PHP; `add(x, 0)` directly mirrors Perl |
| Fresh wrapper externalizes object | `symengine.php/tests/030-external-ownership.phpt` - `External ownership: isExternalOwned true after wrapping; phpRefCount predictable` | `symengine.pl/t/04-cooperative.t` - `a freshly handed-out wrapper is external-owned`, `a freshly handed-out wrapper has a single Perl reference`, `use_count() is 0 in external-owned mode (Perl holds the references)` | None |
| Debug ownership probes expose cooperative state | `symengine.php/tests/035-debug-helpers.phpt` - `Debug ownership helpers expose cooperative state when enabled` | `symengine.pl/t/04-cooperative.t` - `cpp_use_count`, `perl_refcount`, and `is_external_owned` assertions | PHP probes are enabled by `SYMENGINE_PHP_DEBUG_HELPERS`, not PHP's own `NDEBUG` |
| C++ expression pins operand wrapper | `symengine.php/tests/045-expression-pins-operand.phpt` - `Expression ownership: expression-held RCP pins operand wrapper` | `symengine.pl/t/04-cooperative.t` - `the new expression holds a C++ ref that pins the operand wrapper` | Added in PHP via relative `phpRefCount()` assertions |
| Releasing expression releases operand pin | `symengine.php/tests/045-expression-pins-operand.phpt` - `pin released: true` | `symengine.pl/t/04-cooperative.t` - `releasing the expression releases its cooperative reference` | Added in PHP |
| Final release of non-singleton object is safe | `symengine.php/tests/045-expression-pins-operand.phpt` - release path returns to baseline refcount; `symengine.php/tests/065-loop-teardown.phpt` - repeated teardown smoke in child CLI process | `symengine.pl/t/04-cooperative.t` - `final release of an externalized object did not crash` | PHP now has focused release coverage plus looped child-process smoke |
| Shutdown with live singleton wrappers | `symengine.php/tests/050-singleton-teardown.phpt` - `Singleton teardown: subprocess holding live singleton wrappers until exit` using `symengine.php/tests/support/subprocess.php` timeout helper | `symengine.pl/t/05-teardown.t` - `child interpreter tears down cleanly with live singletons (PERL_DESTRUCT_LEVEL=2)` | PHP now has timeout protection; FPM remains separate |
| Shutdown with live composite expressions | `symengine.php/tests/060-expression-teardown.phpt` - `Expression teardown: subprocess holding non-singleton expressions until exit` using `symengine.php/tests/support/subprocess.php` timeout helper; `symengine.php/tests/065-loop-teardown.phpt` - `Loop teardown: repeated expressions and canonical singleton reuse exit cleanly` | `symengine.pl/t/05-teardown.t` - same child teardown covers live ordinary expressions and canonicalized singleton reuse | PHP timeout helper added; loop test adds stress coverage |
| Singleton detach/replay core primitive | `symengine/symengine/tests/rcp/test_cooperative_intrusive_rcp.cpp` - `detach external and replay inline references` | Shared by both runtimes | Core test to be kept as the backend-generic regression target |

## How To Update This Matrix

Every new PHP or Perl ownership test must either add a new row here or update an
existing row with the exact file path and test name it now covers.

Rows that mention runtime shutdown details should stay explicit about the
reconcile point, for example `RSHUTDOWN` in PHP or `call_atexit` during Perl
destruction.
