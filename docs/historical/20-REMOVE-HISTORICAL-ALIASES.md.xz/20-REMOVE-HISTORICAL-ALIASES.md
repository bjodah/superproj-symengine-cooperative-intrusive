# 20 - Remove Historical `nb_intrusive` Aliases

**Date:** 2026-06-16
**Status:** Planned (not started)
**Owner:** (assign)
**Predecessor:** [19-PERL-EXTENSION.md](19-PERL-EXTENSION.md) — see the two bullets
under "Remaining / deferred": *"`nb_intrusive` name normalization"* and
*"Deprecated alias"*.

---

## 1. Goal

The cooperative reference-counting backend used to be called `nb_intrusive`
(short for "nanobind intrusive"). It was generalized and renamed to
`cooperative_intrusive` so it could serve non-nanobind runtimes (e.g. the Perl
XS extension). Two clean-up tasks were deferred when the rename landed:

1. **Name normalization.** Some *live* (still-authoritative) docs, comments, and
   docstrings continue to use the old `nb_intrusive` spelling. Normalize them to
   `cooperative_intrusive`.
2. **Drop the deprecated alias.** `symengine/CMakeLists.txt` still accepts
   `SYMENGINE_RCP_BACKEND=nb_intrusive` (it warns and maps it to
   `cooperative_intrusive`). Remove the alias and migrate every caller that still
   passes the old value, so the only accepted spelling is the canonical one.

When this plan is complete:

- No live config/script/doc/code passes or accepts `nb_intrusive`.
- `cmake -DSYMENGINE_RCP_BACKEND=nb_intrusive` fails fast with the standard
  "invalid backend" `FATAL_ERROR`.
- Dated historical records keep their original wording (see §3).

---

## 2. Required background for the junior engineer

### 2.1 This is a super-project of git submodules

`/work` is a super-project. The directories `symengine/`, `nbsymengine/`,
`nbsymengine_compat/`, and `symengine.py/` are **git submodules** — each is its
own repository with its own history and its own branch. The super-project only
records a commit SHA ("pointer") for each.

Practical consequences you must internalize before editing:

- A change inside `symengine/…` is a commit **in the symengine repo**, not in the
  super-project. After committing inside the submodule, the super-project shows
  the submodule as "modified (new commits)"; you then stage the submodule and
  commit the **pointer bump** in the super-project.
- Files that live directly under `/work` (e.g. `/work/.ci/*`, `/work/AGENTS.md`,
  `/work/benchmarks/*`, `/work/docs/*`) are part of the **super-project** repo
  and are committed normally there.
- Confirm each submodule is on a branch (not detached) before committing:
  `git -C <submodule> status -sb`. As of this writing `symengine` is on
  `rcp-nanobind-2`, `nbsymengine` and `nbsymengine_compat` are on `main`.

Per the project charter (`/work/AGENTS.md`): **keep the patch to the upstream
`symengine` repo as small and generic as possible.** The symengine edits in this
plan are intentionally minimal — a few comment/doc lines, one CMake branch
removal, and the symengine CI matrix that validates that CMake. Do not expand the
symengine diff beyond what §4 lists.

### 2.2 Scope — what is and is **not** `nb_intrusive`

Be precise. The string `nb`/`NB` appears in two unrelated contexts:

- **`nb_intrusive`** = the old name of the RCP backend. **In scope.**
- **`NB_*` / `nb_*` = nanobind**, e.g. `BUILD_PYTHON_NANOBIND`,
  `NB_INSTALL_CONSUME`, `NB_SDIST_SMOKE`, `SYMENGINE_NB_OPTIONAL_DEPS`,
  `bin/test_nb_install_consume.sh`. These refer to *nanobind*, not to the
  backend. **Out of scope — do not rename them.** Touching them is a separate,
  unwanted refactor.

When you edit a CI step *name* or *comment* that currently reads
"nb_intrusive …" you are changing the backend reference (in scope). Leave any
adjacent `NB_INSTALL_CONSUME` / `test_nb_install_consume.sh` tokens alone.

---

## 3. Decision rule: normalize vs. leave as a dated record

Apply this rule per occurrence:

- **Normalize** if the text is *normative / forward-looking* — something a reader
  is expected to act on today: build instructions, "how to reproduce" sections,
  code comments that name a macro, test docstrings describing current behavior,
  the project description in `AGENTS.md`, CMake, CI matrices, and shell scripts.
- **Leave unchanged** if the text is a *dated record of a past event* — completed
  plans, investigation reports, historical design docs, and benchmark result
  captures that state the exact flags used at a fixed date. Rewriting these would
  falsify the record.

Concretely, **leave alone**:

- Everything under `docs/plans/`, `docs/reports/`, `docs/historical/` **except
  this file**. (Predecessor plan 19 may get a one-line status note — see §6.)
- `/work/BENCHMARKS_RESULTS.md` — it is dated (`Date: 2026-06-08`) and records the
  literal flags of that run.

Everything in the §4 / §5 inventories below is normative and gets changed.

---

## 4. Part A — Drop the deprecated alias

> **Ordering matters.** Removing the alias turns any lingering
> `nb_intrusive` value into a hard `FATAL_ERROR`. Migrate **all callers first**,
> then remove the alias, then remove the script-level acceptance. Do the steps in
> the order below.

### A1. Migrate the symengine CI matrix (symengine submodule)

File: `symengine/.github/workflows/ci.yml`

Change every matrix entry value from:

```yaml
            SYMENGINE_RCP_BACKEND: nb_intrusive
```
to:
```yaml
            SYMENGINE_RCP_BACKEND: cooperative_intrusive
```

There are 8 such entries (around lines 225, 233, 244, 251, 258, 273, 280, 288).
Use a review-then-replace, not a blind global sed, because the surrounding
comments and one step name also mention the backend:

- Comment headers like `# nb_intrusive backend (Release, …)`,
  `# nb_intrusive ASAN`, `# nb_intrusive UBSAN`, `# nb_intrusive TSAN`,
  `# nb_intrusive install-consume test`, `# nb_intrusive with optional deps`,
  `# nb_intrusive sdist/wheel smoke test` → replace `nb_intrusive` with
  `cooperative_intrusive`.
- Step name (around line 417): `- name: Test nb_intrusive install and consume`
  → `- name: Test cooperative_intrusive install and consume`.

**Do not touch** `NB_INSTALL_CONSUME`, `NB_SDIST_SMOKE`,
`SYMENGINE_NB_OPTIONAL_DEPS`, `BUILD_PYTHON_NANOBIND`, or
`bin/test_nb_install_consume.sh` (those are nanobind — §2.2). The
`${{ matrix.SYMENGINE_RCP_BACKEND }}` reference at line ~365 and the `OPTIONS`
label at line ~370 need no edit; they read whatever value the matrix supplies.

After editing, sanity-check that nothing in `symengine/` still passes the old
value:
```bash
grep -rn "nb_intrusive" symengine/.github/ symengine/bin/
```
(`bin/` should already be clean — it branches on `cooperative_intrusive`.)

### A2. Migrate the compat CI (nbsymengine_compat submodule)

File: `nbsymengine_compat/.github/workflows/ci.yml` (around line 32)

```diff
           cmake -S . -B build \
             -DBUILD_PYTHON_NANOBIND=ON \
-            -DSYMENGINE_RCP_BACKEND=nb_intrusive \
+            -DSYMENGINE_RCP_BACKEND=cooperative_intrusive \
             -DCMAKE_BUILD_TYPE=Release
```

> **Cross-repo dependency / risk.** This workflow clones symengine from
> `https://github.com/symengine/symengine.git` (the public default branch), **not**
> from the local submodule. `cooperative_intrusive` is the canonical name that
> branch already supports, so switching the *value* here is safe immediately and
> is strictly an improvement. The *alias removal* in A4, however, only takes
> effect for consumers once it is merged into whatever symengine branch they
> build. See §7 (Risks) for the merge-ordering note.

### A3. Remove legacy acceptance in the super-project CI scripts

These accept the old spelling as an *input value*; once nothing supplies it, the
acceptance is dead and must go so the scripts can't silently honor a removed name.

File: `/work/.ci/ci-common.sh` (the `ci_apply_rcp_choice` function, ~lines 204–207)

```diff
 ci_apply_rcp_choice() {
-    # Accept the legacy "nb_intrusive" spelling as well as the canonical name.
-    if [[ "${SYMENGINE_RCP_CHOICE:-}" == "cooperative_intrusive" \
-       || "${SYMENGINE_RCP_CHOICE:-}" == "nb_intrusive" ]]; then
+    if [[ "${SYMENGINE_RCP_CHOICE:-}" == "cooperative_intrusive" ]]; then
```

File: `/work/.ci/ci-02-build-and-test-nbsymengine.sh` (~lines 18–19)

```diff
-if [[ "${SYMENGINE_RCP_CHOICE:-}" != "cooperative_intrusive" \
-   && "${SYMENGINE_RCP_CHOICE:-}" != "nb_intrusive" ]]; then
+if [[ "${SYMENGINE_RCP_CHOICE:-}" != "cooperative_intrusive" ]]; then
```

(The error message on the following line already only mentions
`cooperative_intrusive`; leave it.)

### A4. Remove the alias branch (symengine submodule)

File: `symengine/CMakeLists.txt` (~lines 563–576). Delete the `nb_intrusive`
`elseif` branch entirely:

```diff
 elseif (SYMENGINE_RCP_BACKEND STREQUAL "cooperative_intrusive")
     set(WITH_SYMENGINE_COOPERATIVE_INTRUSIVE_RCP yes)
-elseif (SYMENGINE_RCP_BACKEND STREQUAL "nb_intrusive")
-    message(DEPRECATION
-        "SYMENGINE_RCP_BACKEND=nb_intrusive is deprecated; use cooperative_intrusive.")
-    set(SYMENGINE_RCP_BACKEND cooperative_intrusive)
-    set(WITH_SYMENGINE_COOPERATIVE_INTRUSIVE_RCP yes)
 elseif (SYMENGINE_RCP_BACKEND STREQUAL "teuchos")
     # both booleans stay 'no' -> Teuchos path
 else ()
     message(FATAL_ERROR
         "SYMENGINE_RCP_BACKEND='${SYMENGINE_RCP_BACKEND}' is invalid; "
         "use one of: symengine, teuchos, cooperative_intrusive")
 endif ()
```

Leave the *other* deprecation in this file untouched: the `WITH_SYMENGINE_RCP`
legacy-variable mapping (~lines 541–556) is a different, still-supported
compatibility path and is out of scope.

> **Note (no separate validation list to update):** the accepted backends are
> validated by the `STREQUAL` chain itself. There is no `set_property(... STRINGS
> ...)` enum that lists `nb_intrusive`, so removing the branch above is the only
> CMake edit needed. (Lines ~528–530 already only enumerate
> `symengine teuchos cooperative_intrusive`.) Grep to confirm:
> `grep -n "nb_intrusive" symengine/CMakeLists.txt` should return nothing after
> this edit.

---

## 5. Part B — Name normalization (live references)

These are documentation/comment/docstring edits with no behavioral effect. Make
each change minimal — swap the spelling, keep surrounding wording.

| # | File (live) | What it says now | Action |
|---|-------------|------------------|--------|
| B1 | `symengine/symengine/add.cpp` (~line 156) | comment: `the cooperative_intrusive backend (WITH_SYMENGINE_NB_INTRUSIVE_RCP),` | Rename the macro to `WITH_SYMENGINE_COOPERATIVE_INTRUSIVE_RCP`. **This is the real macro name** (see `symengine/symengine/symengine_config.h.in`); the comment currently names a macro that does not exist, which is actively misleading. |
| B2 | `symengine/CLAUDE.md` (~line 5) | `-DWITH_SYMENGINE_NB_INTRUSIVE_RCP=ON` | Replace with the current spelling. The user-facing CMake option is `-DSYMENGINE_RCP_BACKEND=cooperative_intrusive`; the internal macro is `WITH_SYMENGINE_COOPERATIVE_INTRUSIVE_RCP`. Use the option form here since the sentence is about how to enable the backend. |
| B3 | `nbsymengine/src/rcp_ownership_test_module.cpp` (~line 8) | comment: `-DSYMENGINE_RCP_BACKEND=nb_intrusive.` | → `-DSYMENGINE_RCP_BACKEND=cooperative_intrusive.` |
| B4 | `nbsymengine/tests/test_manual_ownership.py` (~line 247) | docstring: `In nb_intrusive mode, …` | → `In cooperative_intrusive mode, …` |
| B5 | `nbsymengine/tests/test_threading_stress.py` (~line 5) | docstring: `The nb_intrusive backend uses nanobind's intrusive reference counter …` | → `The cooperative_intrusive backend …` |
| B6 | `nbsymengine_compat/README.md` (~line 60) | `-DSYMENGINE_RCP_BACKEND=nb_intrusive` | → `…=cooperative_intrusive` |
| B7 | `benchmarks/LAMBDIFY_RESULTS.md` (~line 42) | "Build requirements" code block: `-DSYMENGINE_RCP_BACKEND=nb_intrusive \` | → `…=cooperative_intrusive \` (this is a forward-looking *how to build* block, not a dated capture) |
| B8 | `AGENTS.md` (~line 6; `/work/CLAUDE.md` is a symlink to it) | `now with "nb_intrusive" as a nanobind compatible reference counted pointer (RCP)` | Update to describe the current name, e.g. `now with "cooperative_intrusive" (originally "nb_intrusive") as a … RCP`. Keeping the parenthetical preserves discoverability for anyone searching the old term. Editing `AGENTS.md` updates `CLAUDE.md` automatically via the symlink. |

> **Confirm B1's macro name before editing.** Run
> `grep -rn "WITH_SYMENGINE_COOPERATIVE_INTRUSIVE_RCP" symengine/symengine/symengine_config.h.in symengine/symengine/symengine_rcp.h`
> to see the canonical macro, so the comment matches reality.

---

## 6. Touch-ups to the predecessor plan (optional, super-project)

In `docs/plans/19-PERL-EXTENSION.md`, the two "Remaining / deferred" bullets
(`nb_intrusive` name normalization; Deprecated alias) are now addressed by this
plan. Plan 19 is itself a dated record, so do **not** rewrite its body. The only
acceptable edit is appending a short closing note to each of those two bullets,
e.g. `(Resolved by docs/plans/20-REMOVE-HISTORICAL-ALIASES.md.)`. If in doubt,
leave plan 19 entirely as-is and rely on this plan's status. Mention which you
chose in the PR description.

---

## 7. Risks, ordering, and rollback

- **Caller-before-alias ordering (most important).** If A4 (alias removal) lands
  before a caller is migrated, that caller's build dies with the invalid-backend
  `FATAL_ERROR`. Always migrate callers (A1–A3) first. Within the symengine
  submodule, A1 (CI matrix) and A4 (CMake) must land in the **same commit**,
  because that CI validates that CMake.
- **Cross-repo merge ordering for downstreams.** `nbsymengine_compat`'s CI builds
  symengine from the public GitHub default branch. The alias removal only affects
  builds once it is merged there. Switching the compat CI value to
  `cooperative_intrusive` (A2) is safe immediately because that name is already
  supported upstream; do not gate A2 on A4. If the symengine change is *not* yet
  upstream, A4 has no effect on compat CI either way — there is no breakage, just
  a deferred effect. Note the current upstream state in the PR.
- **`WITH_SYMENGINE_RCP` confusion.** Do not remove or alter the
  `WITH_SYMENGINE_RCP` legacy-variable deprecation in `symengine/CMakeLists.txt`;
  it is a different mechanism and still supported.
- **Over-renaming `NB_*`.** Re-read §2.2 before touching any `NB_`/`nb_` token in
  CI. Only `nb_intrusive` (the backend) is in scope.
- **Rollback.** Each step is an isolated, reversible edit. The highest-impact
  change is A4; reverting that single diff restores the alias. Keep A4 as its own
  commit (alongside A1 in the symengine repo) so it can be reverted independently.

---

## 8. Verification

Run from `/work`. Adjust nanobind dir discovery to your environment.

### 8.1 Canonical backend still builds and tests pass

```bash
cmake -S /work -B /tmp/build-rmalias -G Ninja \
  -DBUILD_PERL_XS=ON -DSYMENGINE_RCP_BACKEND=cooperative_intrusive \
  -DBUILD_TESTS=ON -DBUILD_BENCHMARKS=OFF
cmake --build /tmp/build-rmalias -j8
ctest --test-dir /tmp/build-rmalias --output-on-failure \
  -R 'perl_symengine|test_cooperative_intrusive_rcp|test_rcp'
```

### 8.2 Old spelling now fails fast (alias is gone)

```bash
cmake -S /work -B /tmp/build-oldname -G Ninja \
  -DSYMENGINE_RCP_BACKEND=nb_intrusive 2>&1 | tee /tmp/oldname.log
# EXPECT: a FATAL_ERROR containing "is invalid; use one of: symengine, teuchos,
# cooperative_intrusive". Configuration must NOT succeed. (rm -rf /tmp/build-oldname after.)
grep -q "is invalid" /tmp/oldname.log && echo "PASS: alias removed" || echo "FAIL"
```

### 8.3 Python ownership/threading tests (nbsymengine)

Run the two normalized test modules to confirm the docstring edits didn't disturb
anything and the behavior they describe still holds:

```bash
# from your built nbsymengine environment
pytest nbsymengine/tests/test_manual_ownership.py nbsymengine/tests/test_threading_stress.py -q
```

### 8.4 No live references remain

This must return **only** the allowed dated records (and this plan):

```bash
grep -rIn "nb_intrusive" /work \
  --exclude-dir=external --exclude-dir=.git \
  | grep -v "/symengine/symengine/utilities/" \
  | grep -v "/docs/plans/1" \
  | grep -v "/docs/reports/" \
  | grep -v "/docs/historical/" \
  | grep -v "/BENCHMARKS_RESULTS.md"
```

Expected remaining hits: none from live files. (The exclusions cover the dated
records we intentionally keep; `docs/plans/20-…` — this file — is allowed to
mention the term.) Also confirm the stale macro is gone:

```bash
grep -rn "WITH_SYMENGINE_NB_INTRUSIVE_RCP" /work --exclude-dir=.git \
  --exclude-dir=external | grep -v "/docs/plans/" | grep -v "/docs/reports/" \
  | grep -v "/docs/historical/"
# EXPECT: no output
```

---

## 9. Commit / PR checklist

Commit per repository, innermost submodules first, then the super-project pointer
bumps. Suggested grouping:

1. **symengine** (branch `rcp-nanobind-2`): A1 + A4 + B1 + B2 in one commit
   (CMake + the CI that validates it + the two stale comments). Keep it minimal.
   - Suggested message: `Drop deprecated SYMENGINE_RCP_BACKEND=nb_intrusive alias; normalize stale comments`
2. **nbsymengine** (branch `main`): B3 + B4 + B5.
   - Suggested message: `Normalize nb_intrusive -> cooperative_intrusive in comments/docstrings`
3. **nbsymengine_compat** (branch `main`): A2 + B6.
   - Suggested message: `Use cooperative_intrusive backend name in CI and README`
4. **super-project** (`/work`, branch off `main`): A3 (`.ci/*`), B7
   (`benchmarks/LAMBDIFY_RESULTS.md`), B8 (`AGENTS.md`), the §6 touch-up if you
   chose to make it, this plan file, **and** the submodule pointer bumps for
   symengine / nbsymengine / nbsymengine_compat.
   - Suggested message: `Remove nb_intrusive aliases; bump submodules`

Each submodule needs its own PR in its own repo; do not push directly to a
default branch. The super-project PR records the new submodule SHAs and must be
merged after (or together with) the submodule PRs so the pointers resolve.

Final pre-merge gate: §8.1, §8.2, and §8.4 all green.
