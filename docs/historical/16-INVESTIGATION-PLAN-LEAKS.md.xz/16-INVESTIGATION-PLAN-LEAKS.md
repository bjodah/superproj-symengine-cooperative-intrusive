# 16 — Investigation Plan: Nanobind Shutdown Leak Warnings

**Date:** 2026-06-12  
**Audience:** Junior engineer  
**Status:** Investigation plan, not a fix plan

This document is a standalone plan for investigating the remaining nanobind shutdown leak warnings in this super-project.

It supersedes the older, broader leak-investigation plan by incorporating what we now know from the follow-up findings review.

---

## 1. Executive Summary

The current leak warnings are real enough to investigate, but the most recent review narrowed the problem substantially.

What we now know for certain:

* the warnings are **not caused by** `nbsymengine_compat`
* the warnings can be reproduced in `nbsymengine._core` directly
* the warnings can also be reproduced in the smaller `symengine_manual_ext` module
* simple import-only and trivial-construction scripts are clean in the tested cases
* top-level object lifetime matters
* explicit `del` before process exit suppresses the warning in the minimal repros
* nanobind reports leaked instances first, then separately reports its still-live tracked types and functions

What we do **not** know yet:

* whether this is merely expected late-shutdown reachability of module globals
* whether the custom `nb_intrusive` ownership handoff contributes to the outcome
* whether there are additional leak shapes beyond the current minimal repro
* whether a real collectable cycle exists anywhere in the current failing paths

The immediate goal is **not** to fix the warnings. The immediate goal is to determine precisely why live `_core` instances still remain in nanobind’s instance registry by the time nanobind’s `Py_AtExit` cleanup runs.

---

## 2. Problem Statement

Running:

```bash
pytest -q nbsymengine_compat/tests
```

currently ends with nanobind shutdown warnings such as:

* leaked instances of `nbsymengine._core.Basic`
* leaked instances of `nbsymengine._core.Integer`
* leaked types such as `nbsymengine._core.Basic`, `nbsymengine._core.Integer`, `nbsymengine._core.Number`
* leaked functions such as `__add__`, `__mul__`, `__hash__`, `get_args`, `is_zero`

This happens after the Python tests themselves finish successfully.

The leak warnings are process-lifetime warnings. That means:

* they are about what is still alive near interpreter shutdown
* they often require subprocess reproducers
* you cannot reason about them reliably from a normal in-process test alone

---

## 3. What We Now Know For Certain

This section is deliberately concrete. Treat it as the current known baseline.

### A. `nbsymengine_compat` is not the root trigger

This has already been demonstrated.

Minimal repros using `nbsymengine._core` alone produce the warnings.

### B. The smaller manual module also reproduces the warning

The separate `symengine_manual_ext` module, which exists as a reduced ownership-validation harness, also shows the same class of warning.

This means the problem is not specific to:

* the full `_core` surface area
* the compat shim
* litgen-generated binding bulk

### C. Import-only is clean in the tested cases

These tested cleanly:

```bash
python -c 'from nbsymengine import _core'
python -c 'import nbsymengine_compat.symengine_py_compat'
```

This matters because it makes a “default argument object created at import time” explanation less likely for the current minimal repro.

### D. Simple `Integer` / `Symbol` construction is clean in the tested cases

These tested cleanly:

```bash
python -c 'from nbsymengine import _core; x=_core.integer(1)'
python -c 'from nbsymengine import _core; x=_core.symbol("x")'
```

So the problem is not “every nanobind instance leaks.”

### E. A small top-level expression repro leaks

This leaks:

```bash
python -c 'from nbsymengine import _core; x=_core.symbol("x"); s=_core.sin(x)'
```

In that repro, nanobind reports a surviving `Symbol` instance.

### F. Explicit `del` suppresses the warning in the minimal repro

This tested cleanly:

```bash
python -c 'from nbsymengine import _core; x=_core.symbol("x"); s=_core.sin(x); del s; del x'
```

This means the current minimal repro is highly sensitive to whether top-level names remain bound until interpreter shutdown.

### G. User `atexit` runs before nanobind’s cleanup and still sees the globals

This has been directly observed:

```python
from nbsymengine import _core
import atexit

x = _core.symbol("x")
s = _core.sin(x)

@atexit.register
def show():
    import sys
    d = sys.modules["__main__"].__dict__
    print("x" in d, "s" in d)
```

The callback prints that both names are still present.

This is important because nanobind installs its leak cleanup via `Py_AtExit`, which runs after normal Python `atexit` handlers.

### H. Nanobind tracks leaked instances, types, and functions separately

From nanobind source:

* live instances are counted from `inst_c2p`
* remaining types are reported from `type_c2p_slow`
* remaining functions are reported from `funcs`

This means type/function warnings are not just textual “fallout” inferred from one instance; they are separate still-live nanobind-tracked objects.

---

## 4. Current Best Hypotheses

### H-late: late reachability (the previous leading hypothesis)

> at least one `_core` Python wrapper remains reachable late in interpreter shutdown because a top-level name still points to it, and nanobind’s `Py_AtExit` cleanup then reports that still-live instance plus its tracked type/function objects.

This is a **late-reachability / shutdown-lifetime** hypothesis.

**Important caveat discovered while preparing this revision:** H-late is incomplete
as stated. CPython's `Py_FinalizeEx` clears module dicts (`finalize_modules()`)
*before* the `Py_AtExit` callbacks run. Objects merely bound to top-level names
are therefore deallocated during interpreter finalization, before nanobind's
leak check executes. A standard nanobind extension does **not** warn about
objects left bound at top level. So "a name was still bound" cannot by itself
produce the warning — something must be preventing the normal teardown
deallocation from completing.

### H-guard: the finalization-guard hypothesis (new, sharper)

Reading `counter.inl` and `nanobind_module_common.h` together suggests a precise
mechanism:

1. `s = _core.sin(x)` makes the C++ `Sin` object hold an intrusive reference to
   the symbol. Because the symbol's wrapper exists (Python-owned state), that
   C++ reference was *transferred* to a `Py_INCREF` on the symbol's wrapper
   (`set_self_py` semantics in `counter.inl`). So `refcount(x wrapper) = 1 name + 1
   transferred C++ ref`.
2. At shutdown, `Py_FinalizeEx` sets `runtime->initialized = 0` **before**
   `finalize_modules()` clears `__main__.__dict__` (CPython explicitly documents
   this ordering in `pylifecycle.c`: exit funcs must still see an initialized
   interpreter, module teardown must not).
3. Dict clearing decrefs `s` to zero → `tp_dealloc` → C++ `Sin` destructor →
   member `RCP` dec_refs the symbol → symbol is Python-owned → the intrusive
   `dec_ref` hook installed by `initialize_intrusive_hooks()` runs → the hook's
   first line is `if (!Py_IsInitialized()) return;` → **the `Py_DECREF` is
   silently swallowed.**
4. The symbol wrapper's refcount is stranded at 1. It is never deallocated,
   never removed from `inst_c2p`, and nanobind's `Py_AtExit` check reports it —
   plus the type objects and bound functions kept alive by the leaked instance.

H-guard makes **sharp, falsifiable predictions** that H-late does not:

* `x=symbol("x"); s=sin(x)` leaks **exactly one `Symbol` instance and no `Sin`**
  (the `Sin` wrapper deallocs cleanly; only the swallowed child decref leaks).
  Under naive H-late one would expect *both* still-reachable instances reported.
* `x=symbol("x"); keep=[x]; del x` is **clean** — a plain Python list dealloc
  uses ordinary `Py_DECREF`, no intrusive hook involved.
* `x=symbol("x"); s=sin(x); del s` is **clean** — the `Sin` is destroyed while
  the interpreter is fully alive, so the hook performs the `Py_DECREF`.
* `x=symbol("x"); s=sin(x); del x` still leaks **one Symbol** — the leak does
  not depend on the symbol's *name* surviving, only on a C++-held transferred
  reference being released during finalization.
* `sys.getrefcount(x)` after `s=sin(x)` reads 3 (name + transferred ref +
  getrefcount argument).

Both hypotheses remain better supported than:

* “pure type registration bug”
* “compat cache leak”
* “singleton-only problem”
* “gross `nb_intrusive` refcount arithmetic bug” (under H-guard the counting is
  correct; it is the *shutdown-window guard* that misbehaves)

That does **not** mean those other possibilities are impossible. It means they are not the leading explanation at this stage.

---

## 5. Non-Goals

This investigation does **not** aim to do any of the following yet:

* suppress the warnings just to make CI quiet
* land `nb::set_leak_warnings(false)` as a shortcut
* implement `tp_traverse` / `tp_clear` preemptively
* redesign the `nb_intrusive` ownership model
* rewrite the compat layer

Those may become relevant later, but not before the shutdown behavior is localized more precisely.

---

## 6. Background: Why Shutdown Leaks Are Tricky

Junior engineers often make one of two mistakes here:

1. they assume “if `gc.collect()` does nothing, the C++ refcounting must be broken”
2. they assume “if `del` fixes it, the warning is harmless and can be ignored”

Both are wrong.

### A. Why `del` matters

Python uses reference counting immediately, not just periodic GC.

If a top-level name still points at an object, that object is still live. It is not a “leak” in the normal sense yet. It is just still reachable.

### B. Why GC may be irrelevant

GC matters for cycles.

If the problem is simply:

* `__main__.__dict__` still contains `x`

then `gc.collect()` is not the primary mechanism, because `x` is still reachable from a live root.

### C. Why nanobind still warns

Nanobind is intentionally strict. Its docs say that if nanobind-created instances/types/functions still exist when its shutdown cleanup runs, it warns noisily.

That warning can indicate:

* a real cycle
* a real refcount bug
* an interaction with other code
* or simply objects still alive unusually late in shutdown

Your job is to distinguish those cases with evidence.

---

## 7. Investigation Goal

The immediate goal is:

> determine exactly why the minimal `_core` repro still leaves a live `Symbol` wrapper in nanobind’s instance registry when `internals_cleanup()` runs.

This breaks down into four smaller questions:

1. Is the object still alive solely because a top-level Python name remains bound?
2. Is the current behavior expected for nanobind wrappers under `Py_AtExit`, or unusual for this binding?
3. Does the custom `nb_intrusive` ownership model change the lifetime in a meaningful way?
4. Are there additional cases involving real cross-language cycles that the minimal repro does not expose?

---

## 8. Files Most Relevant To This Investigation

You should expect to read and reason about these files.

### Project code

* `nbsymengine/src/core_module.cpp`
* `nbsymengine/src/rcp_ownership_test_module.cpp`
* `nbsymengine/support/nanobind_module_common.h`
* `nbsymengine/support/nanobind_symengine.h`
* `symengine/symengine/symengine_rcp_nb.cpp`
* `symengine/symengine/symengine_rcp.h`

### Nanobind reference material

Local checkout:

* `/tmp/nanobind/docs/refleaks.rst`
* `/tmp/nanobind/src/nb_internals.cpp`
* `/tmp/nanobind/include/nanobind/nb_lib.h`
* `/tmp/nanobind/include/nanobind/intrusive/counter.inl` (set_self_py / inc_ref / dec_ref semantics)
* `/tmp/nanobind/docs/api_core.rst`

### CPython reference material

* `Python/pylifecycle.c` (`Py_FinalizeEx` ordering: atexit funcs →
  `runtime->initialized = 0` → `finalize_modules()` → `Py_AtExit` callbacks).
  If no local source tree is available, verify the ordering empirically via
  Experiment 11.

### Existing reports and plans

* `docs/reports/14-POST-REMAINING-WORK.md`
* `docs/plans/15-INVESTIGATION-LEAKS.md` (the broader predecessor plan)

---

## 9. Investigation Sequence

Follow this sequence. Do not jump ahead.

### Phase 1. Re-establish the minimal repro

Before doing any new code reading, rerun the known minimal cases and record the exact output.

Run:

```bash
python -c 'from nbsymengine import _core'
python -c 'from nbsymengine import _core; x=_core.integer(1)'
python -c 'from nbsymengine import _core; x=_core.symbol("x")'
python -c 'from nbsymengine import _core; x=_core.symbol("x"); s=_core.sin(x)'
python -c 'from nbsymengine import _core; x=_core.symbol("x"); s=_core.sin(x); del s; del x'
PYTHONPATH=/work/build python -c 'import symengine_manual_ext as m; x=m.symbol("x"); s=m.add(x,m.integer(1)); p=m.pow(s,m.integer(2))'
```

Capture:

* stdout
* stderr
* return code

Do not proceed until your outputs match the known pattern closely enough.

### Phase 2. Confirm the live-root explanation carefully

Use `atexit`, `gc.get_referrers`, and `__main__.__dict__` to confirm exactly what still refers to the object near shutdown.

Questions to answer:

* does `x` remain present in `__main__.__dict__`?
* does `s` remain present in `__main__.__dict__`?
* is the main dictionary the only Python referrer you can observe?
* when only `s` is kept, does `x` still survive because `s` refers to it?

You must answer these with tiny isolated scripts, not by reasoning from memory.

### Phase 3. Distinguish “still reachable” from “cycle”

This phase exists because the fix strategy depends on the answer.

Test scripts where:

* the only live object at top level is the symbol
* the only live object at top level is the expression
* the top-level name is deleted but another container still holds the object

Examples:

```bash
python -c 'from nbsymengine import _core; x=_core.symbol("x")'
python -c 'from nbsymengine import _core; x=_core.symbol("x"); s=_core.sin(x); del x'
python -c 'from nbsymengine import _core; x=_core.symbol("x"); keep=[x]'
python -c 'from nbsymengine import _core; x=_core.symbol("x"); s=_core.sin(x); keep=[s]; del s'
```

Interpretation:

* if any live root keeps the warning alive, that supports the “late reachability” model
* if warnings persist after all obvious roots are removed, look harder for cycles or hidden holders

### Phase 4. Compare raw `_core` against the manual module

The manual module is valuable because it removes a lot of unrelated binding surface.

For equivalent object patterns, compare:

* raw `_core`
* `symengine_manual_ext`

Questions:

* do both require top-level reachability?
* do both clean up when names are deleted?
* do both leak the same kinds of live instances?
* is the leak size materially different?

If the behavior differs, write that down carefully. Differences matter.

### Phase 5. Inspect the ownership handoff path

Only after the behavioral repros are stable should you read the `nb_intrusive` path.

You need to understand:

* how a `Basic` wrapper becomes Python-owned
* where `self_py()` is attached
* how `RCP<const Basic>` is converted back to an existing Python object
* what `detach_python()` does
* what the singleton shutdown cleanup actually handles

At this phase, your task is not to invent a fix. Your task is to be able to explain the lifetime rules back to someone else accurately.

### Phase 6. Verify whether singleton cleanup is involved at all

The minimal `sin(x)` repro does not look like a singleton-only problem, but you must still prove that the singleton cleanup path is not the relevant mechanism for that case.

Questions:

* does the minimal repro touch any singleton wrappers?
* does removing singleton-related expressions change the repro?
* does the atexit singleton cleanup code run in this case without affecting the surviving symbol?

### Phase 6b. Test H-guard directly (decisive phase)

Two parts: a behavioral matrix that needs no rebuild, and one instrumented
build that settles the question empirically.

**Part 1 — behavioral matrix.** Run the H-guard prediction set from Section 4
and record, for each case, the *exact* leaked instance census (count and type
names). H-guard stands or falls on:

* `keep=[x]` being clean while `s=sin(x)` leaks
* the leaked instance being the *child* (`Symbol`), never the parent (`Sin`)
* `del s` (keeping `x`) being clean
* `del x` (keeping `s`) still leaking one `Symbol`

**Part 2 — instrumented hooks.** Temporarily modify
`nbsymengine/support/nanobind_module_common.h` so the dec_ref hook logs to
stderr when it is invoked with `Py_IsInitialized() == 0` (i.e. when it is about
to swallow a `Py_DECREF`). Rebuild only `symengine_manual_ext` and run the
manual-module repro. If the log line appears during shutdown for exactly the
stranded wrapper, H-guard is proven. Revert the instrumentation afterwards.

Optionally, as a confirmation (not a fix): rebuild with the guard removed
(matching the hook bodies in nanobind's own intrusive docs) and verify the
warning disappears for the minimal repro, while noting any new risk this
creates for post-finalize C++ static destructors.

### Phase 7. Only then revisit cycle-specific remedies

Only after Phases 1-6 should you ask whether `tp_traverse` / `tp_clear` are relevant.

If the root cause remains “object still reachable from module globals at late shutdown,” then cycle-breaking type slots are not the primary answer.

If you later discover a true cycle involving:

* Python function closures
* callback storage
* cross-language object graphs

then revisit nanobind’s cycle-handling guidance.

---

## 10. Concrete Experiments

This section is a checklist. Run these in fresh subprocesses.

### Experiment 1. Known clean cases

```bash
python -c 'from nbsymengine import _core'
python -c 'from nbsymengine import _core; x=_core.integer(1)'
python -c 'from nbsymengine import _core; x=_core.symbol("x")'
```

Expected:

* no leak warnings

### Experiment 2. Minimal leaking case

```bash
python -c 'from nbsymengine import _core; x=_core.symbol("x"); s=_core.sin(x)'
```

Expected:

* leak warning
* leaked instance should include `nbsymengine._core.Symbol`

### Experiment 3. Remove all obvious roots

```bash
python -c 'from nbsymengine import _core; x=_core.symbol("x"); s=_core.sin(x); del s; del x'
```

Expected:

* no leak warning

### Experiment 4. Keep only the expression

```bash
python -c 'from nbsymengine import _core; x=_core.symbol("x"); s=_core.sin(x); del x'
```

Why:

* if this still leaks, the expression is keeping the symbol alive

### Experiment 5. Keep only a container

```bash
python -c 'from nbsymengine import _core; x=_core.symbol("x"); keep=[x]; del x'
python -c 'from nbsymengine import _core; x=_core.symbol("x"); s=_core.sin(x); keep=[s]; del s'
```

Why:

* this checks whether any ordinary Python live root is sufficient

### Experiment 6. Atexit visibility

Write a short script that prints whether `x` and `s` are still in `__main__.__dict__` from an `atexit` handler.

Expected:

* they are still present if not deleted explicitly

### Experiment 7. Python referrers

Use:

* `gc.get_referrers(x)`

in a controlled script.

Expected:

* in the minimal case, `__main__.__dict__` should appear as the visible Python referrer

Be careful:

* `gc.get_referrers()` is intrusive and can perturb the graph
* only use it in a tiny script

### Experiment 8. Manual module equivalence

```bash
PYTHONPATH=/work/build python -c 'import symengine_manual_ext as m; x=m.symbol("x"); s=m.add(x,m.integer(1)); p=m.pow(s,m.integer(2))'
PYTHONPATH=/work/build python -c 'import symengine_manual_ext as m; x=m.symbol("x"); s=m.add(x,m.integer(1)); p=m.pow(s,m.integer(2)); del p; del s; del x'
```

Expected:

* first leaks
* second is clean

If not, write down the exact difference.

### Experiment 9. Exact leak census (H-guard discriminator)

For each leaking case, record the exact number and type of leaked instances
from stderr. H-guard predicts the leaked instance is always the *referenced
child* (e.g. `Symbol`), never the top-level expression whose name was bound.

```bash
python -c 'from nbsymengine import _core; x=_core.symbol("x"); s=_core.sin(x)'        # predict: 1 Symbol, 0 Sin
python -c 'from nbsymengine import _core; x=_core.symbol("x"); s=_core.sin(x); del x' # predict: 1 Symbol
python -c 'from nbsymengine import _core; x=_core.symbol("x"); s=_core.sin(x); del s' # predict: clean
```

### Experiment 10. Refcount probe (H-guard discriminator)

```bash
python -c 'import sys; from nbsymengine import _core; x=_core.symbol("x"); s=_core.sin(x); print(sys.getrefcount(x), file=sys.stderr)'
```

Predict: 3 (top-level name + transferred C++ ref held by the Sin + getrefcount
argument). If it reads 2, H-guard's premise about transferred references is
wrong.

### Experiment 11. Instrumented dec_ref hook (H-guard proof)

Temporarily patch the dec_ref hook in
`nbsymengine/support/nanobind_module_common.h`:

```cpp
[](PyObject *o) noexcept {
    if (!Py_IsInitialized()) {
        fprintf(stderr, "[hook] dec_ref swallowed for %p (Py_IsInitialized()==0)\n", (void*) o);
        return;
    }
    ...
}
```

Rebuild only `symengine_manual_ext`, rerun the manual repro, capture stderr.
The swallowed-decref line appearing for exactly the wrapper(s) that nanobind
subsequently reports as leaked proves H-guard. Revert the patch afterwards.

---

## 11. How To Interpret Results

### If `del` reliably makes the warning disappear

That strongly supports:

* late top-level reachability

It does **not** by itself prove:

* absence of all ownership issues

### If warnings persist after removing all obvious roots

That supports one of:

* hidden Python containers
* hidden C++ holders
* a real cycle
* a refcount bug

That is the point where deeper instrumentation becomes mandatory.

### If manual module behavior differs from `_core`

Then the difference is extremely valuable.

It would suggest that:

* a larger `_core` binding surface matters
* extra functions/types change lifetime behavior
* or some special-case binding in `_core` matters

### If singleton-only probes are clean

Then singleton cleanup is probably not the primary explanation for the minimal `sin(x)` case.

Do not over-attribute everything to the singleton detach machinery.

---

## 12. Questions This Investigation Must Answer Before Any Fix Plan

You should be able to answer all of these clearly.

1. In the minimal `_core.sin(x)` repro, what Python object is still live at nanobind shutdown?
2. What Python root keeps it live?
3. Is the object still intentionally reachable, or only accidentally retained?
4. Does the same reachability pattern explain the manual module repro?
5. Is there any evidence of a genuine cross-language cycle in the minimal repro?
6. Is there any evidence of a gross refcount mismatch in the minimal repro?
7. Is the singleton cleanup path relevant to the minimal repro?
8. Does the `Py_IsInitialized()` guard in the intrusive dec_ref hook swallow
   `Py_DECREF`s during `finalize_modules()`? (H-guard, Experiment 11)
9. Does the evidence suggest a binding fix, an ownership fix, a shutdown-policy fix, or simply better lifecycle discipline in tests?

Do not proceed to implementation planning until these are answered.

---

## 13. Instrumentation Guidance

Only add temporary instrumentation if the small subprocess scripts stop being informative.

### Python-side instrumentation

Allowed and useful:

* `atexit`
* `gc.get_referrers`
* `gc.collect()`
* `sys.modules["__main__"].__dict__`
* `sys.getrefcount(...)`

Keep the scripts tiny. Delete them after use unless they become valuable regression tests.

### C++-side instrumentation

If Python-side evidence becomes insufficient, add temporary logging around:

* `set_self_py(...)`
* `self_py()`
* `detach_python()`
* `from_cpp(...)` in the `RCP<T>` caster
* any custom intrusive inc/dec hook boundaries

Do not land noisy logging permanently.

---

## 14. Risks And Common Mistakes

### Mistake 1. Treating any nanobind warning as proof of a cycle

Not every warning is a cycle.

### Mistake 2. Treating `gc.is_tracked() == False` as a complete diagnosis

That is only one clue. It does not tell you why the object is still reachable.

### Mistake 3. Recommending `tp_traverse` before proving a cycle exists

That is premature and likely wrong for the current minimal repro.

### Mistake 4. Recommending `set_leak_warnings(false)` as a “fix”

That is a suppression policy, not a root-cause fix.

Also, nanobind documents it as a global ABI-domain flag. In this project, no `NB_DOMAIN` is currently set in `nbsymengine/CMakeLists.txt`, so the impact is broader than one module.

### Mistake 5. Deleting `sys.modules` entries in experimental cleanup scripts

Earlier experiments showed this can make the warning much worse and create misleading results.

Avoid it unless you are explicitly testing shutdown-order pathologies.

---

## 15. Expected Deliverables

At the end of this investigation slice, the engineer should produce:

1. one short markdown note with exact repro commands and outputs
2. one table showing clean vs leaking cases
3. one short explanation of the live-root chain in the minimal repro
4. one statement on whether `nb_intrusive` still needs deeper suspicion
5. one recommendation for the next implementation or investigation step

That note should be short, factual, and evidence-driven.

---

## 16. Exit Criteria

This plan is complete when all of the following are true:

1. the minimal repro and minimal clean variant are both stable
2. the engineer can explain the role of `__main__.__dict__` at `atexit`
3. the engineer can explain why the current evidence supports late reachability more strongly than a type-registration bug
4. the engineer can explain why `tp_traverse` is not yet the obvious next move
5. the engineer can point to the next most valuable experiment or the first credible fix direction

Until then, do not write an implementation plan.

---

## 17. Immediate First Step

Start by re-running the six subprocess commands in Section 9 Phase 1 and save the raw stderr for each.

If those outputs do not match the current findings, stop and reconcile that first. A moving baseline invalidates everything that follows.
