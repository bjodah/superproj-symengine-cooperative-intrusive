# Implementation Plan: LLVM Lambdify Support for nbsymengine / nbsymengine_compat

## Root Cause

The benchmark gap is explained by LLVM:

| Backend | Mechanism | ion_speciation | vs SymPy |
|---------|-----------|---------------|----------|
| legacy-symengine | LLVM JIT (`LLVMDoubleVisitor`) | 1.45 us | **4.69x** |
| nbsymengine-legacy | Compat shim → LLVM | 4.37 us | 1.56x |
| nbsymengine | Interpreter (`LambdaRealDoubleVisitor`) | 11.38 us | 0.60x |
| SymPy | Python lambdify | 6.82 us | 1.00x |

The C++ `LLVMVisitor::init()` JIT-compiles SymEngine expression trees into native
machine code via LLVM IR generation + optimization passes + MCJIT. The current
`LambdaRealDoubleVisitor` builds chains of `std::function` closures — no JIT, no
optimization. The 7.8x gap between legacy-symengine and nbsymengine on the same
expressions is entirely attributable to this.

## Key C++ API (from `symengine/llvm_double.h`)

```cpp
class LLVMVisitor : public RewriteTrigVisitor<LLVMVisitor> {
    void init(const vec_basic &inputs, const vec_basic &outputs,
              bool symbolic_cse = false, unsigned opt_level = 3);
    const std::string &dumps() const;  // serialize compiled object code
    void loads(const std::string &s);  // deserialize
};

class LLVMDoubleVisitor : public LLVMVisitor {
    void call(double *outs, const double *inps) const;
};
```

---

## Phase 1: C++ nanobind wrapper (`core_module.cpp`)

**File:** `nbsymengine/bindings/python_nanobind/src/core_module.cpp`

Add a `PyLLVMDouble` class mirroring the existing `PyLambdaRealDouble` (lines 72-95),
guarded by `#ifdef HAVE_SYMENGINE_LLVM`:

```cpp
#ifdef HAVE_SYMENGINE_LLVM
#include <symengine/llvm_double.h>

class PyLLVMDouble {
    std::unique_ptr<LLVMDoubleVisitor> visitor_;
    vec_basic inputs_;
    size_t n_inputs_;
    size_t n_outputs_;
public:
    PyLLVMDouble(const vec_basic &inputs,
                 const vec_basic &flat_outputs,
                 bool cse, unsigned opt_level)
        : inputs_(inputs),
          n_inputs_(inputs.size()),
          n_outputs_(flat_outputs.size())
    {
        visitor_ = std::make_unique<LLVMDoubleVisitor>();
        visitor_->init(inputs_, flat_outputs, cse, opt_level);
    }

    // Deserialization constructor
    PyLLVMDouble(const std::string &blob,
                 size_t n_inputs, size_t n_outputs)
        : n_inputs_(n_inputs), n_outputs_(n_outputs)
    {
        visitor_ = std::make_unique<LLVMDoubleVisitor>();
        visitor_->loads(blob);
    }

    size_t n_inputs() const { return n_inputs_; }
    size_t n_outputs() const { return n_outputs_; }
    void call(double *out, const double *inp) { visitor_->call(out, inp); }
    std::string dumps() const { return visitor_->dumps(); }
};
#endif
```

Bind it as `_core._LLVMDouble` alongside `_LambdaRealDouble` (after line 916):

```cpp
#ifdef HAVE_SYMENGINE_LLVM
    nb::class_<PyLLVMDouble>(m, "_LLVMDouble")
        .def("__init__", [](PyLLVMDouble *self,
                            const std::vector<RCP<const Basic>> &inputs,
                            const std::vector<RCP<const Basic>> &outputs,
                            bool cse, unsigned opt_level) {
            new (self) PyLLVMDouble(inputs, outputs, cse, opt_level);
        }, nb::arg("inputs"), nb::arg("outputs"),
           nb::arg("cse") = false, nb::arg("opt_level") = 3)
        .def("n_inputs", &PyLLVMDouble::n_inputs)
        .def("n_outputs", &PyLLVMDouble::n_outputs)
        .def("call", [](PyLLVMDouble &self,
                        nb::ndarray<double, nb::ndim<1>, nb::c_contig> inp,
                        nb::ndarray<double, nb::ndim<1>, nb::c_contig> out) {
            if ((size_t)inp.shape(0) != self.n_inputs())
                throw nb::value_error(
                    ("Expected " + std::to_string(self.n_inputs()) +
                     " input values, got " + std::to_string(inp.shape(0))).c_str());
            if ((size_t)out.shape(0) != self.n_outputs())
                throw nb::value_error(
                    ("Expected " + std::to_string(self.n_outputs()) +
                     " output slots, got " + std::to_string(out.shape(0))).c_str());
            try {
                self.call(out.data(), inp.data());
            } catch (const std::exception &e) {
                PyErr_SetString(PyExc_RuntimeError, e.what());
                throw nb::python_error();
            }
        }, nb::arg("inp"), nb::arg("out"))
        .def("dumps", &PyLLVMDouble::dumps)
        .def("call_vector", [](PyLLVMDouble &self,
                               const std::vector<double> &inp) -> std::vector<double> {
            if (inp.size() != self.n_inputs())
                throw nb::value_error(
                    ("Expected " + std::to_string(self.n_inputs()) +
                     " input values, got " + std::to_string(inp.size())).c_str());
            std::vector<double> out(self.n_outputs());
            try {
                self.call(out.data(), inp.data());
            } catch (const std::exception &e) {
                PyErr_SetString(PyExc_RuntimeError, e.what());
                throw nb::python_error();
            }
            return out;
        }, nb::arg("inp"));
#endif
```

Expose a feature flag:

```cpp
m.attr("have_llvm") =
#ifdef HAVE_SYMENGINE_LLVM
    true;
#else
    false;
#endif
```

---

## Phase 2: CMake integration

**File:** `nbsymengine/bindings/python_nanobind/CMakeLists.txt`

After `find_package(SymEngine)`, detect LLVM and conditionally add the define + link
flags:

```cmake
# Detect LLVM support from the SymEngine installation
if (TARGET symengine)
    get_target_property(SYMENGINE_DEFS symengine INTERFACE_COMPILE_DEFINITIONS)
    if ("HAVE_SYMENGINE_LLVM" IN_LIST SYMENGINE_DEFS)
        set(NBSYMENGINE_HAVE_LLVM ON)
    endif()
else()
    # Check SymEngine config variables
    if (HAVE_SYMENGINE_LLVM)
        set(NBSYMENGINE_HAVE_LLVM ON)
    endif()
endif()

if (NBSYMENGINE_HAVE_LLVM)
    message(STATUS "LLVM support enabled for nbsymengine")
    target_compile_definitions(_core PRIVATE HAVE_SYMENGINE_LLVM=1)
    # LLVM libraries are already linked into libsymengine when built with
    # -DWITH_LLVM=ON and SYMENGINE_LLVM_LINK_DOWNSTREAM=yes (the default
    # for shared libs). If not, we need to find and link LLVM ourselves:
    find_package(LLVM CONFIG QUIET)
    if (LLVM_FOUND)
        target_link_directories(_core PRIVATE ${LLVM_LIBRARY_DIRS})
        target_link_libraries(_core PRIVATE ${LLVM_LIBRARIES})
        target_include_directories(_core PRIVATE ${LLVM_INCLUDE_DIRS})
    endif()
endif()
```

### Build requirement

The SymEngine C++ library must be built with `-DWITH_LLVM=ON`. The current benchmark
environment uses:
```
-DBUILD_PYTHON_NANOBIND=ON -DSYMENGINE_RCP_BACKEND=nb_intrusive -DINTEGER_CLASS=boostmp
```
This needs `-DWITH_LLVM=ON` added. LLVM >= 5.0 is required (CMake handles version
compatibility up to LLVM 22).

---

## Phase 3: Python `Lambdify` integration

**File:** `nbsymengine/python-bindings/nbsymengine/lambdify.py`

### 3a. Expose feature flag

```python
have_llvm = getattr(_core, 'have_llvm', False)
```

### 3b. Extend backend validation (line 334)

```python
if backend not in ('sympy', 'lambda_double', 'llvm', 'auto'):
    raise ValueError(
        f"Unknown backend {backend!r}. Use 'sympy', 'lambda_double', 'llvm', or 'auto'."
    )
```

### 3c. Add LLVM backend path (after the `lambda_double` block, after line 371)

```python
if self._backend == 'llvm':
    if not have_llvm:
        raise ValueError(
            "LLVM backend requested but nbsymengine was built without LLVM support."
        )
    if not self._real:
        raise ValueError("LLVM backend only supports real-valued expressions.")
    flat_exprs = _flatten_exprs(self._exprs_list)
    opt_level = kwargs.get('opt_level', 3)
    self._native = _core._LLVMDouble(
        self._args, flat_exprs, cse=cse, opt_level=opt_level
    )
    self._n_flat = self._native.n_outputs()
    return
```

### 3d. Update `auto` resolution (line 342)

```python
if self._backend == 'auto':
    self._backend = 'llvm' if (have_llvm and self._real) else 'lambda_double'
```

### 3e. Update `unsafe_real` method

Ensure it routes to `_native.call()` for both `lambda_double` and `llvm` backends
(currently it may only handle `lambda_double`).

### 3f. Update `__call__` output path

The `__call__` method should work identically for both native backends since they
share the same `call(inp, out)` interface.

---

## Phase 4: nbsymengine_compat integration

### 4a. Feature flags

**File:** `nbsymengine_compat/src/nbsymengine_compat/_constants.py`

Replace hardcoded flags (lines 52-55) with runtime detection:

```python
from nbsymengine._core import have_llvm as _have_llvm
have_llvm = _have_llvm
have_llvm_long_double = False  # Not yet supported in nanobind bindings
```

### 4b. Compat Lambdify

**File:** `nbsymengine_compat/src/nbsymengine_compat/lambdify.py` (or equivalent)

Update the compat `Lambdify` to pass `backend='llvm'` through to `nbsymengine.Lambdify`
when the legacy `backend='llvm'` is requested. Accept and forward `opt_level` kwarg.

### 4c. Update `__init__.py` exports

Export `have_llvm` from the compat package's `__init__.py`.

---

## Phase 5: Serialization support (optional, lower priority)

Expose `dumps()`/`loads()` for pickling JIT-compiled functions. This is unique to LLVM
and valuable for caching compiled expressions.

The C++ `LLVMVisitor` already supports this via its `ObjectCache` mechanism. The Python
layer would add `__reduce__` / `__getstate__` / `__setstate__` methods to the `Lambdify`
object when using the LLVM backend.

---

## Phase 6: Tests

**File:** `nbsymengine/python-bindings/tests/test_lambdify_direct.py`

All LLVM tests should `skipUnless(have_llvm)`.

| Test | Description |
|------|-------------|
| `test_Lambdify_LLVM_basic` | Scalar expressions, verify numerical correctness |
| `test_Lambdify_LLVM_opt_level` | Test opt_level 0-3 produce correct results |
| `test_Lambdify_LLVM_cse` | CSE + LLVM combination |
| `test_Lambdify_LLVM_vector_output` | Multi-output expressions |
| `test_Lambdify_LLVM_matrix_output` | DenseMatrix output |
| `test_Lambdify_LLVM_heterogeneous` | The benchmark case that currently fails (vector + matrix tuple) |
| `test_Lambdify_LLVM_serialization` | `dumps()`/`loads()` round-trip |
| `test_Lambdify_LLVM_unavailable` | Graceful error when LLVM not compiled in |
| `test_Lambdify_LLVM_float_dtype` | `LLVMFloat` via `dtype=np.float32` (Phase 2) |
| `test_Lambdify_LLVM_default_backend` | Verify `auto` resolves to `llvm` when available |

Also update `nbsymengine_compat` generated tests to exercise the LLVM path.

---

## Phasing and Priority

| Priority | Phase | Effort | Impact |
|----------|-------|--------|--------|
| **P0** | Phase 1 (C++ wrapper) | ~1 day | Core enabler |
| **P0** | Phase 2 (CMake) | ~0.5 day | Build integration |
| **P0** | Phase 3 (Python Lambdify) | ~0.5 day | User-facing API |
| **P0** | Phase 6 (Tests) | ~1 day | Validation |
| **P1** | Phase 4 (compat shim) | ~0.5 day | Legacy API compat |
| **P2** | Phase 5 (Serialization) | ~1 day | Pickle support |

Total estimated effort: ~4-5 days.

---

## Expected Performance Impact

Based on the benchmarks:
- **ion_speciation**: Expect ~1.45 us (matching legacy-symengine), a **7.8x speedup**
  over current nbsymengine
- **heterogeneous_output**: Expect ~1.9 us (matching legacy-symengine), a **400x
  speedup** over nbsymengine-legacy

The LLVM JIT eliminates per-call interpreter overhead entirely — the expression tree
becomes native x86_64 machine code after `init()`.

---

## Risks and Mitigations

| Risk | Mitigation |
|------|-----------|
| LLVM library linking complexity downstream | Use `SYMENGINE_LLVM_LINK_DOWNSTREAM` CMake flag; test with both shared and static LLVM |
| LLVM version incompatibility | SymEngine already supports LLVM 5-22 with compatibility shims; CI matrix test |
| `HAVE_SYMENGINE_LLVM` not in `INTERFACE_COMPILE_DEFINITIONS` | Fall back to checking `SymEngineConfig.cmake` variables directly |
| Heterogeneous output still broken | Fix in Phase 3 by handling tuple returns per-element (adapter issue, not LLVM) |
| `nb_intrusive` + LLVM interaction | LLVM visitors don't use RCP internally; should be orthogonal |
