# 22d - Upstream Readiness

## PHP Tests Validating Backend-Generic Behavior

- `symengine.php/tests/020-identity-reuse.phpt`
- `symengine.php/tests/025-canonical-identity-reuse.phpt`
- `symengine.php/tests/030-external-ownership.phpt`
- `symengine.php/tests/035-debug-helpers.phpt`
- `symengine.php/tests/045-expression-pins-operand.phpt`
- `symengine.php/tests/050-singleton-teardown.phpt`
- `symengine.php/tests/060-expression-teardown.phpt`
- `symengine.php/tests/065-loop-teardown.phpt`

## Perl Tests Validating Backend-Generic Behavior

- `symengine.pl/t/04-cooperative.t`
- `symengine.pl/t/05-teardown.t`

## Core C++ Tests That No Longer Require A Foreign Runtime

- `symengine/symengine/tests/rcp/test_cooperative_intrusive_rcp.cpp`
  - `C++-owned counting`
  - `Handoff changes mode`
  - `External-owned inc/dec route through hooks`
  - `use_count() is never 1 when external-owned`
  - `detach external and replay inline references`

## Runtime-Specific Behavior That Should Not Move Upstream

- PHP `RSHUTDOWN` / `MSHUTDOWN` placement details
- PHP `zend_object *` wrapper management
- Perl `call_atexit` and `PL_phase` shutdown coordination
- Runtime-specific subprocess harnesses and PHPT/TAP details

## Remaining Unknowns

- Apache module lifecycle remains unverified
- PHP FPM lifecycle has local smoke coverage only, not a broad deployment matrix
- A true PHP ASAN lane is still deferred; current evidence is the clean debug lane

## Bugs Found

### SymEngine core

- None during this phase; added a regression test for the detach/replay primitive

### PHP binding

- Direct `new SymEngine\Basic`, `new SymEngine\Integer`, and `new SymEngine\Symbol` created invalid wrappers; now blocked with a throwing constructor
- PHP lacked explicit canonical wrapper-reuse and operand-pin ownership tests; added
- PHP teardown PHPTs could hang indefinitely; now use timeout-based subprocess handling
- PHP clean build missed Boost headers when SymEngine used `INTEGER_CLASS=boostmp`; fixed in `symengine.php/config.m4`
- Debug helper exposure was accidentally tied to PHP's `NDEBUG`; fixed with explicit `SYMENGINE_PHP_DEBUG_HELPERS`

### Perl binding

- None required for this phase; Perl remained the stronger teardown reference lane

### CI/documentation

- Clean PHP extension build depended on ambient Boost headers; fixed so `.ci/ci-06-build-and-test-php.sh` now works from a fresh install tree
- FPM tooling was installed and the smoke harness now asserts response bodies and worker PID stability

## Candidate Upstream Material

- The core C++ detach/replay regression test
- Documentation that external-owned `use_count()` intentionally returns `0`
- Documentation of the aligned foreign-owner pointer precondition
- Documentation that `is_uniquely_owned_by_cpp()` is the correct ownership check under `cooperative_intrusive`
