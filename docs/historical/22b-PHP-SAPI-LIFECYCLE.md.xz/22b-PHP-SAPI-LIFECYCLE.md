# 22b - PHP SAPI Lifecycle

## Status

PHP CLI and PHP-FPM were validated in this workspace. Apache module mode remains
unverified.

## Local Environment Checked

- PHP CLI version: `PHP 8.4.21 (cli)`
- PHP-FPM version: `PHP 8.4.21 (fpm-fcgi)`
- Verified SAPIs: `cli`, `fpm-fcgi`
- FPM harness: `symengine.php/tools/fpm-smoke.sh`
- Extension path used: `/tmp/se-php-review-ext/modules/symengine.so`

## FPM Tooling

Initial tooling check:

```bash
command -v php-fpm || command -v php-fpm8.4 || command -v php-fpm8.3 || command -v php-fpm8.2 || true
command -v cgi-fcgi || true
```

Initial observed result: both tools were missing. They were then installed with:

```bash
apt-get update
DEBIAN_FRONTEND=noninteractive apt-get install -y php8.4-fpm libfcgi-bin
```

## FPM Command Run

```bash
symengine.php/tools/fpm-smoke.sh \
  /tmp/se-php-review-install \
  /tmp/se-php-review-ext/modules/symengine.so
```

Observed output included:

```text
worker:523080
singleton:pi
worker:523080
expression:1 + x**2
worker:523080
canonical:same
FPM smoke passed with worker 523080
```

## Result Summary

- Repeated requests passed: yes
- Same worker handled all tested requests: yes
- FPM shutdown passed: yes
- Stderr contained crashes, leaks, or warnings: no
- Limitation: Apache module mode remains untested

## Verified Scope

- PHP CLI cooperative ownership PHPT suite passed from a clean build in `/tmp/se-php-review-ext`
- CLI teardown subprocess tests now have explicit timeout handling
- The current PHP design claims cover CLI plus the local FPM smoke shape:
  `pm = static`, `pm.max_children = 1`, a temporary Unix socket, three
  sequential requests to one worker, then clean master shutdown
