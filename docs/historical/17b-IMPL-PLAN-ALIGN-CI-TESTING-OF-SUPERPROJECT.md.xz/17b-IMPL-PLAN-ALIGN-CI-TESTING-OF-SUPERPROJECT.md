# 17b - Implementation Plan: Align CI Testing of Superproject

**Date:** 2026-06-13
**Audience:** Junior engineer
**Status:** Reviewed and ready for implementation

## 1. Goal

Restructure CI so that:

- `SYMENGINE_RCP_CHOICE` is the orthogonal switch for the RCP backend.
- `ci-01` tests the SymEngine C++ library only.
- `ci-02` tests `nbsymengine` only.
- `ci-03` tests `nbsymengine_compat` only.
- `ci-04` remains the leak probe and reuses a build from `ci-02`.
- Python interpreter selection moves out of `.woodpecker.yaml` and into `.ci/run-ci-steps.sh`.
- A minimal TSAN lane is added now, without pretending the `3.14td` environment can run the full Python matrix.

This document replaces the previous `17b` draft after review against the actual repository state.

## 2. Decisions Fixed by Review

The previous draft had four problems that must not be carried into implementation:

1. `ci-01` still needs nanobind headers when `SYMENGINE_RCP_CHOICE=nb_intrusive`, even if it does not build Python bindings. The core SymEngine configure step must still provide `nanobind_DIR` or `NANOBIND_INCLUDE_DIR`.
2. `/opt-3/cpython-v3.14.4-tsan` is not a normal virtualenv. Do not assume `bin/activate` or `bin/python` exists there. Use explicit executables such as `bin/python3.14` and `bin/pip3.14`.
3. Test commands must fail the job on failure. Do not wrap pytest or ctest in `|| echo "WARNING: ..."`.
4. `nbsymengine_compat/tests/converted/` is intentionally untracked. A fresh CI checkout will not contain those files, so `ci-03` must regenerate them before testing if we want converted-test coverage.

## 3. End State

Keep the current four-stage shape, but tighten the responsibilities:

- `ci-01-build-and-test.sh`
  - Configure and test only the SymEngine C++ library.
  - Build from `symengine/`, never from the superproject root.
  - Respect `SYMENGINE_RCP_CHOICE`.

- `ci-02-build-and-test-nbsymengine.sh`
  - Configure and build from the superproject root with `-DBUILD_PYTHON_NANOBIND=ON`.
  - Run only the nanobind-related CTest entries plus the pytest-only `nbsymengine` suites.
  - Do not rerun the entire SymEngine C++ test suite here.

- `ci-03-build-and-test-nbsymengine_compat.sh`
  - Consume the `nbsymengine` build from `ci-02`.
  - Regenerate `nbsymengine_compat/tests/converted/` from `symengine.py`.
  - Install and test `nbsymengine_compat`.

- `ci-04-leak-test.sh`
  - Unchanged in behavior.
  - Reuse the debug build directory produced by `ci-02`, not a special old `nb_intrusive` build.

## 4. Generated Artifact Policy

Two generated areas matter here:

### 4.1 `nbsymengine/generated/`

This is already the correct policy:

- generated files are not tracked in git
- sdists ship pre-generated files
- in-tree CI may regenerate them when requested

Do not change that policy in this task.

### 4.2 `nbsymengine_compat/tests/converted/`

This directory is also already untracked and git-ignored:

- `nbsymengine_compat/.gitignore` ignores `tests/converted/`
- `git ls-files nbsymengine_compat/tests/converted` returns nothing
- local regeneration is deterministic apart from `__pycache__/`

Therefore:

- nothing needs to be removed from version control
- ordinary CI must regenerate these files if it wants converted-test coverage
- regeneration should be part of `ci-03`, not a silent manual prerequisite

## 5. Recommended File Layout

Touch these files:

| File | Action |
|---|---|
| `.woodpecker.yaml` | Simplify to one `bash -lc ".ci/run-ci-steps.sh"` call |
| `.ci/run-ci-steps.sh` | Rewrite orchestrator |
| `.ci/ci-common.sh` | New helper for interpreter and variant setup |
| `.ci/ci-01-build-and-test.sh` | Remove `nb_intrusive` variant; add generic RCP handling and `tsan` |
| `.ci/ci-02-build-and-test-nbsymengine.sh` | New file |
| `.ci/ci-03-build-and-test-nbsymengine_compat.sh` | New file |
| `.ci/ci-04-leak-test.sh` | No functional change; only invocation target changes |
| `nbsymengine_compat/tools/regen_converted_tests.sh` | Make path detection work in the superproject checkout too |

Creating `.ci/ci-common.sh` is recommended, not optional. Without it, `ci-01` and `ci-02` will duplicate variant flags, Python selection, and `nb_intrusive` setup and will drift again.

## 6. Detailed Implementation

### 6.1 `.woodpecker.yaml`

Replace the two current Python-related lines with one line:

```yaml
- bash -lc ".ci/run-ci-steps.sh"
```

Rationale:

- interpreter selection must live in shell, not in YAML
- TSAN uses a different Python install than the default lane
- the orchestrator should be runnable locally without copying commands out of YAML

### 6.2 New `.ci/ci-common.sh`

Add a shared helper script with shell functions. Source it from `run-ci-steps.sh`, `ci-01`, `ci-02`, and `ci-03`.

Required responsibilities:

1. Resolve the default Python installation.

   Suggested exports:

   ```bash
   CI_DEFAULT_PYTHON_ROOT=/opt-3/cpython-v3.13-apt-deb
   CI_DEFAULT_PYTHON=/opt-3/cpython-v3.13-apt-deb/bin/python
   CI_DEFAULT_PIP=/opt-3/cpython-v3.13-apt-deb/bin/pip
   ```

   Use the existing wildcard resolution logic if you want, but export concrete paths once and reuse them.

2. Resolve the TSAN Python installation explicitly.

   Use:

   ```bash
   CI_TSAN_PYTHON_ROOT=/opt-3/cpython-v3.14.4-tsan
   CI_TSAN_PYTHON=/opt-3/cpython-v3.14.4-tsan/bin/python3.14
   CI_TSAN_PIP=/opt-3/cpython-v3.14.4-tsan/bin/pip3.14
   ```

3. Provide one function to export compiler flags for a given `SYMENGINE_VARIANT`.

   It should cover at least:

   - `debug`
   - `glibcxxdbg`
   - `tsan`
   - existing commented-out variants may stay supported but disabled by the orchestrator

4. Provide one function to apply `SYMENGINE_RCP_CHOICE`.

   For `nb_intrusive`, it must:

   - remove legacy `-DWITH_SYMENGINE_RCP=ON` from `CMAKE_ARGS` if present
   - append `-DSYMENGINE_RCP_BACKEND=nb_intrusive`
   - ensure nanobind headers are discoverable

5. Provide one function to select the active Python toolchain for a lane.

   Example interface:

   ```bash
   ci_use_python_toolchain default
   ci_use_python_toolchain tsan
   ```

   That function should export:

   - `CI_PYTHON_ROOT`
   - `CI_PYTHON`
   - `CI_PIP`

Do not rely on shell activation for correctness. Activation may still be used for convenience in the default lane, but the actual scripts must use explicit executables and explicit CMake Python arguments.

### 6.3 `.ci/run-ci-steps.sh`

Rewrite this as the single orchestrator.

#### Required behavior

1. Source `.ci/ci-common.sh`
2. Export:

   ```bash
   SYMENGINE_RCP_CHOICE=nb_intrusive
   LIBCXX_ASAN_ROOT=...
   LIBCXX_MSAN_ROOT=...
   ```

3. Prepare the default Python lane:

   - select the default toolchain
   - install baseline Python tooling needed by CI:
     - `munch`
     - `srcml_caller`
     - `libcst`
     - `nanobind`

4. Prepare the TSAN Python lane:

   - select the TSAN toolchain
   - install `nanobind`
   - do **not** attempt to install `numpy`, `scipy`, or `sympy` yet

5. Execute stages in this order:

   - default Python:
     - `ci-01` for `debug`
     - `ci-01` for `glibcxxdbg`
     - `ci-02` for `debug`
     - `ci-03` using the `ci-02` debug build
     - `ci-02` for `glibcxxdbg`
     - optional later: `ci-03` for `glibcxxdbg` if runtime cost is acceptable
     - `ci-04` using the `ci-02` debug build
   - TSAN Python:
     - `ci-01` for `tsan`
     - `ci-02` for `tsan`
     - skip `ci-03` for now

#### Important scope choice

Run `ci-03` only on the debug build initially.

Reason:

- it exercises the compat layer once per pipeline
- it avoids doubling a large pytest matrix for little extra signal
- the TSAN lane is intentionally minimal for now

#### Suggested build directories

Use distinct directories to avoid stale CMake cache pollution:

- `/tmp/bld-se-debug`
- `/tmp/bld-se-glibcxxdbg`
- `/tmp/bld-nbse-debug`
- `/tmp/bld-nbse-glibcxxdbg`
- `/tmp/bld-se-tsan`
- `/tmp/bld-nbse-tsan`

### 6.4 `.ci/ci-01-build-and-test.sh`

This script becomes "SymEngine core only".

#### Changes to make

1. Delete the `nb_intrusive)` case from the `SYMENGINE_VARIANT` switch.
2. Delete the special `if [[ $SYMENGINE_VARIANT == nb_intrusive ]]` block that switched the CMake source directory to the superproject root.
3. Delete the optional pytest block at the end. That belongs in later stages.
4. Add a `tsan` variant.
5. After the variant switch, call the shared helper that applies `SYMENGINE_RCP_CHOICE`.
6. Always configure with:

   ```bash
   -S "$SYMENGINE_SRC"
   ```

7. Keep the CTest behavior variant-specific:

   - `asan`: keep existing exclusions
   - `msan`: keep existing restricted target
   - `release`: keep valgrind behavior if that lane is later re-enabled
   - `debug`, `glibcxxdbg`, `tsan`: `ctest --output-on-failure -E "test_parser"`

#### Important `nb_intrusive` note

Even in `ci-01`, `nb_intrusive` needs nanobind headers. The helper should therefore export one of:

- `NB_CMAKE_DIR`
- `NANOBIND_INCLUDE_DIR`

and `ci-01` must pass it into CMake when `SYMENGINE_RCP_CHOICE=nb_intrusive`.

This is required because `symengine/CMakeLists.txt` validates nanobind header availability for the `nb_intrusive` backend during core-library configure time.

### 6.5 New `.ci/ci-02-build-and-test-nbsymengine.sh`

This script owns the `nbsymengine` stage.

#### Inputs

- argument 1: build directory
- environment:
  - `SYMENGINE_VARIANT`
  - `SYMENGINE_RCP_CHOICE`
  - active `CI_PYTHON_ROOT`, `CI_PYTHON`, `CI_PIP`

#### Responsibilities

1. Fail unless `SYMENGINE_RCP_CHOICE=nb_intrusive`
2. Build from the superproject root:

   ```bash
   -S "$SUPERPROJECT_ROOT"
   -DBUILD_PYTHON_NANOBIND=ON
   -DSYMENGINE_RCP_BACKEND=nb_intrusive
   -Dnanobind_DIR=...
   -DPython_EXECUTABLE="$CI_PYTHON"
   -DPython_ROOT_DIR="$CI_PYTHON_ROOT"
   ```

3. Reuse the shared variant-flag helper from `.ci/ci-common.sh`
4. Run only the nanobind CTest entries

#### CTest selection

For normal lanes, use:

```bash
ctest --output-on-failure -R '^nanobind_'
```

Do not run plain `ctest --output-on-failure -E "test_parser"` here. That would rerun the entire SymEngine C++ test suite and defeat the point of the split.

#### Extra pytest-only coverage

After CTest:

- for `debug` and `glibcxxdbg`:
  - run `nbsymengine/tests/test_lambdify_direct.py`
  - run `benchmarks/tests/` if the directory exists
- for `tsan`:
  - keep this lane minimal
  - run only a small explicit subset, for example:

    ```bash
    ctest --output-on-failure -R '^nanobind_(nbsymengine_import|ownership|generated_smoke|generated_rcp|threading_stress)$'
    ```

  - do not run `test_lambdify_direct.py`
  - do not run `benchmarks/tests/`

Choose one approach and document it in the script comment. The important part is that the TSAN lane stays intentionally small until the `3.14td` environment has the broader dependency set installed.

### 6.6 New `.ci/ci-03-build-and-test-nbsymengine_compat.sh`

This script owns the compat stage.

#### Inputs

- argument 1: the `nbsymengine` build directory from `ci-02`
- default Python lane only for now

#### Responsibilities

1. Export `PYTHONPATH` so the built `nbsymengine` package from `ci-02` is importable
2. Install compat package and test extras
3. Regenerate converted tests from the top-level `symengine.py` checkout
4. Run the compat test suite

#### Regeneration behavior

This stage should regenerate converted tests every time.

Use the top-level legacy tests source:

```bash
TESTS_DIR="${SUPERPROJECT_ROOT}/symengine.py/symengine/tests"
OUT_DIR="${COMPAT_DIR}/tests/converted"
SHIM_PATH="${COMPAT_DIR}/src/nbsymengine_compat/symengine_py_compat.py"
```

Then run:

```bash
bash "${COMPAT_DIR}/tools/regen_converted_tests.sh"
```

This should be a required step, not a best-effort warning-only step.

Reason:

- `tests/converted/` is untracked
- CI should exercise the real conversion output, not stale local files
- local testing showed the regeneration is deterministic

#### Test command

Run:

```bash
python -m pytest -x "${COMPAT_DIR}/tests/" --tb=short -q
```

Do not swallow failures.

### 6.7 `nbsymengine_compat/tools/regen_converted_tests.sh`

Update path detection so the tool works in both contexts:

1. standalone `nbsymengine_compat` checkout with nested `external/symengine.py`
2. this superproject checkout with top-level `../symengine.py`

Recommended fallback order for `TESTS_DIR` if the caller did not set it:

1. `${REPO_ROOT}/external/symengine.py/symengine/tests`
2. `${REPO_ROOT}/../symengine.py/symengine/tests`

If neither exists, fail with a clear error.

This change keeps the tool usable both inside the compat repo and from the superproject CI.

### 6.8 `.ci/ci-04-leak-test.sh`

No script change is required unless it bakes in old build-directory names elsewhere.

What changes is the caller:

- use the debug `ci-02` build directory
- example:

  ```bash
  .ci/ci-04-leak-test.sh /tmp/bld-nbse-debug
  ```

This is correct because the leak probe imports `symengine_manual_ext`, which is built by the nanobind build in `ci-02`, not by the new slimmed-down `ci-01`.

## 7. Implementation Order

Do the work in this order:

1. Create `.ci/ci-common.sh`
2. Rewrite `.ci/run-ci-steps.sh`
3. Refactor `.ci/ci-01-build-and-test.sh`
4. Add `.ci/ci-02-build-and-test-nbsymengine.sh`
5. Add `.ci/ci-03-build-and-test-nbsymengine_compat.sh`
6. Update `nbsymengine_compat/tools/regen_converted_tests.sh`
7. Simplify `.woodpecker.yaml`
8. Verify `ci-04` is called with the correct build directory

This order minimizes time spent debugging scripts that still depend on the old execution model.

## 8. Verification Plan

### 8.1 Local script-level checks

Run these in order:

```bash
. .ci/ci-common.sh
ci_use_python_toolchain default
.ci/ci-01-build-and-test.sh /tmp/bld-se-debug /tmp/symen-debug
.ci/ci-02-build-and-test-nbsymengine.sh /tmp/bld-nbse-debug
.ci/ci-03-build-and-test-nbsymengine_compat.sh /tmp/bld-nbse-debug
.ci/ci-04-leak-test.sh /tmp/bld-nbse-debug
```

### 8.2 TSAN checks

Run only the intended minimal subset:

```bash
. .ci/ci-common.sh
ci_use_python_toolchain tsan
"$CI_PIP" install nanobind
env SYMENGINE_VARIANT=tsan .ci/ci-01-build-and-test.sh /tmp/bld-se-tsan /tmp/symen-tsan
env SYMENGINE_VARIANT=tsan .ci/ci-02-build-and-test-nbsymengine.sh /tmp/bld-nbse-tsan
```

Do not add `ci-03` TSAN coverage in this task.

### 8.3 Full orchestrator

Finally run:

```bash
bash .ci/run-ci-steps.sh
```

## 9. Non-Goals

This task does **not** attempt to:

- fix or re-enable `asan`
- fix or re-enable `msan`
- widen TSAN Python coverage beyond the minimal lane
- change the `nbsymengine/generated/` packaging policy
- redesign the converted-test tooling beyond making it work in the superproject CI

## 10. Notes for the Implementer

- There is a pre-existing mangled `elif [[ $SYMENGINE_VARIANT == nb_intrusive ]]` block near the external-download path in `ci-01-build-and-test.sh`. Remove that dead code while doing the refactor; it is unrelated to the intended control flow.
- Use explicit Python executables in scripts and explicit CMake Python arguments. This matters most for the `3.14td` TSAN build.
- Keep `SYMENGINE_RCP_CHOICE` future-proof, but only `nb_intrusive` needs to be wired through CI in this task.
- Prefer failing early with clear messages over falling through to partial test coverage.
