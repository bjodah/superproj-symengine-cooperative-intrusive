# 12b — Implementation Plan: Stabilize the nbsymengine Refactor

This plan addresses the gaps found in the recent `nbsymengine` deduplication refactor:

1. the new shared header is not yet safe for source-distribution packaging
2. the new shutdown test is not wired into the normal `ctest`/CI path
3. the new equality tests do not actually verify the intended `Basic.__eq__` contract

It also answers the structural question of whether `nbsymengine/src/` should be reduced to a single `.cpp` file.

---

## 1. Executive Decision

### Keep two extension modules and two entry-point `.cpp` files

The project should **not** collapse [core_module.cpp](file:///work/nbsymengine/src/core_module.cpp) and the test-only ownership module source into a single module or a single entry-point source file as part of this work.

That is the right decision for three reasons:

1. **They are different Python extension modules.**
   * `_core` is the real package extension used by `nbsymengine`
   * `symengine_manual_ext` is a separate test-only ownership-validation module with its own import name, CMake target, and dedicated tests

2. **The minimal manual module has value as an isolation harness.**
   It proves that direct `RCP<const Basic>` ownership and shutdown behavior work without depending on the far larger `_core` surface or generated bindings.

3. **A single `.cpp` file would not actually remove the architectural split.**
   Even if both targets were made to compile the same file with preprocessor switches, the build would still need:
   * two extension targets
   * two `NB_MODULE(...)` entry points
   * two test/import paths
   * two independently verifiable module lifecycles

That would trade a clear separation for macro-heavy build plumbing without removing a meaningful concept from the system.

### What *is* worth doing

Keep the two entry-point `.cpp` files, but keep shrinking the duplicated scaffolding behind shared helpers. That preserves the test harness while reducing maintenance drift.

As part of that cleanup, rename `manual_module.cpp` to `rcp_ownership_test_module.cpp`. That is a good clarity improvement because the current filename underspecifies its role.

---

## 2. Scope

This plan covers:

* packaging and source-distribution correctness for the new shared helper header
* CI/CTest integration for shutdown smoke tests
* direct semantic verification of `Basic.__eq__`
* small cleanup of stale comments/tests introduced by the refactor
* renaming the test-only extension source file for clarity

This plan does **not** cover:

* removing `symengine_manual_ext`
* folding its tests into `_core`
* changing the public package import layout
* redesigning nanobind ownership semantics

---

## 3. Current Problems

### A. Source-distribution breakage risk

The refactor introduced a new shared header, currently [src/module_common.h](file:///work/nbsymengine/src/module_common.h), and both module sources include it.

However:

* [make_sdist.sh](file:///work/nbsymengine/scripts/make_sdist.sh) currently copies `src/*.cpp` but not `src/*.h`
* the staged sdist therefore omits the new header
* standalone/sdist installs will fail at compile time when `core_module.cpp` or the test-only ownership module source includes that header

There is a second practical problem: if the header is not tracked in git, the `git archive HEAD` export step in `make_sdist.sh` will omit it even before the staging copy logic runs.

### B. Shutdown regression test not enforced by automation

[test_singleton_shutdown.py](file:///work/nbsymengine/tests/test_singleton_shutdown.py) now includes the new `symengine_manual_ext` subprocess exit test, but [CMakeLists.txt](file:///work/nbsymengine/CMakeLists.txt) does not register that file with `add_test(...)`.

That means:

* `ctest` does not run it
* the superproject CI path that runs `ctest` does not run it
* the most important regression guard for this refactor is currently opt-in only

### C. `Basic.__eq__` tests verify final operator results, not direct method behavior

The new tests in [test_core_bindings.py](file:///work/nbsymengine/tests/test_core_bindings.py) assert that expressions like `x == "hello"` evaluate to `False`.

That is insufficient to verify the intended contract. Those assertions pass in both cases:

* `Basic.__eq__` returns `NotImplemented`, and Python falls back correctly
* `Basic.__eq__` returns `False` directly

Because the refactor explicitly standardized the direct `__eq__` implementation, the tests must exercise the special method itself.

---

## 4. Design Adjustment

### A. Move the shared header to `support/`

The cleanest fix is to move the shared helper header out of `src/` and into the existing shared-header area:

* recommended path: [support/nanobind_module_common.h](file:///work/nbsymengine/support/nanobind_module_common.h)

This is better than keeping it in `src/` because:

* `support/` already holds shared nanobind/SymEngine headers
* `CMakeLists.txt` already adds `support/` to the include path for both targets
* [make_sdist.sh](file:///work/nbsymengine/scripts/make_sdist.sh) already stages `support/*.h`
* the file’s role is shared support infrastructure, not a translation unit

### B. Make sdist staging more robust anyway

Even after moving the header, the sdist script should be slightly hardened:

* continue copying `support/*.h`
* optionally also copy `src/*.h` if any exist, so future header additions in `src/` do not silently break sdists again

This is a small defensive improvement and worth doing even if the current header is relocated.

### C. Keep the module split explicit

The current structure should remain:

* [core_module.cpp](file:///work/nbsymengine/src/core_module.cpp): full `_core` module
* `rcp_ownership_test_module.cpp`: minimal ownership/shutdown validation module backing `symengine_manual_ext`
* shared helpers in `support/`

That preserves the value of the manual test harness without duplicating low-level scaffolding.

---

## 5. Concrete Implementation Steps

### Phase 1: Packaging and Header Hygiene

#### Step 1.0: Rename the test-only module source file for clarity

Rename:

* `nbsymengine/src/manual_module.cpp`

to:

* `nbsymengine/src/rcp_ownership_test_module.cpp`

and update all direct references in:

* [nbsymengine/CMakeLists.txt](file:///work/nbsymengine/CMakeLists.txt)
* any docs that mention the old filename

This rename is intentionally limited to the source filename. It does **not** rename:

* the CMake target `symengine_manual_ext`
* the Python import name `symengine_manual_ext`
* the test file names

That keeps the change low-risk while improving codebase readability.

#### Step 1.1: Relocate and rename the shared helper header

Move:

* `nbsymengine/src/module_common.h`

to:

* `nbsymengine/support/nanobind_module_common.h`

and update includes in:

* [core_module.cpp](file:///work/nbsymengine/src/core_module.cpp)
* `rcp_ownership_test_module.cpp`

Benefits:

* matches the file’s purpose
* avoids sdist breakage through existing `support/*.h` staging
* makes the header’s role clearer than the generic name `module_common.h`

#### Step 1.2: Ensure the header is tracked in git

Before considering this work complete:

* verify the new header is no longer untracked in `git status`
* verify it is included by `git archive HEAD`

This is mandatory because the sdist workflow is archive-based.

#### Step 1.3: Harden `make_sdist.sh`

Update [make_sdist.sh](file:///work/nbsymengine/scripts/make_sdist.sh) so the staged sdist includes all required extension-support headers.

Recommended changes:

1. keep copying `support/*.h` and `support/*.cpp`
2. add a guarded copy of `src/*.h` if any are present
3. extend the validation section so missing support headers fail the script early

Suggested validation ideas:

* assert the staged sdist contains `support/nanobind_symengine.h`
* assert the staged sdist contains `support/nanobind_module_common.h`

#### Step 1.4: Update docs if needed

If any docs explicitly describe tracked hand-written sources, update them to mention the shared support header if useful, especially:

* [docs/ROLLOUT.md](file:///work/nbsymengine/docs/ROLLOUT.md)

This is lower priority than the code and packaging fixes, but it prevents drift.

---

### Phase 2: Wire Shutdown Smoke Tests into CTest and CI

#### Step 2.1: Register `test_singleton_shutdown.py` in `CMakeLists.txt`

Add a dedicated CTest entry, for example:

* `nanobind_singleton_shutdown`

using [test_singleton_shutdown.py](file:///work/nbsymengine/tests/test_singleton_shutdown.py).

#### Step 2.2: Set the correct `PYTHONPATH`

This test file exercises both:

* `nbsymengine._core`
* `symengine_manual_ext`

So its `ENVIRONMENT` should include both locations:

* `${CMAKE_BINARY_DIR}` for `nbsymengine`
* `$<TARGET_FILE_DIR:symengine_manual_ext>` for the standalone manual module

This should mirror the environment already used for [test_singleton_leaks.py](file:///work/nbsymengine/tests/test_singleton_leaks.py), with the addition that `_core` must also be importable.

#### Step 2.3: Confirm it is picked up by the normal CI path

The superproject CI runs `ctest` in the `nb_intrusive` branch, so once the test is registered no CI script change should be required.

Still, verify that:

* `ctest -N` lists the new test
* `ctest --output-on-failure -R nanobind_singleton_shutdown` executes it successfully

---

### Phase 3: Make `Basic.__eq__` Tests Semantically Correct

#### Step 3.1: Strengthen `_core` tests

In [test_core_bindings.py](file:///work/nbsymengine/tests/test_core_bindings.py), add direct-method tests that distinguish these cases:

1. `_core.Basic.__eq__(x, "hello") is NotImplemented`
2. `_core.Basic.__eq__(x, 42) is NotImplemented`
3. `_core.Basic.__eq__(x, None) is False`
4. `_core.Basic.__eq__(x, x) is True`
5. `_core.Basic.__eq__(x, y) is False`

Retain operator-level tests like `x == "hello"` as secondary checks for user-visible behavior, but do not rely on them to prove the special method contract.

#### Step 3.2: Add matching direct-method tests for `symengine_manual_ext`

In [test_manual_ownership.py](file:///work/nbsymengine/tests/test_manual_ownership.py), add the same direct-method assertions against `m.Basic.__eq__`.

That matters because the shared binder is now used by both modules, and the plan explicitly standardized the manual module’s behavior.

#### Step 3.3: Audit stale comments and assumptions

Review existing comments in:

* [test_generated_rcp.py](file:///work/nbsymengine/tests/test_generated_rcp.py)
* [test_manual_ownership.py](file:///work/nbsymengine/tests/test_manual_ownership.py)
* [test_core_bindings.py](file:///work/nbsymengine/tests/test_core_bindings.py)

and update wording that conflates:

* direct `__eq__` return value
* final `==` expression result after Python fallback

The code behavior may be correct already, but the comments should stop encoding the wrong proof obligation.

---

### Phase 4: End-to-End Verification of the Packaging Path

This phase is mandatory because the highest-severity issue is in the sdist path.

#### Step 4.1: Rebuild locally

Run:

```bash
cmake --build /work/build
```

or the actual active build directory for the `nb_intrusive` configuration.

#### Step 4.2: Run focused pytest suites

Run:

```bash
pytest /work/nbsymengine/tests/test_manual_ownership.py
pytest /work/nbsymengine/tests/test_core_bindings.py
pytest /work/nbsymengine/tests/test_singleton_shutdown.py
pytest /work/nbsymengine/tests/test_singleton_leaks.py
```

#### Step 4.3: Verify CTest registration

Run:

```bash
ctest -N --test-dir /work/build/nbsymengine
ctest --output-on-failure -R nanobind_singleton_shutdown --test-dir /work/build/nbsymengine
```

Success means the shutdown test is present in the normal CTest graph.

#### Step 4.4: Exercise the sdist workflow

Run:

```bash
bash /work/nbsymengine/scripts/make_sdist.sh /tmp/nbsymengine-sdist-check
tar -tzf /tmp/nbsymengine-sdist-check.tar.gz | rg 'nanobind_module_common\\.h|module_common\\.h|nanobind_symengine\\.h'
```

At minimum, confirm the tarball contains the shared helper header in the expected location.

#### Step 4.5: Validate an install from the produced sdist

The strongest check is a clean install from the generated tarball, for example in a disposable virtual environment:

```bash
python -m venv /tmp/nbsymengine-sdist-venv
source /tmp/nbsymengine-sdist-venv/bin/activate
pip install /tmp/nbsymengine-sdist-check.tar.gz
python -c "from nbsymengine import _core; print(_core.pi())"
```

This is the acceptance test for the packaging fix. Without it, the main regression is only theoretically addressed.

---

## 6. File-Level Change List

The expected implementation touches these files:

### Required

* [nbsymengine/src/core_module.cpp](file:///work/nbsymengine/src/core_module.cpp)
* `nbsymengine/src/rcp_ownership_test_module.cpp`
* [nbsymengine/CMakeLists.txt](file:///work/nbsymengine/CMakeLists.txt)
* [nbsymengine/scripts/make_sdist.sh](file:///work/nbsymengine/scripts/make_sdist.sh)
* [nbsymengine/tests/test_core_bindings.py](file:///work/nbsymengine/tests/test_core_bindings.py)
* [nbsymengine/tests/test_manual_ownership.py](file:///work/nbsymengine/tests/test_manual_ownership.py)

### New or moved shared header

* [nbsymengine/support/nanobind_module_common.h](file:///work/nbsymengine/support/nanobind_module_common.h)

### Likely cleanup

* [nbsymengine/tests/test_generated_rcp.py](file:///work/nbsymengine/tests/test_generated_rcp.py)
* [nbsymengine/docs/ROLLOUT.md](file:///work/nbsymengine/docs/ROLLOUT.md)

---

## 7. Acceptance Criteria

This refactor is complete only when all of the following are true:

1. the shared helper header is tracked in git
2. the sdist tarball contains that header
3. `pip install <generated-sdist.tar.gz>` succeeds
4. `ctest -N` lists a shutdown smoke test entry
5. that CTest entry passes with the normal test environment
6. direct-method tests prove `_core.Basic.__eq__(x, unsupported)` returns `NotImplemented`
7. direct-method tests prove `symengine_manual_ext.Basic.__eq__(x, unsupported)` returns `NotImplemented`
8. operator-level behavior remains user-friendly: `x == "hello"` still evaluates to `False`

---

## 8. Deferred Work: When a Single Module Would Make Sense

Removing `symengine_manual_ext` entirely would be a **different** project. It would only be justified after proving that:

1. all ownership, leak, and shutdown coverage provided by the manual module is reproduced against `_core`
2. the smaller isolation harness is no longer valuable for debugging
3. deleting the separate CMake target and import path does not reduce test clarity

That is a decommissioning effort, not a follow-up to this bug-fix plan. It should not be mixed into the current stabilization work.
