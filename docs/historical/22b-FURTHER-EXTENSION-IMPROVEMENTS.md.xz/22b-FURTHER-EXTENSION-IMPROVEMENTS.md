# 22b - Further Extension Improvements

## What Was Done

- Added `docs/reports/22a-CROSS-RUNTIME-OWNERSHIP-MATRIX.md` and linked it from the plan
- Added PHP ownership tests:
  - `symengine.php/tests/025-canonical-identity-reuse.phpt`
  - `symengine.php/tests/035-debug-helpers.phpt`
  - `symengine.php/tests/045-expression-pins-operand.phpt`
  - `symengine.php/tests/065-loop-teardown.phpt`
- Added timeout-based subprocess support in `symengine.php/tests/support/subprocess.php`
- Updated `050-singleton-teardown.phpt` and `060-expression-teardown.phpt` to use the helper
- Banned direct construction of `SymEngine\Basic`, `SymEngine\Integer`, and `SymEngine\Symbol`
- Added `symengine_sub`, `symengine_div`, and `symengine_neg` to the PHP extension
- Extended `symengine.php/tests/010-basic-ops.phpt` for the new PHP surface
- Added the core C++ regression test `detach external and replay inline references`
- Fixed clean PHP extension builds against fresh `boostmp` SymEngine installs by adding Boost includes in `symengine.php/config.m4`
- Added and ran `symengine.php/tools/fpm-smoke.sh` for FPM validation
- Fixed debug ownership helper exposure so it is controlled by `SYMENGINE_PHP_DEBUG_HELPERS`, not PHP's own `NDEBUG`
- Wrote supporting reports:
  - `docs/reports/22b-PHP-SAPI-LIFECYCLE.md`
  - `docs/reports/22c-COOPERATIVE-INTRUSIVE-CROSS-RUNTIME.md`
  - `docs/reports/22d-UPSTREAM-READINESS.md`

## Verification Performed

- Clean SymEngine debug build and core tests:

```bash
SYMENGINE_RCP_CHOICE=cooperative_intrusive SYMENGINE_VARIANT=debug \
  .ci/ci-01-build-and-test.sh /tmp/se-php-plan-build /tmp/se-php-plan-install
```

- Clean PHP extension build and PHPT suite:

```bash
SYMENGINE_VARIANT=debug \
  .ci/ci-06-build-and-test-php.sh \
  /tmp/se-php-plan-build \
  /tmp/se-php-plan-install \
  /tmp/se-php-ext-plan
```

- Perl reference lane:

```bash
SYMENGINE_VARIANT=debug \
  .ci/ci-05-build-and-test-perl.sh /tmp/se-perl-plan-build
```

Observed result:

- `test_cooperative_intrusive_rcp` passed with the new detach/replay case
- all 12 PHP PHPTs passed from the clean build tree
- `perl_symengine` passed
- FPM smoke passed on PHP-FPM 8.4.21 with three requests handled by the same worker

## Deferred Or Unverified

- Apache module validation remains unverified
- A true ASAN PHP lane is still deferred

## Potential Future Improvements

See `docs/plans/23-FOLLOW-UP-EXTENSION-HARDENING.md`.
