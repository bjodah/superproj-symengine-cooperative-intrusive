# 21 - Next Steps: PHP Extension

**Date:** 2026-06-17
**Status:** Proposed

## Summary

The initial PHP prototype in `/work/symengine.php/` now demonstrates the core
viability point for `cooperative_intrusive`: a SymEngine `Basic` can be
externalized to a PHP-owned wrapper whose `zend_object` participates directly in
 the shared refcount story. The next work is not broad API expansion yet. The
priority is to harden lifetime correctness, add focused tests, and reduce the
prototype into something trustworthy enough to compare against the Perl and
Python integrations.

This plan treats the PHP extension as a runtime-lifetime validation project for
the upstream SymEngine backend first, and only secondarily as a user-facing PHP
binding.

## Current State

What exists today:

- sibling prototype repo at `/work/symengine.php/`
- configure-time check that SymEngine was built with
  `SYMENGINE_RCP_BACKEND=cooperative_intrusive`
- cooperative hooks wired to PHP object refcount operations
- raw-pointer wrapper model matching the Perl design
- identity reuse via `self_external()`
- singleton reconciliation sketch using `detach_external()` plus `inc_ref()`
- basic smoke-tested API for constants, `integer`, `symbol`, `add`, `mul`,
  `pow`, `str`, and `eq`

What is still weak or incomplete:

- no committed PHP test suite yet
- shutdown behavior is only lightly validated
- no explicit coverage for request shutdown vs module shutdown semantics
- no stress testing for wrappers kept alive only by C++ references
- no CI wiring
- no decision yet on long-term repository shape or upstreaming path

## Goals

The next phase should produce these outcomes:

1. Prove the shared-refcounted ownership model is correct under realistic PHP
   lifecycle scenarios.
2. Reduce the chance that PHP-specific bugs are mistaken for backend bugs in
   `cooperative_intrusive`.
3. Establish a compact test harness that can be rerun locally and in CI.
4. Keep the PHP surface minimal until lifetime, teardown, and identity behavior
   are well understood.
5. Make the results comparable to the existing Perl extension work so the same
   arguments can support an upstream SymEngine PR.

## Non-Goals

For this phase, do not prioritize:

- large API coverage
- automatic code generation
- ergonomic PHP OO design beyond a minimal proof surface
- Windows support
- packaging for PECL or distribution repositories

## Workstreams

## 1. Harden Lifetime Semantics

This is the highest-priority workstream.

### Objectives

- confirm that every object path obeys the intended ownership contract
- remove shutdown hangs, leaks, refcount underflows, and duplicate wrapper bugs
- document the exact invariants in code comments and tests

### Required checks

1. Wrapper creation:
   - wrapping a fresh C++ object externalizes exactly once
   - wrapping an already external-owned object reuses the existing PHP object
   - no path ever calls `set_self_external()` twice for the same object
2. Wrapper destruction:
   - non-singleton objects are deleted when the final PHP/C++ reference is gone
   - objects detached back to inline mode are not deleted by PHP wrapper teardown
3. Unwrap / temporary C++ handles:
   - `rcp(ptr)` temporarily pins the wrapper via cooperative incref
   - temporary `RCP` construction and destruction cannot resurrect or prematurely
     destroy the wrapper
4. Singleton behavior:
   - singletons externalized during runtime are detached back to inline mode at
     shutdown
   - replayed inline counts match the live PHP object refcount at teardown
5. Shutdown flag behavior:
   - hooks become inert only after the runtime can no longer safely touch PHP
     objects
   - the inert period does not start too early and hide real lifetime bugs

### Implementation tasks

- review whether singleton reconciliation belongs in `RSHUTDOWN`, `MSHUTDOWN`,
  or both, with explicit CLI/FPM reasoning
- decide whether the current global `g_php_destructing` flag is sufficient or if
  it needs finer-grained state
- add debug-only assertions around:
  - `self_external()` transitions
  - unexpected null native pointers
  - wrapper class selection mismatches
- add a small helper for describing wrapper state in debug logs

## 2. Add Focused PHP Tests

The extension now needs a real regression suite before more code lands.

### Test directory

Create tests under `/work/symengine.php/tests/`.

### First-wave tests

1. `001-load.phpt`
   - extension loads
   - version/info smoke test
2. `010-basic-ops.phpt`
   - `integer`, `symbol`, `add`, `mul`, `pow`, `str`, `eq`
   - expected string results for small expressions
3. `020-identity-reuse.phpt`
   - repeated wrapping of the same singleton returns the same PHP object
   - `sameObject()` returns true where expected
4. `030-external-ownership.phpt`
   - `isExternalOwned()` becomes true after wrapping
   - `phpRefCount()` behaves predictably for copied PHP references
5. `040-temporary-cpp-handles.phpt`
   - operations that rebuild temporary `RCP` handles do not break ownership
6. `050-singleton-teardown.php`
   - subprocess-based shutdown test holding live singleton wrappers until exit
   - assert clean exit, no hang, no crash
7. `060-expression-teardown.php`
   - subprocess-based shutdown test for non-singleton expressions retained in
     locals and arrays until exit

### Test style

- prefer `phpt` for normal runtime assertions
- prefer subprocess-driven `.php` tests for teardown cases where process exit is
  part of the test
- keep tests tiny and ownership-focused; avoid broad symbolic-math coverage at
  this stage

## 3. Add Native-Lifetime Stress Tests

PHP-level tests are necessary but not sufficient. Add a small amount of targeted
native-side instrumentation to flush out cross-runtime bugs.

### Proposed debug helpers

Expose these only in debug builds or behind an extension env flag:

- `cppUseCount()` on `Basic`
- `externalOwnerAddress()` or stringified external-owner state
- maybe `isSingletonSeeded()` for selected constants

### Why

- `use_count()` is expected to be `0` while external-owned, which is easy to
  misread without explicit tests
- debugging teardown requires visibility into whether objects are still external
  or have been detached back to inline mode

## 4. Clarify Shutdown Model by SAPI

The current prototype is CLI-smoke-tested only. The next step is to document and
then verify the intended behavior for different PHP lifecycles.

### Questions to settle

1. In CLI, is `RSHUTDOWN` sufficient for singleton reconciliation, or should the
   extension reconcile only in `MSHUTDOWN`?
2. In FPM/Apache module modes, can a singleton wrapper survive beyond a single
   request through module-level state, preload, or extension globals?
3. What ordering guarantees exist between object destruction, request shutdown,
   and module shutdown that are relevant to cooperative hooks?
4. Are there Zend shutdown phases analogous to the Perl `PL_phase` guard that
   should be checked explicitly?

### Deliverable

Add a short runtime-lifecycle note, either in `symengine.php/README.md` or a new
doc under `docs/`, that states which shutdown phases are relied upon and why.

## 5. Clean the Prototype Repo Shape

The current `symengine.php/` tree contains generated build artifacts because the
prototype was built in place. Before this grows, make the repository easier to
review.

### Tasks

- add a `.gitignore` for generated PHP extension build files
- decide which files are source-of-truth:
  - `config.m4`
  - `src/*.cpp`
  - tests
  - minimal README
- remove or avoid committing generated files such as:
  - `Makefile`
  - `configure`
  - `config.log`
  - `.libs/`
  - `modules/*.so`
  - `autom4te.cache/`

### Rationale

The prototype is currently harder to review than necessary. Cleaning this up is
low risk and makes future diffs much more legible.

## 6. Add CI Validation

Once the first ownership tests exist, wire a minimal CI path so regressions are
caught automatically.

### Minimum CI scope

- build SymEngine with `SYMENGINE_RCP_BACKEND=cooperative_intrusive`
- build the PHP extension with `phpize`
- run the targeted PHP tests

### Nice-to-have follow-up

- ASAN-enabled build for the extension and SymEngine
- timeout guard around shutdown tests
- matrix job that runs both Perl and PHP cooperative tests, to show that the
  backend supports more than one foreign refcounted runtime

## 7. Decide the Upstreaming Story

Before expanding surface area much further, decide what should eventually move
upstream and what should remain project-local.

### Likely split

Keep project-local:

- the PHP extension prototype itself
- PHP-specific tests and docs
- any exploratory debug hooks not needed by other runtimes

Candidate upstream material:

- backend bug fixes discovered while validating PHP
- generic documentation improvements to `cooperative_intrusive`
- new core tests in SymEngine that reproduce foreign-runtime ownership edge
  cases without depending on PHP

### Required evidence before upstream discussion

- PHP and Perl both exercise the same generic backend successfully
- no backend-specific crashes or shutdown leaks under targeted tests
- clear statement of which remaining issues are PHP integration details rather
  than SymEngine core problems

## Milestones

### Milestone A: Ownership Regression Suite

Deliverables:

- source tree cleaned up
- first-wave PHP tests committed
- repeated local pass of load/basic/identity/external-ownership tests

Success criteria:

- no crashes
- no hangs
- identity reuse is stable

### Milestone B: Teardown Confidence

Deliverables:

- subprocess shutdown tests for singletons and regular expressions
- documented shutdown strategy by SAPI

Success criteria:

- clean CLI exit for representative teardown scenarios
- no evidence of double-free or leaked external ownership during shutdown

### Milestone C: CI and Comparison With Perl

Deliverables:

- CI job building and testing PHP extension
- short comparison note against the Perl extension design

Success criteria:

- PHP and Perl both validate the same ownership story
- any remaining differences are documented and explained

## Recommended Execution Order

1. Clean `symengine.php/` source vs generated files.
2. Add the first-wave PHP tests.
3. Rework and verify shutdown placement (`RSHUTDOWN` vs `MSHUTDOWN`).
4. Add subprocess teardown tests.
5. Add debug-only lifetime introspection if needed to resolve failures.
6. Wire the minimal CI job.
7. Write the PHP vs Perl comparison note and summarize backend implications.

## Risks

### Zend shutdown ordering is trickier than the prototype assumes

Impact:

- hangs or leaks may appear only at process exit

Mitigation:

- prefer subprocess teardown tests early
- keep hooks inert only in the narrowest necessary shutdown window

### Singleton replay count may be subtly wrong

Impact:

- singletons can leak or be destroyed too early

Mitigation:

- add targeted tests that hold multiple PHP references to wrapped singletons
- compare behavior directly with the Perl implementation

### Broader API work could hide ownership bugs

Impact:

- more code without more confidence

Mitigation:

- keep API growth intentionally slow until Milestone B is complete

## Definition of Done for This Phase

This phase is complete when:

- the PHP extension has a committed ownership-focused test suite
- shutdown behavior is documented and tested under CLI at minimum
- the prototype repo is clean enough for review
- CI can build and run the PHP ownership tests
- we can state, with evidence, whether PHP strengthens the case for the upstream
  `cooperative_intrusive` PR

## Immediate Next Task

Implement `symengine.php/tests/` with the first-wave ownership tests and clean
the source tree so generated artifacts are not part of future review noise.
