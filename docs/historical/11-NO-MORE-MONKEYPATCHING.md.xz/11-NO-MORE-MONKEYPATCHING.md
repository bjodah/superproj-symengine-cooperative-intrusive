# 11 — Isolation: Eliminating Monkeypatching in nbsymengine_compat

This plan outlines the architecture and migration steps to eliminate all monkeypatching from [nbsymengine_compat](file:///work/nbsymengine_compat/). Importing the compatibility shim will have **absolutely no effect** on `nbsymengine` native types, ensuring third-party libraries using `nbsymengine` directly remain unaffected.

---

## 1. Goal

1. **Complete Isolation:** Remove all side-effects (monkeypatching) on classes inside `nbsymengine._core` (like `Basic`, `Integer`, `DenseMatrix`, etc.) at import time.
2. **Dedicated Wrapper Hierarchy:** Introduce a **Delegation Wrapper Pattern** inside the compatibility layer. All compatibility API methods and classes will operate on and return wrapped objects instead of raw `_core` objects.
3. **Preserve Legacy Behavior:** Ensure all converted and legacy tests in `nbsymengine_compat/tests/` continue to pass cleanly.

---

## 2. The Delegation Wrapper Pattern

Rather than modifying `_core` classes globally, `nbsymengine_compat` will define a parallel class hierarchy.

### Core Architecture

```mermaid
classDiagram
    class Basic {
        +Basic _raw
        +args
        +free_symbols
        +is_zero
        +__add__(other)
        +__mul__(other)
    }
    class Symbol {
        +Symbol(name)
    }
    class Integer {
        +Integer(val)
        +p
        +q
    }
    
    Basic <|-- Symbol
    Basic <|-- Integer
```

Each compatibility class will be a wrapper around a raw `_core` object:

```python
class Basic:
    def __init__(self, raw: _core.Basic):
        self._raw = raw

    def __repr__(self):
        return repr(self._raw)

    def __str__(self):
        return str(self._raw)

    def __hash__(self):
        return hash(self._raw)
```

### Automatic Wrapping & Unwrapping

A central set of helpers will convert back and forth between wrapped objects and raw C++ objects at the boundary of every function:

```python
# Helper to wrap raw _core instances
def wrap(obj):
    if isinstance(obj, _core.Basic):
        cls = _WRAPPER_MAP.get(type(obj), Basic)
        return cls(obj)
    if isinstance(obj, _core.DenseMatrix):
        return ImmutableMatrix(obj)
    return obj

# Helper to unwrap compat objects
def unwrap(obj):
    if isinstance(obj, Basic):
        return obj._raw
    if isinstance(obj, MatrixCommon):  # for DenseMatrix/ImmutableMatrix wrapper
        return obj._raw
    return obj
```

---

## 3. Detailed Migration Steps

### Step 1: Replace Metaclass Shims with Wrapper Classes
In [_wrappers.py](file:///work/nbsymengine_compat/src/nbsymengine_compat/_wrappers.py), replace the existing metaclass shims (which directly aliased `_core` types and intercepted `__instancecheck__`) with actual wrapper classes inheriting from the wrapper `Basic`.

* Define the static `Basic` wrapper containing all core operator definitions (`__add__`, `__sub__`, `__mul__`, `__eq__`, `__lt__`, etc.) and general property methods.
* Define wrappers for specialized leaf classes that require custom constructors or attributes (e.g. `Symbol`, `Integer`, `Rational`, `Interval`).

### Step 2: Implement Dynamic Wrapper Class Mapping
To avoid writing boilerplate for hundreds of functions and classes defined in `nbsymengine` (such as `Sin`, `Cos`, `Add`, `Mul`, `Pow`), we will dynamically construct the rest of the wrapper subclasses at import time:

```python
_WRAPPER_MAP = {}

def _register_wrappers():
    # Build wrapper mapping dynamically for all C++ types inheriting from _core.Basic
    for name in dir(_core):
        obj = getattr(_core, name)
        if isinstance(obj, type) and issubclass(obj, _core.Basic):
            # Create a dynamic subclass of Basic representing this type
            wrapper_cls = type(name, (Basic,), {})
            _WRAPPER_MAP[obj] = wrapper_cls
            globals()[name] = wrapper_cls
```

### Step 3: Move Monkeypatches to Wrapper Methods
Delete [_monkeypatch.py](file:///work/nbsymengine_compat/src/nbsymengine_compat/_monkeypatch.py). Move all of its logic into static method and property definitions on the wrapper classes:

1. **Arithmetic Operations:** Implement operators directly on the wrapper `Basic` by unwrapping operands, performing the native operation, and calling `wrap()` on the result:
   ```python
   def __add__(self, other):
       return wrap(self._raw + unwrap(other))
   ```
2. **Predicates:** Move `is_zero`, `is_positive`, `is_real`, etc., to properties on the wrapper `Basic`.
3. **Properties:** Move `.args`, `.free_symbols`, `.atoms`, `.real`, and `.imag` to the wrapper classes.

### Step 4: Update Matrix Implementations
Modify [_matrices.py](file:///work/nbsymengine_compat/src/nbsymengine_compat/_matrices.py):
* Convert `DenseMatrix` and `ImmutableMatrix` to wrap `_core.DenseMatrix` instead of inheriting from it directly.
* Ensure all matrix arithmetic, element access, and mutation operations wrap returned symbols and unwrap inputs.

### Step 5: Clean up Serialization/Pickling
In [_pickling.py](file:///work/nbsymengine_compat/src/nbsymengine_compat/_pickling.py):
* Define `__reduce__` and `__reduce_ex__` directly on the wrapper classes `Basic` and `DenseMatrix`.
* **DO NOT** modify `_core.Basic.__reduce_ex__` or `_core.DenseMatrix.__reduce__`. This leaves the native serialization path of `nbsymengine` completely untouched.

---

## 4. Addressing Edge Cases

### Binary Operations with Third-Party Types
If a 3rd-party object (like a SymPy expression or Python number) is added to a wrapped object, the wrapper's `__add__` will coerce it:
```python
def __add__(self, other):
    from ._helpers import PyNumber
    coerced = _coerce_operand(other)  # returns raw _core.Basic or PyNumber
    if isinstance(coerced, PyNumber):
        # Delegate to SymPy or return NotImplemented
        ...
    return wrap(self._raw + coerced)
```

### Identity and Type Checks
Legacy tests often check type equality (e.g. `type(x) == Symbol`). By mapping each `_core` type to a dedicated dynamic Python subclass of `Basic` (e.g. `Symbol`), these checks will continue to work exactly as they did under the old Cython-based `symengine.py` wrapper.

---

## 5. Verification Plan

### A. Non-Interference Verification
Write a test script (`nbsymengine_compat/tests/test_no_monkeypatch.py`) to verify isolation:
1. Save the attributes/directory of `nbsymengine._core` classes before importing `nbsymengine_compat`.
2. Import `nbsymengine_compat`.
3. Assert that no classes in `nbsymengine._core` have new attributes, overridden operators, or changes to their `__dict__`.

### B. Compatibility Test Suite Run
1. Regenerate all legacy converted tests:
   ```bash
   python nbsymengine_compat/tools/rewrite_legacy_tests.py
   ```
2. Run the compatibility test suite:
   ```bash
   pytest nbsymengine_compat/tests
   ```
3. Run the native `nbsymengine` tests to guarantee no regressions:
   ```bash
   pytest nbsymengine/tests
   ```
