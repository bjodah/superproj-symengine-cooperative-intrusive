# 19 - Perl Extension: Cooperative Intrusive Ownership

**Date:** 2026-06-15 (cooperative ownership landed 2026-06-16)
**Status:** Complete — Perl wrappers participate in the cooperative_intrusive
counter; clean under system, debug and ASAN perls.

## Summary

The Perl XS extension now implements full cooperative ownership on top of the
`cooperative_intrusive` SymEngine backend. A SymEngine object handed out to
Perl is *externalized* so that its blessed inner SV becomes the object's
reference-count anchor: every C++ `RCP<const Basic>` that points at the object
is mirrored as an `SvREFCNT` on that wrapper, and every Perl reference is
mirrored as an inline count via the inc/dec hooks. This gives:

- identity reuse (one Perl wrapper per C++ object),
- correct cross-runtime lifetime (C++ RCPs keep Perl wrappers alive and vice
  versa),
- crash-free, leak-free interpreter teardown for singletons.

## What Landed Previously (unchanged)

1. SymEngine core owns a generic pointer-sized tagged counter
   (`symengine_cooperative_intrusive_counter`) and no longer depends on
   nanobind headers.
2. The backend is spelled `cooperative_intrusive`; `nb_intrusive` remains a
   deprecated CMake alias.
3. `nbsymengine` installs Python hooks into the generic counter.

## Cooperative Ownership in the Perl Layer

Relevant files:

- [symengine.pl/xs/perl_symengine.h](/work/symengine.pl/xs/perl_symengine.h)
- [symengine.pl/xs/perl_symengine.cpp](/work/symengine.pl/xs/perl_symengine.cpp)
- [symengine.pl/xs/SymEngine.xs](/work/symengine.pl/xs/SymEngine.xs)

### Wrapper layout

`BasicHolder` now stores a **raw** `const Basic *` (no embedded RCP). The
blessed inner SV holds the holder; the inner SV *is* the cooperative owner.
Storing a strong RCP in the holder would create an `inner -> holder -> RCP ->
(external) -> inner` cycle that can never reach refcount zero, so the raw
pointer is essential.

### Hooks

`inc_ref`/`dec_ref` map to `SvREFCNT_inc`/`SvREFCNT_dec` on the inner SV. The
object pointer handed to `set_self_external()` is the inner (blessed) SV.

### wrap_basic

- If `self_external()` is non-null, the object already owns a wrapper: return a
  fresh `newRV_inc(inner)` (identity reuse).
- Otherwise create the inner SV + holder, bless, and call
  `set_self_external(inner)`, which replays the current C++ count as `SvREFCNT`
  increments on the inner SV.

### unwrap_basic

Rebuilds an `RCP<const Basic>` from the raw pointer via `rcp(p)`, which takes
one cooperative reference for the life of the returned RCP.

### DESTROY (destroy_basic)

Frees the holder, then — outside global destruction — deletes the C++ object if
it is still external-owned (refcount reached zero means no C++ and no Perl
reference survives). During global destruction it does **not** delete (see
below).

## Teardown: the hard part

Two ordering problems had to be solved; both are the reason the earlier attempt
was backed out.

### 1. Premature delete during global destruction

During Perl global destruction `sv_clean_objs` force-calls `DESTROY` on objects
**regardless of refcount**. A singleton wrapper (pinned by a SymEngine C++
static such as `SymEngine::one`) would therefore be DESTROYed while the static
still references the object, deleting it and leaving the static dangling →
use-after-free when the static's `~RCP` runs at C++ static-destruction time.

Fix: `destroy_basic` checks `PL_phase == PERL_PHASE_DESTRUCT` (set at the very
start of `perl_destruct`, before any pad teardown or DESTROY sweep) and skips
the delete during global destruction. This is the standard Perl `if (PL_dirty)
return;` idiom — objects still alive at global destruction are left for the OS,
which is expected Perl behaviour. (Lexically-scoped objects are freed during
the normal run and delete cleanly, so this is not a real leak for well-scoped
code.)

### 2. Singletons must revert to inline ownership

SymEngine's singletons are freed by `ConstantInitializer::~ConstantInitializer`
(a "nifty counter" that runs `n.~RCP()` at C++ static destruction). If a
singleton is left external-owned, that `~RCP` routes into a hook after the Perl
interpreter is gone (crash) or no-ops (leak).

Fix: a `call_atexit` handler runs during `perl_destruct`, *after* the program's
pad/lexicals are released. Empirically, at that point the only references left
to a singleton wrapper are the C++ static RCPs (`SvREFCNT(inner) == that
count`). The handler calls `detach_external()` (flip back to inline, count 0)
and replays `inc_ref()` that many times, so the SymEngine static destructors
delete the singletons exactly as they would without Perl. A `g_perl_destructing`
flag (set by the same handler and by the first teardown DESTROY) makes the hooks
inert for any reference that is released after the interpreter is gone.

The seed list of singletons lives in `seed_singletons()` and covers the named
public constants reachable through the XS API (`zero`, `one`, `minus_one`,
`two`, `I`, `pi`, `E`, `EulerGamma`, `Catalan`, `GoldenRatio`, `Inf`, `NegInf`,
`ComplexInf`, `Nan`).

## Tests

- [t/04-cooperative.t](/work/symengine.pl/t/04-cooperative.t): externalization,
  identity reuse (`add(x,0)` returns the same wrapper), wrappers kept alive by
  copied C++ RCPs, releasing the last reference, singleton identity.
- [t/05-teardown.t](/work/symengine.pl/t/05-teardown.t): spawns a child
  interpreter under `PERL_DESTRUCT_LEVEL=2` holding live singletons and
  expressions, and asserts a clean exit.

Introspection helpers added to the XS for testing/debugging: `perl_refcount`,
`is_external_owned` (alongside the existing `same_object`, `cpp_use_count`).

### Verification

```bash
cmake -S /work -B /tmp/build-perl-super -G Ninja \
  -DBUILD_PERL_XS=ON -DSYMENGINE_RCP_BACKEND=cooperative_intrusive \
  -DBUILD_TESTS=ON -DBUILD_BENCHMARKS=OFF
cmake --build /tmp/build-perl-super -j8
ctest --test-dir /tmp/build-perl-super --output-on-failure \
  -R 'perl_symengine|test_cooperative_intrusive_rcp|test_rcp'
```

All 36 Perl tests pass under the system perl, `/opt/perl-v5.43.11-debug`, and
`/opt/perl-v5.43.11-asan` (the latter run with `ASAN_OPTIONS=detect_leaks=0`,
since the ASAN-enabled perl reports its own interpreter-internal leaks). With
leak detection on and the perl-internal allocations suppressed, no
SymEngine-attributable leaks remain.

## Remaining / deferred

- **Wider singleton coverage.** The seed list covers everything reachable
  through the current (small) XS surface. If more constructors are exposed
  (boolean atoms, set singletons, the internal `i2`/`sqrt`/`C0` constants),
  extend `seed_singletons()` accordingly — mirror the nanobind list in
  `nbsymengine/support/nanobind_module_common.h`.
- **Objects held in package globals until process exit** "leak" at global
  destruction (idiomatic Perl). Prefer lexical scoping in code and tests.
- **`nb_intrusive` name normalization.** Done for the super-project CI scripts
  and benchmark docs. Historical reports/plans and the submodule-internal
  comments still reference the old spelling and were left as dated records.
  (Resolved by docs/plans/20-REMOVE-HISTORICAL-ALIASES.md.)
- **Deprecated alias.** `SYMENGINE_RCP_BACKEND=nb_intrusive` is still accepted
  by `symengine/CMakeLists.txt`; decide whether to drop it once downstreams
  have migrated. (Resolved by docs/plans/20-REMOVE-HISTORICAL-ALIASES.md.)
