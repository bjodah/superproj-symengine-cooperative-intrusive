# 22c - Cooperative Intrusive Cross-Runtime

## Tagged Counter State

`cooperative_intrusive` stores either an inline shifted reference count with a
tag bit or an aligned foreign-owner pointer. The tag distinguishes inline mode
from external-owned mode.

## Foreign Owner Pointer Alignment

Foreign owner pointers must have bit 0 clear. This is why the core test uses an
`alignas(2)` fake owner pointer.

## Why Holders Store Raw Pointers

PHP and Perl holders store raw `Basic *` pointers instead of strong `RCP`s so
the foreign runtime remains the owner while the object is externalized.

## Identity Reuse Through `self_external()`

When a `Basic` already has `self_external() != nullptr`, wrappers must reuse the
existing foreign object rather than creating a second wrapper for the same C++
instance.

## External-Owned `use_count() == 0`

In external-owned mode, `use_count()` reports `0` because the live references are
tracked by the foreign runtime. Ownership-sensitive C++ code must use
`is_uniquely_owned_by_cpp()` instead of `use_count() == 1`.

## Temporary Native Handles

Temporary `RCP` handles created while unwrapping foreign objects must not steal
ownership back from the runtime. They should mirror foreign refcount hooks while
the object remains externalized.

## Singleton Seed Lists

Singleton-backed objects need explicit seed lists so shutdown reconciliation only
touches known canonical statics. The list should stay reviewable, not inferred.

## Detach and Inline Replay

Shutdown reconciliation for singleton wrappers is:

1. Observe the foreign wrapper refcount.
2. Call `detach_external()`.
3. Replay the observed count with `inc_ref()`.
4. Let later C++ static destruction release those inline references.

This is now covered by `symengine/symengine/tests/rcp/test_cooperative_intrusive_rcp.cpp`.

## When Hooks Become Inert

Foreign-runtime incref/decref hooks must become inert before later static C++
destruction can touch a torn-down runtime.

## Runtime-Specific Shutdown Policies

| Runtime | Foreign owner pointer | Normal incref/decref | Reconcile point | Inert hook point |
| --- | --- | --- | --- | --- |
| PHP CLI | `zend_object *` | `GC_ADDREF` / `OBJ_RELEASE` | `RSHUTDOWN` | `MSHUTDOWN` |
| PHP FPM | `zend_object *` | `GC_ADDREF` / `OBJ_RELEASE` | `RSHUTDOWN` verified by local smoke | `MSHUTDOWN` verified by local smoke |
| Perl | blessed inner `SV *` | `SvREFCNT_inc` / `SvREFCNT_dec` | `call_atexit` during `perl_destruct` | `PL_phase` / cleanup flag |
| Python nanobind | Python object pointer | nanobind/Python refcount hooks | existing nanobind cleanup | existing nanobind cleanup |

## Known Unverified SAPIs

- Apache module mode remains unverified.
- PHP FPM validation is currently a local smoke test, not a broad SAPI matrix.
