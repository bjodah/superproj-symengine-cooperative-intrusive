# PHP Extension Implementation Plan for SymEngine (cooperative_intrusive backend)

## 1. Project Structure

```
/work/symengine.php/
├── config.m4                    # PHP extension build configuration (primary)
├── config.w32                   # Windows build config (stub, optional)
├── php_symengine.h              # Main header with PHP API + SymEngine includes
├── symengine_php.cpp            # Core C++ implementation (ownership, wrapping)
├── symengine_php.h              # C++ header for internal functions
├── symengine_arginfo.h          # Generated arginfo (or manual for now)
├── symengine.c                  # PHP extension entry point (MINIT, MSHUTDOWN, etc.)
├── classes/
│   ├── basic.c                  # Basic class (SymEngine\Basic)
│   ├── basic.h
│   ├── integer.c                # Integer class (SymEngine\Integer)
│   ├── integer.h
│   ├── symbol.c                 # Symbol class (SymEngine\Symbol)
│   ├── symbol.h
│   └── basic_arginfo.h          # ArgInfo for Basic class methods
├── functions/
│   ├── functions.c              # Module functions (symbol, integer, add, etc.)
│   ├── functions.h
│   └── functions_arginfo.h
├── tests/
│   ├── 001_load.php             # Basic load test
│   ├── 002_basic.php            # Basic functionality test
│   ├── 003_ownership.php        # Cooperative ownership test
│   ├── 004_identity.php         # Identity reuse test
│   └── 005_teardown.php         # Shutdown/teardown test
└── README.md                    # Build/install instructions
```

## 2. Ownership Model (cooperative_intrusive ↔ PHP)

### SymEngine cooperative_intrusive RCP Mechanics

The SymEngine `cooperative_intrusive` RCP backend uses a single pointer-sized counter (`uintptr_t m_state`) with two modes:

| Mode | `m_state` LSB | Meaning |
|------|---------------|---------|
| C++-owned (inline) | `1` | Upper bits = refcount (shifted left by 1) |
| External-owned | `0` | `m_state` = pointer to external owner object |

**Key operations:**
- `inc_ref()`: If inline (LSB=1), increment count; if external (LSB=0), call `g_cooperative_incref(ext_ptr)`
- `dec_ref()`: If inline, decrement and return true if count reaches 0; if external, call `g_cooperative_decref(ext_ptr)`
- `set_self_external(void *o)`: Atomically switch from inline to external mode, replaying current inline count as `incref` calls on `o`
- `self_external()`: Returns external pointer or nullptr if inline
- `detach_external()`: Atomically switch back to inline (count=0), return previous external pointer

### PHP Ownership Mapping

| SymEngine Operation | PHP Action |
|---------------------|------------|
| `inc_ref()` (external mode) | `GC_ADDREF(zend_object)` on the PHP wrapper object |
| `dec_ref()` (external mode) | `OBJ_RELEASE(zend_object)` on the PHP wrapper object |
| `set_self_external(zend_object*)` | Called when wrapping a C++ object for PHP; transfers ownership to PHP's GC |
| `detach_external()` | Called at PHP shutdown to return singletons to C++ ownership |

### PHP Object Structure

```c
typedef struct {
    const SymEngine::Basic *ptr;  // Raw pointer to SymEngine object (no ownership)
    zend_object std;              // Stable GC-tracked external owner anchor
} symengine_basic_object;
```

**Critical invariant:** The `zend_object` itself (the `std` member) IS the external owner pointer passed to `set_self_external()`. A `zval` is not stable enough for this role. The PHP object's GC refcount is the SymEngine refcount when in external-owned mode.

### Object Creation (wrap_basic equivalent)

```cpp
zval *symengine_wrap_basic(const SymEngine::RCP<const SymEngine::Basic> &value) {
    if (value.is_null()) return &EG(uninitialized_zval);

    const Basic *p = value.get();

    // Identity reuse: if already wrapped, return existing wrapper
    if (void *ext = p->self_external()) {
        zend_object *existing = (zend_object *)ext;
        GC_ADDREF(existing);
        return existing;
    }

    // Create new PHP object
    zval *obj = ...; // allocate zend_object
    symengine_basic_object *intern = ...;
    intern->ptr = p;
    // Hand off to cooperative ownership: transfers C++ refcount to PHP GC
    p->set_self_external(obj);

    return obj;
}
```

### Object Destruction (DESTROY equivalent)

```c
static void symengine_basic_free_obj(zend_object *object) {
    symengine_basic_object *intern = symengine_basic_from_obj(object);

    // During PHP shutdown, don't touch C++ objects
    if (symengine_is_shutting_down()) {
        return;
    }

    const Basic *p = intern->ptr;
    if (p && p->is_external_owned()) {
        // PHP refcount hit zero while external-owned -> final delete.
        // In this model the wrapper stores only a raw pointer; any temporary
        // C++ handle is rebuilt on demand with rcp(p), which cooperatively
        // bumps the zend_object refcount.
        delete p;
    }
    // If not external-owned, C++ side retains ownership (singleton case).

    zend_object_std_dtor(object);
}
```

### Unwrapping (unwrap_basic equivalent)

```cpp
SymEngine::RCP<const SymEngine::Basic> symengine_unwrap_basic(zval *obj) {
    symengine_basic_object *intern = symengine_basic_from_obj(Z_OBJ_P(obj));
    const Basic *p = intern->ptr;
    // Rebuild RCP: takes one cooperative reference (increments PHP GC refcount)
    return SymEngine::rcp(p);
}
```

### Singleton Handling (Shutdown Reconciliation)

Mirror Perl's approach:
1. Track all SymEngine singletons (`zero`, `one`, `pi`, etc.) that get wrapped
2. At PHP `MSHUTDOWN` (or RSHUTDOWN for CLI), call `detach_external()` on each
3. Replay the PHP refcount as C++ `inc_ref()` calls to restore C++-owned state
4. Let C++ static destructors clean up normally

## 3. Lifecycle & Hooks Registration

### Module Initialization (MINIT)
```c
PHP_MINIT_FUNCTION(symengine) {
    // 1. Register cooperative hooks with SymEngine
    SymEngine::cooperative_intrusive_init(php_incref_hook, php_decref_hook);

    // 2. Register PHP classes (Basic, Integer, Symbol, etc.)
    symengine_register_classes();

    // 3. Seed singleton pointers
    symengine_seed_singletons();

    // 4. Register RSHUTDOWN handler for singleton reconciliation
    zend_register_auto_global(...); // or use RSHUTDOWN
    return SUCCESS;
}
```

### Cooperative Hooks
```c
static void php_incref_hook(void *object) noexcept {
    if (symengine_is_shutting_down()) return;
    zend_object *obj = (zend_object *)object;
    GC_ADDREF(obj);
}

static void php_decref_hook(void *object) noexcept {
    if (symengine_is_shutting_down()) return;
    zend_object *obj = (zend_object *)object;
    OBJ_RELEASE(obj);
}
```

### Shutdown Handling
```c
static bool symengine_shutting_down = false;

PHP_RSHUTDOWN_FUNCTION(symengine) {
    // For CLI: reconcile singletons at request shutdown
    symengine_reconcile_singletons();
    return SUCCESS;
}

PHP_MSHUTDOWN_FUNCTION(symengine) {
    symengine_shutting_down = true;
    // For shared extensions (FPM): reconcile at module shutdown
    symengine_reconcile_singletons();
    return SUCCESS;
}
```

## 4. Identity Reuse Strategy

Mirror Perl's identity reuse:
- When wrapping a `Basic*`, check `self_external()`
- If non-null, it's the `zval*` of the existing PHP wrapper
- `GC_ADDREF` that zval and return it
- This ensures `same_object($a, $b)` works by pointer identity

## 5. Build System Integration

### config.m4 (primary)
```m4
PHP_ARG_ENABLE(symengine, whether to enable SymEngine support,
[  --enable-symengine       Enable SymEngine support])

if test "$PHP_SYMENGINE" != "no"; then
    # Find SymEngine with cooperative_intrusive backend
    PHP_CHECK_LIBRARY(symengine, cooperative_intrusive_init,
        [PHP_ADD_LIBRARY(symengine, 1, SYMENGINE_SHARED_LIBADD)],
        [AC_MSG_ERROR([SymEngine with cooperative_intrusive backend not found])], 
        [-lsymengine])

    PHP_ADD_INCLUDE(/usr/local/include/symengine)  # or pkg-config
    PHP_NEW_EXTENSION(symengine, 
        symengine.c
        symengine_php.cpp
        classes/basic.c
        classes/integer.c
        classes/symbol.c
        functions/functions.c
        , $ext_shared, , -std=c++17 -DWITH_SYMENGINE_COOPERATIVE_INTRUSIVE_RCP)
fi
```

### CMake Alternative (for nbsymengine style)
Could also provide a `CMakeLists.txt` for building via CMake, but `config.m4` is the standard PHP extension way.

## 6. PHP Class Hierarchy (Minimal Scaffold)

### SymEngine\Basic (Base class)
```php
namespace SymEngine;

class Basic {
    // Internal: wraps const Basic*
    public function __toString(): string;
    public function __equals(Basic $other): bool;
    public static function sameObject(Basic $a, Basic $b): bool;
    // Internal debugging:
    public function getCppUseCount(): int;
    public function getPhpRefCount(): int;
    public function isExternalOwned(): bool;
}
```

### SymEngine\Integer (extends Basic)
```php
class Integer extends Basic {
    public static function fromInt(int $value): Integer;
}
```

### SymEngine\Symbol (extends Basic)
```php
class Symbol extends Basic {
    public function __construct(string $name);
    public function getName(): string;
}
```

### Module Functions
```php
function symbol(string $name): Symbol;
function integer(int $value): Integer;
function add(Basic $a, Basic $b): Basic;
function mul(Basic $a, Basic $b): Basic;
function zero(): Basic;
function one(): Basic;
```

## 7. Staged Roadmap

### Stage 1: Minimal Scaffold (This PR)
- [ ] `config.m4` with cooperative_intrusive detection
- [ ] `php_symengine.h` / `symengine_php.h` headers
- [ ] Module entry (MINIT/MSHUTDOWN/RINIT/RSHUTDOWN)
- [ ] Cooperative hook registration
- [ ] `SymEngine\Basic` class with:
  - Object allocation/free
  - `wrap_basic` / `unwrap_basic` / identity reuse
  - `__toString`, `sameObject`, `isExternalOwned`, `getPhpRefCount`
- [ ] Module functions: `symbol()`, `integer()`, `add()`, `mul()`, `zero()`, `one()`
- [ ] Basic test suite (load, basic ops, ownership, identity, shutdown)

### Stage 2: Core Types
- [ ] `Integer`, `Symbol`, `Rational`, `RealDouble`, `Complex` classes
- [ ] Arithmetic operators (`__add`, `__mul`, etc.) via `Basic` handlers
- [ ] More functions: `sub`, `div`, `pow`, `neg`, `sin`, `cos`, `expand`

### Stage 3: Advanced Types
- [ ] `Add`, `Mul`, `Pow` expression classes
- [ ] `Function`, `Derivative`, `Series`
- [ ] `Matrix`, `DenseMatrix`
- [ ] Sets, Logic, Number theory

### Stage 4: Compatibility Layer
- [ ] `SymEngineCompat` shim matching `symengine.py` API (like `nbsymengine_compat`)
- [ ] Automated test transcription from Perl/Python test suites

## 8. Implementation Notes

### Key Differences from Perl Extension

| Aspect | Perl (XS) | PHP (Zend API) |
|--------|-----------|----------------|
| Object header | `SV*` (blessed RV to IV holder) | `zend_object` with `std` header |
| Refcount | `SvREFCNT(SV*)` | `GC_REFCOUNT(zval)` / `zend_object.gc.refcount` |
| Blessing | `sv_bless()` | `zend_object_std_init()` + class_entry |
| Identity | `IV` holder pointer | `zend_object*` pointer |
| Destructor | `DESTROY` XSUB | `zend_object_free_obj_t` handler |
| Shutdown hook | `call_atexit()` | `RSHUTDOWN` / `MSHUTDOWN` |

### PHP GC Integration
- Use `zend_object` with `zend_object_handlers`
- Implement `free_obj` for destructor logic
- Use `GC_ADDREF`/`GC_DELREF` in cooperative hooks
- Register `zend_object` as the external owner pointer

### Exception Handling
- Catch C++ exceptions in every PHP method
- Convert to `zend_throw_exception` with appropriate PHP exception class

### Debug Helpers
- `SYMENGINE_PHP_DEBUG` env var for debug output
- `getCppUseCount()`, `getPhpRefCount()`, `isExternalOwned()` for test assertions

## 9. Test Plan (Stage 1)

| Test | Description |
|------|-------------|
| `001_load.php` | `extension_loaded('symengine')` and version |
| `002_basic.php` | `symbol('x')`, `integer(42)`, `add()`, `mul()`, `__toString()` |
| `003_ownership.php` | `isExternalOwned()`, refcount tracking, external ownership transfer |
| `004_identity.php` | `sameObject($a, $b)` identity reuse when wrapping same C++ object |
| `005_teardown.php` | Request shutdown cleanup, singleton reconciliation |

## 10. Directory Location

Create at `/work/symengine.php/` following the pattern of sibling directories:
- `/work/symengine` (C++ core)
- `/work/symengine.pl` (Perl XS)
- `/work/symengine.py` (Legacy Cython)
- `/work/nbsymengine` (Nanobind Python)
- `/work/nbsymengine_compat` (Compat shim)
- **`/work/symengine.php` (NEW: PHP extension)**

This keeps the extension as a first-class sibling in the super-project.
