# 06 — Implementation Plan: More Code-Generation, Less Hand-Typing

**Audience:** a junior developer working on the SymEngine nanobind bindings.
**Goal:** replace large blocks of repetitive, hand-typed binding code in
`nbsymengine/bindings/python_nanobind/src/core_module.cpp` (and its duplicated
type-stub twin in `generate.py`) with code generated from a single declarative
data file, so that adding/changing a simple function is a one-line data edit
instead of editing C++ *and* `.pyi` stubs *and* the litgen exclude list.

Read this whole document before touching anything. Each phase is independently
shippable and independently testable. Do **not** start Phase _N+1_ until the
tests for Phase _N_ pass.

---

## 1. Background: how binding code is produced today

There are **two** generators in play, plus a lot of hand-written C++:

1. **litgen** (`generate.py` + `generate.yaml`) parses curated SymEngine
   headers and emits `generated/symengine_pydef.cpp` (binding statements) and
   `generated/symengine.pyi` (type stubs). These outputs are **not** tracked in
   git; they are produced at build time (source checkout) or shipped pre-baked
   in the sdist tarball. `core_module.cpp` pulls the C++ in with
   `#include "symengine_pydef.cpp"` (see `core_module.cpp:1040`).

2. **Hand-written C++** in `core_module.cpp`. Below the litgen include sits a
   large *"Hand-written direct RCP API"* section (`core_module.cpp:1065`–`1768`).
   These functions take/return `RCP<const Basic>` directly (litgen cannot see
   `RCP` because it lives in `nanobind_symengine.h`, not the parsed headers).

3. **Hand-written `.pyi` stubs** for those same hand-written functions, stored
   as a giant string literal `_MANUAL_FUNCTION_STUBS` in `generate.py:47`–`208`.

The pain: function #2 and stub #3 are **two parallel hand-maintained lists that
must stay in sync**, and many of the names are *also* listed a **third** time in
`generate.yaml`'s `fn_exclude` (to stop litgen from also binding them). Adding
one trig function today means editing three places by hand, with no check that
they agree.

### The specific blocks the user pointed at

In `core_module.cpp`:

- `// Trig functions (direct RCP)` — `core_module.cpp:1106`–`1128`
- `// Hyperbolic functions (direct RCP)` — `core_module.cpp:1130`–`1145`
- `// Other math functions (direct RCP)` — `core_module.cpp:1147`–`1211`

Every entry is a near-identical 3-line lambda, e.g.:

```cpp
m.def("sin", [](const RCP<const Basic> &a) -> RCP<const Basic> {
    return SymEngine::sin(a);
}, nb::arg("a"));
```

This is exactly the kind of boilerplate that should be rendered from a table.

---

## 2. Opportunities identified (ranked by value / risk)

| # | Opportunity | Lines saved (approx) | Risk | Phase |
|---|-------------|----------------------|------|-------|
| A | **Unary** `Basic -> Basic` functions (trig/hyperbolic/other) | ~80 | low | 1 |
| B | **Binary** `Basic,Basic -> Basic` / `-> Boolean` functions | ~70 | low | 1 |
| C | Drive the `.pyi` stubs for A+B from the same table | ~40 | low | 2 |
| D | Auto-derive the `fn_exclude` entries for A+B from the table | ~15 | low | 2 |
| E | ntheory funcs taking `RCP<const Integer>` (deref + `*a`) | ~120 | med | 3 |
| F | Status/`Optional`-returning funcs (`outArg` + None) | ~120 | med | 3 |
| G | `list`-returning funcs (`prime_factors`, `*_list`) | ~80 | med | 3 |
| H | Completeness cross-check against `type_codes.inc` (a test) | n/a | low | 4 |

Phases 1–2 cover precisely the blocks the user called out and remove the
triple-maintenance problem for them. Phases 3–4 are follow-ups that apply the
same mechanism to the rest of the hand-written section.

### Why a data file, not `type_codes.inc` directly

`symengine/symengine/type_codes.inc` lists the **class** names (`Sin`, `Cos`,
`ASin`, `Dirichlet_eta`, …). But the bindings need the **free-function** name
(`sin`, `cos`, `asin`, `dirichlet_eta`), the **arity**, and the **argument
names** (`zeta(s)` not `zeta(a)`). The class→function mapping is *mostly*
lower-casing but has exceptions (`LambertW`→`lambertw`, `Dirichlet_eta`→
`dirichlet_eta`, `ATan2` is binary). So `type_codes.inc` is the wrong source of
truth for *what to bind*; it is, however, a great source of truth for *checking
we didn't miss anything* (Phase 4). The authoritative input is a new,
purpose-built data file.

We use **JSON** for that data file (the user's suggestion) on purpose: the
small renderer that consumes it can then be **pure Python stdlib** — no PyYAML,
no litgen, no Python 3.13 requirement — so it can run unconditionally at build
time, even in the sdist case where litgen is absent.

---

## 3. Recommended design

Introduce one declarative file and one small renderer:

```
bindings/python_nanobind/
  simple_functions.json        # NEW — the single source of truth (tracked in git)
  gen_simple_functions.py      # NEW — stdlib-only renderer (tracked in git)
  generated/
    symengine_simple_funcs.inc # NEW — generated C++  (NOT tracked; build output)
```

- `simple_functions.json` describes each function: its Python name, the
  `SymEngine::` free function to call, its "kind" (which C++ template to emit),
  and its argument names.
- `gen_simple_functions.py` reads the JSON and writes:
  - `generated/symengine_simple_funcs.inc` — the `m.def(...)` block, which
    `core_module.cpp` will `#include` in place of the deleted hand-written blocks.
  - It also exposes a function `stub_lines()` that returns the `.pyi` lines, so
    `generate.py` can import it and inject those lines instead of carrying its
    own hand-typed copy.
  - It also exposes `excluded_names()` so `generate.py` can extend litgen's
    `fn_exclude` from the table (Phase 2/D), killing the third copy.

This keeps the existing "generated files are not tracked, sdist ships pre-baked"
policy intact — `symengine_simple_funcs.inc` is just another build artifact next
to `symengine_pydef.cpp`.

### Data file schema

```jsonc
{
  "functions": [
    // kind "unary_basic":  RCP<const Basic> f(RCP<const Basic>)
    { "py": "sin",  "cpp": "sin",  "kind": "unary_basic",  "args": ["a"] },
    { "py": "zeta", "cpp": "zeta", "kind": "unary_basic",  "args": ["s"] },

    // kind "binary_basic": RCP<const Basic> f(RCP<const Basic>, RCP<const Basic>)
    { "py": "atan2", "cpp": "atan2", "kind": "binary_basic", "args": ["a","b"] },
    { "py": "polygamma", "cpp": "polygamma", "kind": "binary_basic", "args": ["n","x"] },

    // kind "binary_boolean": RCP<const Boolean> f(RCP<const Basic>, RCP<const Basic>)
    { "py": "Eq", "cpp": "Eq", "kind": "binary_boolean", "args": ["a","b"] }
  ]
}
```

`py` defaults to `cpp` when omitted; `args` defaults to `["a"]` / `["a","b"]` by
arity. Keep the schema deliberately small — only add a new `kind` when a new C++
shape actually appears (Phases 3 introduces more kinds).

---

## 4. Phase 1 — generate the unary/binary RCP function blocks

### Step 1.1 — Create the data file

Create `bindings/python_nanobind/simple_functions.json`. Populate it by reading
the **current** hand-written blocks in `core_module.cpp` and transcribing them
exactly — this phase must be **behavior-preserving**. The full Phase-1 set
(transcribed from `core_module.cpp:1106`–`1237`):

- `unary_basic`, arg `["a"]`: `sin cos tan asin acos atan` (trig);
  `sinh cosh tanh sech csch` (hyperbolic);
  `log sqrt abs sign floor ceiling gamma erf erfc lambertw conjugate loggamma
  digamma trigamma` (other).
- `unary_basic`, arg `["s"]`: `zeta dirichlet_eta`.
- `binary_basic`, args `["a","b"]`: `atan2`.
- `binary_basic`, custom args: `beta ["x","y"]`, `polygamma ["n","x"]`,
  `uppergamma ["s","x"]`, `lowergamma ["s","x"]`.
- `binary_boolean`, args `["a","b"]`: `Eq Ne Ge Gt Le Lt`.

> ⚠️ Do **not** add functions that aren't currently bound in this phase (e.g.
> `cot`, `csc`, `sec`, `acot`, `coth`, `asinh`, …, which exist in
> `type_codes.inc` but are not bound today). Adding new public API is a separate,
> opt-in change — see Phase 4. Phase 1 changes *how* the existing set is
> produced, not *what* is produced.

### Step 1.2 — Write the renderer `gen_simple_functions.py`

Stdlib only. It must:

1. Define a `load(path)` that reads the JSON and validates each entry (known
   `kind`, arg count matches kind, no duplicate `py` names). Fail loudly on a
   bad entry — a clear `SystemExit("simple_functions.json: …")` message.
2. Define `render_cpp(entries) -> str` returning the `m.def` block. Emit a
   header banner comment `// AUTO-GENERATED from simple_functions.json — DO NOT EDIT.`
   and group output with the same section comments the file uses today so diffs
   stay readable. Templates per kind:

   - `unary_basic`:
     ```cpp
     m.def("{py}", [](const RCP<const Basic> &{a0}) -> RCP<const Basic> {
         return SymEngine::{cpp}({a0});
     }, nb::arg("{a0}"));
     ```
   - `binary_basic`: two `RCP<const Basic>` params → `RCP<const Basic>`.
   - `binary_boolean`: two `RCP<const Basic>` params → `RCP<const Boolean>`.

3. Define `stub_lines(entries) -> list[str]` (used in Phase 2). Mapping:
   `*_basic` → `-> Basic`, `binary_boolean` → `-> Boolean`; every param typed
   `Basic`. e.g. `def sin(a: Basic) -> Basic: ...`.
4. Define `excluded_names(entries) -> list[str]` returning each entry's `cpp`
   name (used in Phase 2 to feed `fn_exclude`).
5. A `main()` with argparse: `--output <path>` writes the `.inc`. Mirror the
   `--output-dir` convention already used by `generate.py` so CMake can place it
   in the build `generated/` dir.

Keep it ~120 lines. No third-party imports.

### Step 1.3 — Wire it into the build (CMake)

Edit `bindings/python_nanobind/CMakeLists.txt`, in the generation section
(around `CMakeLists.txt:99`–`133`). The `.inc` is needed in **both** the
source-checkout case and the sdist case (litgen may be absent in sdist, but this
renderer never needs litgen), so generate it **unconditionally**:

1. Add near the other `SYMENGINE_NB_GENERATED_*` vars (`CMakeLists.txt:73`):
   ```cmake
   set(SYMENGINE_NB_SIMPLE_INC "${SYMENGINE_NB_GENERATED_DIR}/symengine_simple_funcs.inc")
   ```
   Note `SYMENGINE_NB_GENERATED_DIR` is reassigned to the source `generated/`
   dir in the sdist branch (`CMakeLists.txt:84`); keep this `set` *after* that
   branch so the path follows suit, **or** add a dedicated `add_custom_command`
   that always regenerates into the build dir. Prefer: always regenerate into
   the build `generated/` dir and add that dir to the include path (it already
   is — `CMakeLists.txt:139`). The renderer is cheap and dependency-free, so
   regenerating even in the sdist case is fine and avoids a stale pre-baked
   `.inc`.
2. Add the command + target:
   ```cmake
   add_custom_command(
       OUTPUT ${SYMENGINE_NB_SIMPLE_INC}
       COMMAND ${CMAKE_COMMAND} -E make_directory ${SYMENGINE_NB_GENERATED_DIR}
       COMMAND ${Python3_EXECUTABLE}
               ${CMAKE_CURRENT_SOURCE_DIR}/gen_simple_functions.py
               --input  ${CMAKE_CURRENT_SOURCE_DIR}/simple_functions.json
               --output ${SYMENGINE_NB_SIMPLE_INC}
       DEPENDS
           ${CMAKE_CURRENT_SOURCE_DIR}/gen_simple_functions.py
           ${CMAKE_CURRENT_SOURCE_DIR}/simple_functions.json
       COMMENT "Generating simple RCP function bindings"
       VERBATIM)
   add_custom_target(symengine_nb_simple_funcs DEPENDS ${SYMENGINE_NB_SIMPLE_INC})
   ```
   Any `Python3` interpreter works (no 3.13 floor) — but the build already
   resolves `Python3_EXECUTABLE`, so reuse it.
3. Make `_core` depend on it (next to `CMakeLists.txt:151`):
   ```cmake
   add_dependencies(_core symengine_nb_simple_funcs)
   ```

### Step 1.4 — Edit `core_module.cpp`

1. Delete the three hand-written blocks (`core_module.cpp:1106`–`1211`, trig +
   hyperbolic + other-math) **and** the boolean/relational constructor block
   (`Eq Ne Ge Gt Le Lt`, `core_module.cpp:1214`–`1237`).
2. In their place put a single include with a short pointer comment:
   ```cpp
   // Simple direct-RCP functions (trig, hyperbolic, special, relational).
   // Generated from simple_functions.json by gen_simple_functions.py.
   #include "symengine_simple_funcs.inc"
   ```
   It must sit **inside** `NB_MODULE(_core, m)` where `m` is in scope (the old
   blocks were), and the include path resolves because the build `generated/`
   dir is already on `_core`'s include path (`CMakeLists.txt:139`).
3. Leave everything else (arithmetic dunders at the top, `add/sub/mul/...`,
   `logical_*`, ntheory, sets, etc.) untouched in Phase 1.

> Keep the generated `m.def` text **byte-identical** to what you deleted (same
> arg names, same order). The point of Phase 1 is a no-op refactor you can prove
> with the existing test suite.

### Step 1.5 — Update sdist + policy scripts

- `scripts/check_generated_policy.sh`: the new `.inc` lives under
  `generated/` and is covered by the existing `*` gitignore + the `git ls-files`
  check, so **no change needed** — but verify `simple_functions.json` and
  `gen_simple_functions.py` **are** tracked (they are inputs, not outputs) and
  the `.inc` is **not**. Add a one-line assertion to the script if you want
  belt-and-suspenders.
- `scripts/make_sdist.sh`: ensure the new source files
  (`simple_functions.json`, `gen_simple_functions.py`) are copied into the
  sdist alongside `generate.py`. Since the build regenerates the `.inc`
  unconditionally, you do **not** need to ship a pre-baked `.inc` — but you
  **must** ship the JSON + renderer. Find where `generate.py`/`generate.yaml`
  are staged and add these two next to them.

### Phase 1 goal criteria

- `gen_simple_functions.py --input simple_functions.json --output /tmp/x.inc`
  runs with stock CPython (no extra deps) and produces a `.inc` whose `m.def`
  lines match the deleted C++ (diff the old block against the generated one).
- Clean build of `_core` succeeds (both source-checkout and a `make_sdist.sh`
  tarball build).
- The full existing pytest suite passes unchanged, in particular
  `tests/test_generated_smoke.py` and `tests/test_generated_rcp.py`, plus any
  `python-bindings` tests that call `sin`, `Eq`, etc.
- `git status` shows `simple_functions.json` + `gen_simple_functions.py` as new
  tracked files and **no** generated `.inc` tracked.

---

## 5. Phase 2 — single source of truth for stubs and excludes

Now remove the *other two* hand-maintained copies of the Phase-1 names.

### Step 2.1 — Stubs come from the table

In `generate.py`:

1. `import gen_simple_functions` (it sits in the same directory; `generate.py`
   already does `sys.path.insert(0, str(Path(__file__).parent))` at line 23).
2. Delete the hand-typed Trig/Hyperbolic/Other/Boolean stub lines from the
   `_MANUAL_FUNCTION_STUBS` string literal (`generate.py:69`–`118`, the lines
   corresponding to the Phase-1 functions only — leave `add/sub/mul/div/pow`,
   number theory, sets, constants, utility stubs alone for now).
3. Where those lines were, inject
   `"\n".join(gen_simple_functions.stub_lines(entries))` (load the JSON via the
   same path CMake uses). Keep the section comments.

### Step 2.2 — `fn_exclude` comes from the table

The Phase-1 `cpp` names are listed by hand in `generate.yaml`'s `fn_exclude`
(e.g. the trig/hyperbolic names are excluded so litgen doesn't double-bind
them). In `generate.py`, after loading the YAML excludes
(`generate.py:452`–`454`), extend them programmatically:

```python
fn_excludes = module.get("fn_exclude", [])
fn_excludes += gen_simple_functions.excluded_names(entries)
```

Then **remove** the now-redundant trig/hyperbolic/relational names from
`generate.yaml` (keep a short comment: `# trig/hyperbolic/relational excludes
are injected from simple_functions.json by generate.py`). Be conservative: only
remove names you actually added back programmatically; cross-check by diffing
the set before/after (print `sorted(set(fn_excludes))` once and compare).

### Phase 2 goal criteria

- `simple_functions.json` is now the **only** place the Phase-1 function set is
  spelled out. Grep proves it: the names no longer appear in `generate.py`'s
  string literal nor (for the excluded ones) hand-written in `generate.yaml`.
- Regenerated `symengine.pyi` is identical (modulo ordering) to before — diff
  the old vs new stub; the Phase-1 `def` lines must still be present with the
  same signatures.
- `mypy`/`pyright` over `python-bindings` (whatever the repo runs) still passes;
  `import nbsymengine; nbsymengine.sin` etc. resolve.
- litgen still does not double-bind these (no duplicate-registration error at
  import — nanobind would raise at module init if it did).

---

## 6. Phase 3 — extend the table to the rest of the hand-written section

Apply the same mechanism to the remaining repetitive families. Add new `kind`s
to `gen_simple_functions.py`, one family at a time, each its own commit + test
run. Transcribe behavior **exactly** (these have edge cases — keep them):

- **`integer_unary` / `integer_binary`** (Opportunity E): take
  `RCP<const Integer>`, call with `*a`. e.g. `nextprime`, `totient`,
  `carmichael`, `gcd`, `lcm` (`core_module.cpp:1285`–`1307`). Note `gcd`/`lcm`
  return `RCP<const Basic>` from `SymEngine::gcd(*a,*b)`.
- **`status_optional`** (Opportunity F): the `outArg(x)` + `int/bool status` →
  `nb::object` (return `nb::cast(x)` or `nb::none()`) family: `mod_inverse`,
  `primitive_root`, `factor`, `nthroot_mod`, `powermod`, `multiplicative_order`
  (`core_module.cpp:1377`–`1514`). These differ in arity and arg types — model
  that in the schema (`"params": [{"name":"a","type":"Integer"}, ...]`,
  `"out":"Integer"`). Several have default args (`factor` `B1=1.0`,
  `factor_pollard_*` retries) — add an optional `"defaults"` field.
- **`list_basic`** (Opportunity G): functions filling a
  `std::vector<RCP<const Integer>>` then repackaging into
  `std::vector<RCP<const Basic>>`: `prime_factors`, `primitive_root_list`,
  `nthroot_mod_list`, `powermod_list` (`core_module.cpp:1395`–`1481`).

For each family, also move its stubs out of `_MANUAL_FUNCTION_STUBS` and its
names out of `generate.yaml`'s `fn_exclude` (same as Phase 2).

> Functions with genuinely unique bodies (the `mod` zero-division guard at
> `core_module.cpp:1309`, `quotient_mod` tuple returns, `cse`, the matrix
> factories, the `_make_derivative`/`subs`/`xreplace` dict-walkers) are **not**
> worth templating — leave them hand-written. The win is in the families above,
> not in one-offs. Stop when the remaining hand-written functions are all
> distinct shapes.

### Phase 3 goal criteria

- Each family commit keeps the full test suite green.
- After Phase 3, the only hand-written `m.def`s left in `core_module.cpp` are
  genuinely one-of-a-kind (guards, tuple returns, dict walkers, matrix/lambdify
  bindings). The repetitive families are gone.

---

## 7. Phase 4 — completeness cross-check against `type_codes.inc` (a test, not codegen)

Add a pytest, e.g. `tests/test_function_coverage.py`, that:

1. Parses `symengine/symengine/type_codes.inc` for every
   `SYMENGINE_ENUM(..., Name)` whose `Name` is a unary/binary math function
   class (you can keep an explicit allow/skip set for non-function entries like
   `Integer`, `Add`, matrix types, sets).
2. Maps each to its expected free-function name and asserts it is either present
   in `simple_functions.json` **or** in an explicit `WAIVED` set (with a reason
   comment). This turns "we forgot to bind `cot`/`csch`/`acosh`/…" into a
   failing test rather than a silent gap.

This is also where you'd **opt in** to binding the currently-missing functions
(`cot csc sec acot asec acsc coth asinh acosh atanh acoth asech acsch
kronecker_delta`): add them to `simple_functions.json`, and because Phases 1–2
already wired stubs+excludes from the table, that single edit binds them, types
them, and excludes them from litgen — exactly the "one-line change" payoff this
whole plan is for. (Verify each has a real `SymEngine::` free function first;
add a matching test asserting `sin(Symbol("x"))`-style round-trips.)

### Phase 4 goal criteria

- New coverage test passes and fails loudly if a function class in
  `type_codes.inc` is neither bound nor explicitly waived.
- If you opted into new functions, each has a behavioral test and appears in the
  generated `.pyi`.

---

## 8. Out of scope / explicitly leave alone

- The litgen pipeline itself (`adapt_rcp_basic.py`, `preprocess.py`,
  `_SYMENTITY_HIERARCHY`, the `is_*` stub re-injection). The `_SYMENTITY_HIERARCHY`
  dict (`generate.py:304`) *looks* like a codegen target, but its base-class
  relationships are **not** derivable from `type_codes.inc` (which has no
  hierarchy info), so deriving it would need a second hand-maintained mapping —
  no net win. Leave it.
- Matrix bindings, lambdify/LLVM classes, the singleton atexit cleanup,
  arithmetic dunders — all genuinely bespoke.
- Do not change the "generated files are not tracked; sdist ships pre-baked
  litgen output" policy. The new `.inc` follows that policy; the new `.json` +
  renderer are tracked **inputs**.

## 9. Summary of files touched

| File | Phase | Change |
|------|-------|--------|
| `simple_functions.json` | 1 | **new**, tracked — source of truth |
| `gen_simple_functions.py` | 1 | **new**, tracked — stdlib renderer |
| `generated/symengine_simple_funcs.inc` | 1 | **new**, *not* tracked — build output |
| `src/core_module.cpp` | 1,3 | delete hand-written family blocks → `#include` |
| `CMakeLists.txt` | 1 | add custom command/target + `_core` dependency |
| `scripts/make_sdist.sh` | 1 | stage the new `.json` + `.py` |
| `scripts/check_generated_policy.sh` | 1 | (optional) assert `.inc` untracked |
| `generate.py` | 2,3 | import renderer; inject stubs + excludes; delete duplicated literals |
| `generate.yaml` | 2,3 | remove now-injected `fn_exclude` names |
| `tests/test_function_coverage.py` | 4 | **new** completeness test |

## 10. Definition of done

1. Adding one trig/special/ntheory function of an existing shape is a **one-line
   edit** to `simple_functions.json` — no C++, no `.pyi`, no `generate.yaml`.
2. The Phase-1 function set is spelled out in exactly **one** place.
3. Full existing test suite is green in both source-checkout and sdist builds.
4. No generated artifact is tracked in git (`check_generated_policy.sh` passes).
</content>
</invoke>
