# 18b ASAN CI Review

Consultant claim review: mostly directionally correct on the final goal, but the implementation had brittle boundaries that needed cleanup before it was fit to keep.

What I changed:

- Kept the ASAN Python wrapper in CI, because direct use of the ASAN Python binary still broke C++ exception paths without `libc++abi` preloading.
- Moved that wrapper behavior back behind CI/toolchain setup only.
- Removed hardcoded `/tmp/python-asan-wrapper` assumptions from `nbsymengine` tests and replaced them with `NBSYMENGINE_SUBPROCESS_PYTHON`.
- Removed ASAN-specific `LD_PRELOAD` / `LD_LIBRARY_PATH` mutation from package import paths.
- Tightened ASAN discovery and validation in `.ci/ci-common.sh` and `.ci/run-ci-steps.sh`.
- Kept the minimal ASAN `nbsymengine` lane shape: core CTest subset plus `test_lambdify_direct.py`, with downstream `scipy`-dependent coverage still left out.
- Added LSAN suppression usage for expected CPython startup/runtime leaks.
- Removed repeated ASAN compile-time `-stdlib=libc++` warning noise while preserving link-time libc++ selection.

Verification:

- `bash .ci/run-ci-steps.sh` passed on 2026-06-14 UTC.
- Post-cleanup reruns also passed:
  - `SYMENGINE_VARIANT=asan .ci/ci-01-build-and-test.sh` with 56/56 C++ tests passing
  - `SYMENGINE_VARIANT=asan .ci/ci-02-build-and-test-nbsymengine.sh` with 9/9 CTest plus `42 passed, 17 skipped` in pytest

Residual note:

- The default `nbsymengine_compat` stage still prints nanobind leak diagnostics at interpreter shutdown. That output does not fail CI and was not part of the ASAN lane fix.
