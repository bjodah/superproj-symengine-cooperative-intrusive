I'm looking for opportunities to generate a larger portion of the binding code 
in e.g. `nbsymengine/bindings/python_nanobind/src/core_module.cpp` programatically.

Take for example the sections with headings "// Trig functions (direct RCP)",
"// Hyperbolic functions (direct RCP)", "// Other math functions (direct RCP)". It feels
to me that we should be able to render that part of the source file based on e.g. 
`symengine/symengine/type_codes.inc`, or at least from a .json file with all unary function
names listed?

See if you can identify any further such opportunities. Then write a detailed implementation plan
of your recommended improvements, with clear instructions for a junior developer to follow (what files
to edit, why, and how, goal criteria etc.). Save the plan as docs/plans/06-IMPL-PLAN-BETTER-CODEGEN.md
