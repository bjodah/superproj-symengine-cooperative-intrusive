# 22 - Further Extension Improvements

**Date:** 2026-06-17
**Status:** Proposed, revised after local viability checks
**Audience:** Junior developer implementing the next cooperative-runtime work

## Summary

The PHP extension is no longer just a sketch. It has a minimal binding surface,
PHPT ownership tests, CLI subprocess teardown tests, debug ownership probes, and
super-project CI wiring. The next phase should therefore focus on strengthening
evidence, not on broad API growth.

The main outcome of this phase is a defensible cross-runtime story for
`cooperative_intrusive`: PHP and Perl should exercise the same backend
invariants, any PHP SAPI uncertainty should be explicit, and the small amount of
new binding surface should exist only because it improves lifetime or
canonicalization coverage.

## Local Viability Checks Already Performed

These checks were run on 2026-06-17 while revising this plan. Treat them as
inputs to the plan, not as permanent project guarantees.

```bash
LD_LIBRARY_PATH=/tmp/inst-se-php/lib:${LD_LIBRARY_PATH:-} \
TEST_PHP_EXECUTABLE=$(command -v php) \
EXTENSION_DIR=/tmp/bld-php-ext/modules \
php run-tests.php -q \
  -d extension=/tmp/bld-php-ext/modules/symengine.so \
  tests/*.phpt
```

Result: all 7 current PHP CLI PHPT tests passed.

```bash
LD_LIBRARY_PATH=/tmp/inst-se-php/lib:${LD_LIBRARY_PATH:-} \
php -d extension=/tmp/bld-php-ext/modules/symengine.so -r '
foreach (["SymEngine\\Basic", "SymEngine\\Integer", "SymEngine\\Symbol"] as $class) {
    $o = new $class();
    echo "$class: constructed ", get_class($o), "\n";
}'
```

Result: direct construction is currently allowed for all three classes. A
separate probe showed methods on `new SymEngine\Basic()` throw
`SymEngine object has no native pointer`. This is usable as a regression target:
direct construction should be banned or should throw a clearer constructor
error.

```bash
LD_LIBRARY_PATH=/tmp/inst-se-php/lib:${LD_LIBRARY_PATH:-} \
php -d extension=/tmp/bld-php-ext/modules/symengine.so -r '
$x = symengine_symbol("x");
$again = symengine_add($x, symengine_zero());
var_dump($x === $again, $x->sameObject($again), $x->phpRefCount());
'
```

Result: canonical `add(x, 0)` reuses the same PHP wrapper. This means PHP can
mirror the Perl `add(x, 0)` identity-reuse test directly.

```bash
LD_LIBRARY_PATH=/tmp/inst-se-php/lib:${LD_LIBRARY_PATH:-} \
php -d extension=/tmp/bld-php-ext/modules/symengine.so -r '
$x = symengine_symbol("x");
echo "x0=", $x->phpRefCount(), "\n";
$expr = symengine_add($x, symengine_integer(1));
echo "x1=", $x->phpRefCount(), " expr=", symengine_str($expr), "\n";
unset($expr);
echo "x2=", $x->phpRefCount(), "\n";
'
```

Result: the operand wrapper refcount increased while the expression held a C++
`RCP` and returned to the previous value after the expression was released.
This is viable PHP coverage for the same invariant Perl tests with
`perl_refcount`.

```bash
g++ -std=c++17 \
  -I/tmp/inst-se-php/include \
  -L/tmp/inst-se-php/lib \
  -Wl,-rpath,/tmp/inst-se-php/lib \
  -x c++ - -lsymengine -lgmp \
  -o /tmp/symengine_ops_probe <<'CPP'
#include <symengine/add.h>
#include <symengine/constants.h>
#include <symengine/functions.h>
#include <symengine/integer.h>
#include <symengine/mul.h>
#include <symengine/pow.h>
#include <symengine/symbol.h>
#include <iostream>

int main() {
    using namespace SymEngine;
    cooperative_intrusive_init(nullptr, nullptr);
    auto x = symbol("x");
    auto y = symbol("y");
    auto two = integer(2);
    auto three = integer(3);
    std::cout << "sub(x,y)=" << sub(x, y)->__str__() << "\n";
    std::cout << "div(3,2)=" << div(three, two)->__str__() << "\n";
    std::cout << "neg(x)=" << neg(x)->__str__() << "\n";
    std::cout << "sin(x)=" << sin(x)->__str__() << "\n";
    std::cout << "add(x,0)-same=" << (add(x, zero).get() == x.get()) << "\n";
}
CPP
/tmp/symengine_ops_probe
```

Result:

```text
sub(x,y)=x - y
div(3,2)=3/2
neg(x)=-x
sin(x)=sin(x)
add(x,0)-same=1
```

`symengine_sub`, `symengine_div`, `symengine_neg`, and `symengine_sin` are all
viable thin additions if tests justify them.

```bash
g++ -std=c++17 \
  -I/tmp/inst-se-php/include \
  -L/tmp/inst-se-php/lib \
  -Wl,-rpath,/tmp/inst-se-php/lib \
  -x c++ - -lsymengine -lgmp \
  -o /tmp/symengine_detach_probe <<'CPP'
#include <symengine/symengine_rcp.h>
#include <iostream>
#include <stdexcept>

using SymEngine::EnableRCPFromThis;
using SymEngine::RCP;
using SymEngine::make_rcp;

struct Node : EnableRCPFromThis<Node> {};

static int inc_count = 0;
static int dec_count = 0;
static void inc_hook(void *) noexcept { ++inc_count; }
static void dec_hook(void *) noexcept { ++dec_count; }

int main() {
    alignas(2) static char owner_storage;
    void *owner = &owner_storage;
    SymEngine::cooperative_intrusive_init(inc_hook, dec_hook);

    RCP<Node> a = make_rcp<Node>();
    RCP<Node> b = a;
    if (a->use_count() != 2) throw std::runtime_error("expected inline count 2");

    a->set_self_external(owner);
    if (!a->is_external_owned()) throw std::runtime_error("expected external owned");
    if (a->use_count() != 0) throw std::runtime_error("external use_count must be 0");
    if (inc_count != 2) throw std::runtime_error("handoff should replay 2 refs");

    void *old = a->detach_external();
    if (old != owner) throw std::runtime_error("detach returned wrong owner");
    if (a->is_external_owned()) throw std::runtime_error("detach should return inline mode");
    if (a->use_count() != 0) throw std::runtime_error("detach starts inline count at 0");

    a->inc_ref();
    a->inc_ref();
    if (a->use_count() != 2) throw std::runtime_error("replay should restore inline count 2");

    b = SymEngine::null;
    if (a->use_count() != 1) throw std::runtime_error("dropping b should leave count 1");
    std::cout << "detach/replay probe passed\n";
}
CPP
/tmp/symengine_detach_probe
```

Result: `detach/replay probe passed`. This should become a real core C++ test
because it directly covers the singleton reconciliation primitive used by PHP
and Perl.

`php-fpm` was not present on the local PATH during the original revision of
this plan. It was installed during implementation and a local FPM smoke harness
was run successfully; see `docs/reports/22b-PHP-SAPI-LIFECYCLE.md`.

## Current State

### PHP

Relevant files:

- `symengine.php/src/symengine_php.h`
- `symengine.php/src/symengine_php.cpp`
- `symengine.php/src/cooperative_hooks.cpp`
- `symengine.php/tests/*.phpt`
- `symengine.php/README.md`
- `.ci/ci-06-build-and-test-php.sh`

What exists:

- raw-pointer holder model in `symengine_object`
- cooperative hooks mapping `inc_ref` and `dec_ref` to Zend object references
- identity reuse through `self_external()`
- singleton seed list matching the currently exposed constants
- `RSHUTDOWN` singleton reconciliation with `detach_external()` plus `inc_ref()`
- `MSHUTDOWN` transition that makes PHP cooperative hooks inert
- PHPT coverage for load, basic operations, singleton identity, external
  ownership, temporary native handles, singleton teardown, and expression teardown
- debug helpers on `SymEngine\Basic` when `SYMENGINE_PHP_DEBUG_HELPERS` is enabled

Known gaps:

- no Apache module validation
- current teardown subprocess PHPTs use `exec()` without an explicit timeout
- no PHP sanitizer lane
- direct `new SymEngine\Basic`, `new SymEngine\Integer`, and
  `new SymEngine\Symbol` produce wrappers with null native pointers
- PHP does not yet have a test matrix paired line-by-line with Perl
- PHP does not yet expose subtraction, division, negation, or `sin`, although
  these are already present in Perl and viable in C++

### Perl

Relevant files:

- `symengine.pl/xs/perl_symengine.h`
- `symengine.pl/xs/perl_symengine.cpp`
- `symengine.pl/xs/SymEngine.xs`
- `symengine.pl/t/04-cooperative.t`
- `symengine.pl/t/05-teardown.t`
- `docs/plans/19-PERL-EXTENSION.md`

What exists:

- raw-pointer holder model in `BasicHolder`
- cooperative hooks mapping `inc_ref` and `dec_ref` to `SvREFCNT`
- identity reuse through `self_external()`
- explicit `add(x, 0)` wrapper-reuse test
- explicit operand-wrapper pinning test using `perl_refcount`
- final release test for non-singleton external-owned objects
- child-interpreter teardown test with live singletons and expressions under
  `PERL_DESTRUCT_LEVEL=2`
- singleton reconciliation via `call_atexit`
- `PL_phase == PERL_PHASE_DESTRUCT` guard in `DESTROY`

Known gaps:

- Perl is stronger than PHP as a teardown reference, but its README still has
  older wording in places; use `docs/plans/19-PERL-EXTENSION.md` as the current
  source of truth until the README is refreshed
- Perl singleton seeding must be revisited only if its XS surface grows to
  expose additional singleton-backed objects

## Phase Rules

Follow these rules throughout this phase:

- Prefer tests and documentation over new user-facing surface.
- Add PHP functions only when they unlock better ownership, canonicalization, or
  PHP/Perl comparison tests.
- Do not monkey-patch `nbsymengine` or depend on `nbsymengine_compat`.
- Do not store a strong `RCP<const Basic>` inside PHP or Perl holders.
- Keep singleton seed lists explicit and reviewable.
- When behavior differs between PHP and Perl, document the runtime reason rather
  than forcing false symmetry.
- Treat CLI, FPM, and Apache module behavior as separate claims.

## Preflight for Any Implementer

Start every implementation branch with these checks.

1. Inspect local changes:

```bash
git status --short
```

Do not revert unrelated user work. The PHP and Perl extension directories may be
untracked in this super-project; that is expected in the current workspace.

2. Build and test PHP from a clean pair of temporary directories:

```bash
rm -rf /tmp/se-php-plan-build /tmp/se-php-plan-install /tmp/se-php-ext-plan

SYMENGINE_RCP_CHOICE=cooperative_intrusive \
SYMENGINE_VARIANT=debug \
.ci/ci-01-build-and-test.sh \
  /tmp/se-php-plan-build \
  /tmp/se-php-plan-install

SYMENGINE_VARIANT=debug \
.ci/ci-06-build-and-test-php.sh \
  /tmp/se-php-plan-build \
  /tmp/se-php-plan-install \
  /tmp/se-php-ext-plan
```

Expected result: the current PHP PHPT suite passes. If this fails because
`ci-06-build-and-test-php.sh` assumes an install tree that does not exist, fix
the script or the CI orchestration before adding more PHP tests.

Note: `ci-01-build-and-test.sh` may require the Python/nanobind tooling used by
the broader super-project even though the PHP extension itself does not. If that
tooling is unavailable and the task is PHP-only, build SymEngine directly:

```bash
cmake -S symengine -B /tmp/se-php-plan-build -G Ninja \
  -DBUILD_SHARED_LIBS=ON \
  -DBUILD_TESTS=ON \
  -DBUILD_BENCHMARKS=OFF \
  -DCMAKE_INSTALL_PREFIX=/tmp/se-php-plan-install \
  -DSYMENGINE_RCP_BACKEND=cooperative_intrusive
cmake --build /tmp/se-php-plan-build -j"$(nproc)"
ctest --test-dir /tmp/se-php-plan-build --output-on-failure \
  -R 'test_cooperative_intrusive_rcp|test_rcp'
cmake --install /tmp/se-php-plan-build
```

3. Build and test Perl:

```bash
SYMENGINE_VARIANT=debug \
.ci/ci-05-build-and-test-perl.sh /tmp/se-perl-plan-build
```

Expected result: `perl_symengine` passes.

4. Confirm whether FPM tooling exists locally:

```bash
command -v php-fpm || command -v php-fpm8.4 || command -v php-fpm8.3 || command -v php-fpm8.2 || true
command -v cgi-fcgi || true
```

Expected result for automated FPM work: both a PHP-FPM binary and a FastCGI
client are available. If either is missing, document the missing package and
skip FPM automation until the environment is extended.

## Workstream A: Cross-Runtime Ownership Matrix

### Goal

Create a single document that pairs PHP and Perl tests by backend invariant.
This lets reviewers distinguish a core `cooperative_intrusive` failure from a
runtime integration failure.

### Deliverable

Create `docs/reports/22a-CROSS-RUNTIME-OWNERSHIP-MATRIX.md`.

Implemented at `docs/reports/22a-CROSS-RUNTIME-OWNERSHIP-MATRIX.md`.

### Required matrix rows

Use this exact initial row set:

| Invariant | PHP coverage | Perl coverage | Gap / action |
| --- | --- | --- | --- |
| Extension loads with cooperative backend | `tests/001-load.phpt` | `t/00-load.t` | None |
| Basic expression creation works | `tests/010-basic-ops.phpt` | `t/01-basic.t` | PHP lacks `sub`, `div`, `neg`, `sin` parity |
| Singleton identity reuse | `tests/020-identity-reuse.phpt` | `t/02-identity.t`, `t/04-cooperative.t` | None for `pi`; consider all exposed singleton constants |
| Canonical expression returns existing wrapper | Add `tests/025-canonical-identity-reuse.phpt` | `t/04-cooperative.t` | PHP missing; `add(x, 0)` is verified viable |
| Fresh wrapper externalizes object | `tests/030-external-ownership.phpt` | `t/04-cooperative.t` | None |
| C++ expression pins operand wrapper | Add `tests/045-expression-pins-operand.phpt` | `t/04-cooperative.t` | PHP missing; `phpRefCount()` probe is viable |
| Releasing expression releases operand pin | Add to `tests/045-expression-pins-operand.phpt` | `t/04-cooperative.t` | PHP missing |
| Final release of non-singleton object is safe | Existing PHP teardown smoke is indirect | `t/04-cooperative.t` | Add a focused PHP subprocess test if debug probes are not enough |
| Shutdown with live singleton wrappers | `tests/050-singleton-teardown.phpt` | `t/05-teardown.t` | Add timeout helper to PHP test |
| Shutdown with live composite expressions | `tests/060-expression-teardown.phpt` | `t/05-teardown.t` | Add timeout helper to PHP test |
| Singleton detach/replay core primitive | Add C++ test in `symengine/symengine/tests/rcp/test_cooperative_intrusive_rcp.cpp` | Shared by both runtimes | Core test missing |

### Implementation steps

1. Write the matrix document first, before changing tests.
2. In each matrix row, include the exact file path and test name.
3. Add a short "How to update this matrix" section saying every new PHP or Perl
   ownership test must either add a row or update an existing row.
4. Link the matrix from this plan when the file exists.

### Acceptance checks

Run:

```bash
rg -n "025-canonical|045-expression|detach/replay|RSHUTDOWN|call_atexit" \
  docs/reports/22a-CROSS-RUNTIME-OWNERSHIP-MATRIX.md
```

Expected result: all key planned coverage points appear in the matrix.

## Workstream B: Fill the Highest-Value PHP Ownership Gaps

### Goal

Make PHP cover the same two high-signal ownership cases that Perl already
covers explicitly: canonical wrapper reuse and expression-held operand pins.

### Add `tests/025-canonical-identity-reuse.phpt`

Test shape:

```php
<?php
$x = symengine_symbol('x');
$before = $x->phpRefCount();
$again = symengine_add($x, symengine_zero());

echo "same zval: ", ($x === $again ? "true" : "false"), "\n";
echo "same native: ", ($x->sameObject($again) ? "true" : "false"), "\n";
echo "refcount increased: ", ($x->phpRefCount() > $before ? "true" : "false"), "\n";

unset($again);
echo "refcount restored: ", ($x->phpRefCount() === $before ? "true" : "false"), "\n";
?>
```

Expected output:

```text
same zval: true
same native: true
refcount increased: true
refcount restored: true
```

Use relative refcount assertions. Do not assert exact Zend refcount values.

### Add `tests/045-expression-pins-operand.phpt`

Test shape:

```php
<?php
$x = symengine_symbol('x');
$before = $x->phpRefCount();
$expr = symengine_add($x, symengine_integer(1));
$during = $x->phpRefCount();

echo "expr: ", symengine_str($expr), "\n";
echo "operand pinned: ", ($during > $before ? "true" : "false"), "\n";

unset($expr);
echo "pin released: ", ($x->phpRefCount() === $before ? "true" : "false"), "\n";
?>
```

Expected output:

```text
expr: 1 + x
operand pinned: true
pin released: true
```

### Strengthen subprocess teardown tests with timeouts

Current tests `050-singleton-teardown.phpt` and `060-expression-teardown.phpt`
use `exec()` and can hang indefinitely if teardown deadlocks. Replace the
duplicated subprocess logic with a helper, for example
`symengine.php/tests/support/subprocess.php`.

The helper should:

- start the child with `proc_open`
- capture stdout and stderr
- poll with a deadline, defaulting to 10 seconds
- call `proc_terminate` if the deadline expires
- print the captured output before failing
- return the child exit code to the PHPT

Avoid relying on `pcntl_alarm`; `pcntl` is available in the current local CLI,
but `proc_open` polling is more portable across PHP CLI builds.

### Add a looped teardown stress test

Add `tests/065-loop-teardown.phpt` with a child script that:

- creates and drops many non-singleton expressions in a loop
- stores a small final set of live expressions in an array until process exit
- includes at least one singleton canonicalization path such as `add(x, 0)`
- exits normally

Keep the loop small, for example 500 iterations. This is a lifetime smoke test,
not a benchmark.

### Acceptance checks

Run:

```bash
LD_LIBRARY_PATH=/tmp/se-php-plan-install/lib:${LD_LIBRARY_PATH:-} \
TEST_PHP_EXECUTABLE=$(command -v php) \
EXTENSION_DIR=/tmp/se-php-ext-plan/modules \
php /tmp/se-php-ext-plan/run-tests.php -q \
  -d extension=/tmp/se-php-ext-plan/modules/symengine.so \
  /tmp/se-php-ext-plan/tests/025-canonical-identity-reuse.phpt \
  /tmp/se-php-ext-plan/tests/045-expression-pins-operand.phpt \
  /tmp/se-php-ext-plan/tests/050-singleton-teardown.phpt \
  /tmp/se-php-ext-plan/tests/060-expression-teardown.phpt \
  /tmp/se-php-ext-plan/tests/065-loop-teardown.phpt
```

Expected result: all listed PHPTs pass and no subprocess exceeds the timeout.

## Workstream C: Ban Direct PHP Wrapper Construction

### Goal

Prevent userland from creating wrapper objects with null native pointers.

### Why this is necessary

Local probes show `new SymEngine\Basic()`, `new SymEngine\Integer()`, and
`new SymEngine\Symbol()` currently construct objects. These objects are invalid
because `symengine_object::ptr` is null. Methods fail later with
`SymEngine object has no native pointer`, which is less clear than failing at
construction time.

### Implementation steps

1. Add a `__construct` method to `SymEngine\Basic` that throws an exception such
   as `SymEngine objects cannot be constructed directly; use symengine_integer(),
   symengine_symbol(), or SymEngine factory functions`.
2. Let `Integer` and `Symbol` inherit the same constructor unless PHP requires
   explicit method registration on each internal subclass.
3. Do not mark `Basic` abstract until after testing subclass behavior. A throwing
   constructor is enough and less likely to disturb internal allocation paths.
4. Add `tests/015-constructor-ban.phpt`.

### Test requirements

`tests/015-constructor-ban.phpt` should assert:

- `new SymEngine\Basic()` throws
- `new SymEngine\Integer()` throws
- `new SymEngine\Symbol()` throws
- factory functions still construct valid wrappers
- `symengine_integer(1) instanceof SymEngine\Integer`
- `symengine_symbol('x') instanceof SymEngine\Symbol`

### Acceptance checks

Run:

```bash
LD_LIBRARY_PATH=/tmp/se-php-plan-install/lib:${LD_LIBRARY_PATH:-} \
TEST_PHP_EXECUTABLE=$(command -v php) \
EXTENSION_DIR=/tmp/se-php-ext-plan/modules \
php /tmp/se-php-ext-plan/run-tests.php -q \
  -d extension=/tmp/se-php-ext-plan/modules/symengine.so \
  /tmp/se-php-ext-plan/tests/015-constructor-ban.phpt
```

Expected result: `015-constructor-ban.phpt` passes.

## Workstream D: Add a Small, Test-Justified PHP Surface

### Goal

Bring PHP just far enough toward Perl parity to build more representative
ownership and canonicalization tests.

### Add these first

Add these functions in one small patch:

- `symengine_sub(SymEngine\Basic $a, SymEngine\Basic $b): SymEngine\Basic`
- `symengine_div(SymEngine\Basic $a, SymEngine\Basic $b): SymEngine\Basic`
- `symengine_neg(SymEngine\Basic $value): SymEngine\Basic`

Add `symengine_sin` only if it is needed for direct parity with Perl teardown or
function-expression tests. The C++ API is viable, but do not add it merely to
grow the surface.

### Implementation steps

1. Update `symengine.php/src/symengine_php.h` declarations.
2. Include `<symengine/functions.h>` in `symengine_php.h` or
   `symengine_php.cpp` if adding `symengine_sin`.
3. Reuse the existing binary arginfo for `sub` and `div`.
4. Add unary arginfo for `neg` and `sin`.
5. Implement each function by unwrapping to `RCP<const Basic>`, calling the
   SymEngine C++ function, and passing the result to `symengine_wrap_basic`.
6. Register each function in `symengine_functions`.
7. Extend `tests/010-basic-ops.phpt` only for basic string outputs.
8. Add ownership-focused assertions in `025`, `045`, or `065` if the new
   operation is meant to support those tests.

### Expected string outputs

The local C++ probe produced:

| Expression | Expected string |
| --- | --- |
| `symengine_sub($x, $y)` | `x - y` |
| `symengine_div(symengine_integer(3), symengine_integer(2))` | `3/2` |
| `symengine_neg($x)` | `-x` |
| `symengine_sin($x)` | `sin(x)` |

### Acceptance checks

Run the full PHP PHPT suite:

```bash
LD_LIBRARY_PATH=/tmp/se-php-plan-install/lib:${LD_LIBRARY_PATH:-} \
TEST_PHP_EXECUTABLE=$(command -v php) \
EXTENSION_DIR=/tmp/se-php-ext-plan/modules \
php /tmp/se-php-ext-plan/run-tests.php -q \
  -d extension=/tmp/se-php-ext-plan/modules/symengine.so \
  /tmp/se-php-ext-plan/tests/*.phpt
```

Expected result: all tests pass. If a string output differs only by canonical
ordering, update the test to match SymEngine's actual canonical string; do not
special-case PHP.

## Workstream E: Add Core C++ Coverage for Detach/Reconcile

### Goal

Move the most important runtime-independent singleton reconciliation primitive
into SymEngine's core C++ tests.

### Implementation target

Edit `symengine/symengine/tests/rcp/test_cooperative_intrusive_rcp.cpp`.

### Add a test case named

```cpp
TEST_CASE("detach external and replay inline references", "[cooperative_intrusive_rcp]")
```

### Test behavior

The test should:

- create a fake external owner pointer with at least 2-byte alignment
- create a `Node` with two live `RCP<Node>` handles
- call `set_self_external(owner)`
- assert `is_external_owned()`
- assert `use_count() == 0` while external-owned
- assert the fake incref hook saw two transferred references
- call `detach_external()`
- assert the returned pointer equals `owner`
- assert the object is back in inline mode with `use_count() == 0`
- call `inc_ref()` twice to replay the two observed external references
- release one `RCP` and assert `use_count() == 1`
- let the remaining `RCP` clean up normally

### Why this belongs in core

PHP and Perl both rely on this sequence during singleton shutdown:

1. read the foreign wrapper refcount
2. detach the singleton from external-owned mode
3. replay the observed count into inline C++ references
4. let SymEngine static destructors later release those inline references

If this primitive regresses, both runtimes can fail even if their binding code is
unchanged.

### Acceptance checks

Configure a core build with tests enabled and run:

```bash
ctest --test-dir /tmp/se-php-plan-build --output-on-failure \
  -R '^test_cooperative_intrusive_rcp$'
```

Expected result: `test_cooperative_intrusive_rcp` passes.

## Workstream F: Validate PHP Beyond CLI

### Goal

Determine whether the current `RSHUTDOWN` and `MSHUTDOWN` design remains valid
under a multi-request SAPI, starting with FPM.

### Implementation result

Implemented as `symengine.php/tools/fpm-smoke.sh` and locally verified with
PHP-FPM 8.4.21 plus `cgi-fcgi`; see
`docs/reports/22b-PHP-SAPI-LIFECYCLE.md`.

### Add a local FPM smoke harness

Preferred path: `symengine.php/tools/fpm-smoke.sh`.

The harness should:

- require `php-fpm` or a versioned `php-fpm8.x` binary
- require `cgi-fcgi`
- create a temporary document root under `/tmp`
- create a temporary `php.ini` that loads the built `symengine.so`
- create a temporary FPM config under `/tmp`
- run FPM with `pm = static` and `pm.max_children = 1`
- preserve the SymEngine library path with `clear_env = no` or explicit
  `env[LD_LIBRARY_PATH]`
- send at least three FastCGI requests to the same worker
- stop FPM cleanly and assert the process exits without a crash

Use one worker so repeated requests exercise request shutdown in a persistent
process.

### Request scripts

Use three small request scripts:

1. `singleton.php`

```php
<?php
$GLOBALS['keep'] = [symengine_zero(), symengine_one(), symengine_pi()];
echo "singleton:", symengine_str($GLOBALS['keep'][2]), "\n";
```

2. `expression.php`

```php
<?php
$x = symengine_symbol('x');
$GLOBALS['expr'] = symengine_add(symengine_pow($x, symengine_integer(2)), symengine_one());
echo "expression:", symengine_str($GLOBALS['expr']), "\n";
```

3. `canonical.php`

```php
<?php
$x = symengine_symbol('x');
$again = symengine_add($x, symengine_zero());
echo "canonical:", ($x === $again ? "same" : "different"), "\n";
```

These globals are request globals, not proof of persistence across requests.
Their purpose is to keep wrappers alive until each request's shutdown path.

### Manual command shape

The final script can generate these files, but the underlying procedure should
look like this:

```bash
PHP_FPM=$(command -v php-fpm8.4 || command -v php-fpm)
export LD_LIBRARY_PATH=/tmp/se-php-plan-install/lib:${LD_LIBRARY_PATH:-}

"$PHP_FPM" -c /tmp/se-fpm/php.ini -y /tmp/se-fpm/php-fpm.conf -F &
FPM_PID=$!

SCRIPT_FILENAME=/tmp/se-fpm/docroot/singleton.php \
REQUEST_METHOD=GET \
cgi-fcgi -bind -connect 127.0.0.1:9077

kill "$FPM_PID"
wait "$FPM_PID"
```

The generated `php.ini` should set:

```ini
extension=/tmp/se-php-ext-plan/modules/symengine.so
```

### Document the result

Create `docs/reports/22b-PHP-SAPI-LIFECYCLE.md` with:

- exact PHP version and SAPI
- FPM command used
- extension path used
- whether repeated requests passed
- whether FPM shutdown passed
- whether stderr contained crashes, leaks, or warnings
- any limitation, especially if Apache module mode remains untested

### Acceptance checks

Run:

```bash
symengine.php/tools/fpm-smoke.sh \
  /tmp/se-php-plan-install \
  /tmp/se-php-ext-plan/modules/symengine.so
```

Expected result:

- all three request outputs match expected strings
- the FPM worker stays alive across requests
- stopping FPM exits cleanly
- the lifecycle report records the tested SAPI precisely

## Workstream G: Add Stronger PHP CI Validation

### Goal

Make lifetime regressions more likely to fail in automation.

### First fix the existing CI shape

`.ci/ci-06-build-and-test-php.sh` expects an installed SymEngine tree. Ensure
the full CI path either:

- runs `.ci/ci-01-build-and-test.sh` first with the same install prefix passed
  to `ci-06`, or
- makes `ci-06` explicitly build and install SymEngine before configuring the
  PHP extension.

Do this before adding sanitizer complexity.

### Add timeout protection

After Workstream B, subprocess teardown PHPTs should fail in about 10 seconds
instead of hanging. This is mandatory for CI.

### Add a debug/assertive PHP lane

Minimum acceptable lane:

- SymEngine `Debug`
- PHP extension built with `SYMENGINE_PHP_DEBUG_HELPERS=1`
- all PHPT ownership tests
- timeout-protected teardown tests

This exposes debug-only helper methods such as `cppUseCount`,
`externalOwnerAddress`, and `isSingletonSeeded`. Do not key this behavior off
plain `NDEBUG`: installed PHP headers may define `NDEBUG` even for a debug
SymEngine lane.

### Add ASAN only as a true instrumented lane

A weak smoke check was viable locally with:

```bash
LD_PRELOAD=$(gcc -print-file-name=libasan.so) \
ASAN_OPTIONS=detect_leaks=0 \
LD_LIBRARY_PATH=/tmp/inst-se-php/lib:${LD_LIBRARY_PATH:-} \
php -d extension=/tmp/bld-php-ext/modules/symengine.so -r '
$x = symengine_symbol("x");
$e = symengine_add($x, symengine_integer(1));
echo symengine_str($e), "\n";
'
```

This proves `libasan` preloading does not immediately break the local PHP CLI,
but it is not a real ASAN validation lane unless SymEngine and the PHP extension
are also compiled with sanitizer flags.

A real PHP ASAN lane should:

- build SymEngine with `-fsanitize=address`
- build `symengine.php` with compatible `CXXFLAGS` and `LDFLAGS`
- run PHP with the ASAN runtime preloaded if PHP itself is not ASAN-built
- set `ASAN_OPTIONS=symbolize=1:detect_leaks=0` initially, then revisit leak
  detection after suppressing PHP runtime noise
- run only the focused ownership PHPTs at first

If this is unstable, keep the debug/assertive lane and document why ASAN is
deferred.

### Acceptance checks

Run from a clean temp state:

```bash
rm -rf /tmp/se-php-ci-debug /tmp/se-php-ci-install /tmp/se-php-ci-ext
SYMENGINE_RCP_CHOICE=cooperative_intrusive \
SYMENGINE_VARIANT=debug \
.ci/ci-01-build-and-test.sh /tmp/se-php-ci-debug /tmp/se-php-ci-install

SYMENGINE_VARIANT=debug \
.ci/ci-06-build-and-test-php.sh \
  /tmp/se-php-ci-debug \
  /tmp/se-php-ci-install \
  /tmp/se-php-ci-ext
```

Expected result: no dependency on stale `/tmp` install trees and all PHPTs pass.

## Workstream H: Write the Shared Design Note

### Goal

Centralize the runtime-independent reasoning so future PHP, Perl, Python,
Swift, or Perl-like integrations do not rediscover the same invariants.

### Deliverable

Create `docs/reports/22c-COOPERATIVE-INTRUSIVE-CROSS-RUNTIME.md`.

### Required sections

Include these sections:

- "Tagged Counter State"
- "Foreign Owner Pointer Alignment"
- "Why Holders Store Raw Pointers"
- "Identity Reuse Through `self_external()`"
- "External-Owned `use_count() == 0`"
- "Temporary Native Handles"
- "Singleton Seed Lists"
- "Detach and Inline Replay"
- "When Hooks Become Inert"
- "Runtime-Specific Shutdown Policies"
- "Known Unverified SAPIs"

### Runtime policy table

Include a table like this:

| Runtime | Foreign owner pointer | Normal incref/decref | Reconcile point | Inert hook point |
| --- | --- | --- | --- | --- |
| PHP CLI | `zend_object *` | `GC_ADDREF` / `OBJ_RELEASE` | `RSHUTDOWN` | `MSHUTDOWN` |
| PHP FPM | `zend_object *` | `GC_ADDREF` / `OBJ_RELEASE` | `RSHUTDOWN` verified by local smoke | `MSHUTDOWN` verified by local smoke |
| Perl | blessed inner `SV *` | `SvREFCNT_inc` / `SvREFCNT_dec` | `call_atexit` during `perl_destruct` | `PL_phase` / cleanup flag |
| Python nanobind | Python object pointer | nanobind/Python refcount hooks | existing nanobind cleanup | existing nanobind cleanup |

Do not treat the FPM smoke as a broad SAPI matrix; it validates one persistent
worker shape.

### Acceptance checks

Run:

```bash
rg -n "Tagged Counter|Raw Pointers|self_external|use_count\\(\\).*0|RSHUTDOWN|call_atexit|FPM" \
  docs/reports/22c-COOPERATIVE-INTRUSIVE-CROSS-RUNTIME.md
```

Expected result: each required concept is present.

## Workstream I: Keep Perl as a Reference, Not a Churn Target

### Goal

Use Perl to compare PHP against a stronger teardown implementation without
making unnecessary XS changes.

### Do change Perl when

- PHP finds an ownership invariant that Perl does not test
- the XS surface expands to expose new singleton-backed objects
- docs are stale enough to mislead implementers

### Do not change Perl when

- the only reason is to make it look symmetrical with PHP
- a PHP-specific SAPI issue has no Perl equivalent
- the change would broaden API surface without improving ownership evidence

### Candidate Perl updates

1. Refresh `symengine.pl/README.md` to match
   `docs/plans/19-PERL-EXTENSION.md`, especially the raw-pointer holder and
   full cooperative ownership wording.
2. If PHP adds `symengine_div` or `symengine_sin` tests that reveal a new shared
   lifetime edge, add the same edge to `t/04-cooperative.t`.
3. If Perl exposes more constants later, extend `seed_singletons()` in
   `symengine.pl/xs/perl_symengine.cpp` in the same patch as the new exposure.

### Acceptance checks

Run:

```bash
SYMENGINE_VARIANT=debug \
.ci/ci-05-build-and-test-perl.sh /tmp/se-perl-reference-check
```

Expected result: `perl_symengine` passes.

## Workstream J: Upstream Readiness

### Goal

End this phase with a concrete statement of what evidence exists for an
upstream SymEngine `cooperative_intrusive` discussion.

### Deliverable

Create `docs/reports/22d-UPSTREAM-READINESS.md`.

### Required content

Include:

- list of PHP tests that validate backend-generic behavior
- list of Perl tests that validate backend-generic behavior
- list of core C++ tests that no longer require a foreign runtime
- list of runtime-specific behavior that should not move upstream
- list of remaining unknowns, especially non-CLI PHP SAPIs if still unresolved
- list of bugs found, grouped as "SymEngine core", "PHP binding", "Perl binding",
  or "CI/documentation"

### Candidate upstream material

- C++ tests for `detach_external()` and inline replay
- documentation for external-owned `use_count() == 0`
- documentation for the aligned foreign-owner pointer precondition
- documentation for why `is_uniquely_owned_by_cpp()` must be used instead of
  `use_count() == 1` under `cooperative_intrusive`
- backend fixes found by PHP or Perl validation

### Acceptance checks

Run:

```bash
rg -n "PHP|Perl|core C\\+\\+|remaining unknown|upstream|use_count|detach_external" \
  docs/reports/22d-UPSTREAM-READINESS.md
```

Expected result: the report is specific enough that an upstream PR description
can be drafted from it without rereading every PHP and Perl test.

## Recommended Execution Order

1. Run the preflight checks from clean temporary directories.
2. Fix any clean-CI orchestration issue before adding new tests.
3. Create the cross-runtime ownership matrix.
4. Add PHP `025` and `045` ownership tests.
5. Add timeout-protected subprocess helpers and `065` loop teardown.
6. Add the core C++ detach/replay test.
7. Ban direct PHP wrapper construction.
8. Add `sub`, `div`, and `neg` only after the ownership tests are stable.
9. Add FPM smoke validation when the environment has `php-fpm` and `cgi-fcgi`.
10. Add or defer PHP ASAN based on a true instrumented build, not just
    `LD_PRELOAD`.
11. Write the shared design note and upstream readiness report.
12. Refresh Perl docs only if they are actively misleading for this phase.

## Definition of Done

This phase is complete when:

- `docs/reports/22a-CROSS-RUNTIME-OWNERSHIP-MATRIX.md` exists and maps PHP,
  Perl, and core C++ coverage by invariant
- PHP has explicit canonical wrapper-reuse and expression-held operand-pin tests
- PHP teardown subprocess tests have timeouts
- direct PHP wrapper construction fails clearly
- SymEngine core has a detach/replay regression test
- PHP non-CLI SAPI behavior is either validated under FPM or documented as
  unverified with exact missing tooling
- PHP CI can run from clean temporary directories without relying on stale
  installs
- any ASAN claim is backed by an instrumented SymEngine and extension build, or
  ASAN is explicitly deferred
- any new PHP surface is limited to test-justified operations
- the shared design note and upstream readiness report exist

## Risks and Mitigations

### FPM behavior differs from CLI

Impact: `RSHUTDOWN` or `MSHUTDOWN` assumptions may be too CLI-specific.

Mitigation: keep the FPM harness separate, run with one persistent worker, and
document the exact SAPI tested.

### API growth distracts from lifetime validation

Impact: more binding code but little additional confidence.

Mitigation: require every new function to support a named ownership,
canonicalization, or PHP/Perl parity test.

### Sanitizer lane gives false confidence

Impact: preloading ASAN into an uninstrumented PHP process can look stronger than
it is.

Mitigation: call it a smoke check unless SymEngine and the extension are built
with sanitizer flags.

### PHP and Perl docs drift

Impact: reviewers spend time rediscovering which runtime owns which part of the
shutdown story.

Mitigation: keep the cross-runtime design note authoritative and link runtime
specific docs back to it.

## Immediate Next Task

Create `docs/reports/22a-CROSS-RUNTIME-OWNERSHIP-MATRIX.md`, then add
`tests/025-canonical-identity-reuse.phpt` and
`tests/045-expression-pins-operand.phpt` to close the two highest-value PHP
coverage gaps already proven viable by local probes.
