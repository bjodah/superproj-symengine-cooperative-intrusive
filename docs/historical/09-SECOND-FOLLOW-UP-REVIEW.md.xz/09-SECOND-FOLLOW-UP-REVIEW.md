# 09 — Second Follow-up Review: commit `2ef8f81` (NB1 fix)

**Commit:** `2ef8f81fb888058a621218b03e56f8791b2a757a` — *"fix: anchor
excluded_names() patterns to prevent substring collisions"* (submodule
`nbsymengine`).
**Scope:** verifies the NB1 regression fix and the three minor items from
review `08`.

## Verdict

**Approve.** All four items from review 08 are correctly addressed. The fix is
small, focused, and well-tested. No new issues introduced.

---

## Per-item verification

| Review 08 item | Status | Evidence |
|----------------|--------|----------|
| **NB1** anchor exclusion patterns | ✅ Fixed | `excluded_names()` now returns `rf"^{re.escape(e['cpp'])}$"` (`gen_simple_functions.py:308`). Independently verified: `re.search` against `Constant`, `LeviCivita`, `Equality`, `LessThan`, `Abs`, `Cos`, `Sin`, `Tan`, `Log`, `Symbol`, `Function` all return `None`; exact names `tan`, `Le`, `Eq` still match. |
| De-mutate `fn_excludes` | ✅ Fixed | `generate.py:398-401` uses spread `[...module.get(...), *excluded_names(...)]` — no mutation of the parsed YAML config list. |
| Guard tests | ✅ Added | `TestExclusionAnchoring` (5 cases): 2 negative (`Constant`, `LeviCivita` not matched) + 3 positive (`tan`, `Le`, `Eq` still matched). Test builds the combined `|`-joined regex and uses `re.search`, accurately simulating litgen's consumer path. |
| `generate.yaml` comment | ✅ Clarified | Lines 210–211 note the anchored patterns are "a defensive no-op today" guarding against future changes. |

---

## Code quality notes (non-blocking)

- **`re.escape()` is currently a no-op** — all 57 `cpp` names are pure
  alphanumeric. Correct to include it anyway: future JSON entries with special
  regex characters (unlikely but possible) will be safe.
- **Test coverage is adequate** — the two negative cases target the exact
  regression (substring collisions from `tan`⊂`Constant`, `Le`⊂`LeviCivita`).
  The three positive cases span short relational (`Eq`, `Le`) and trig (`tan`)
  names. A brute-force sweep of all 14 short names (≤3 chars) against known
  SymEngine class names would be marginally more thorough, but the current set
  is sufficient.
- **YAML `fn_exclude` entries remain unanchored** — this is intentional and
  correct. Entries like `is_zero` deliberately match member methods on `Integer`,
  `Rational`, etc. (see `generate.yaml:177-180`). The anchoring only applies to
  the table-driven `excluded_names()` output, which is the right scope.

---

## Carry-over (still open)

1. **Full build + test run not independently reproduced.** Neither review 07, 08,
   nor this review performed a compile + full pytest run. The commit message for
   `2ef8f81` does not claim one either. This remains pending until CI confirms
   clean results (380+ passed, 0 failures) with the anchored patterns active.
2. **Optional next step (unchanged from reviews 07/08):** the 13 inverse/
   hyperbolic functions in the coverage `WAIVED` set (`cot`, `csc`, `sec`,
   `acot`, `asec`, `acsc`, `coth`, `asinh`, `acosh`, `atanh`, `acoth`,
   `asech`, `acsch`) are one-line JSON additions each — a good follow-up that
   would also serve as a real-world test of the anchored exclusion machinery.
