I'd like you to:

- Consolidate (break out) ./symengine/python-bindings/ & ./symengine/bindings/ into ./nbsymengine
- Move ./symengine/.ci/ & ./symengine/.woodpecker.yaml up one folder to this super-project root: ./ (we will use this superproject for CI testing).
- In the submodule ./symengine/, remove its submodules `external/symengine.py` and `external/nbsymengine_compat`. (these now live directly under this super-project and will from now on be "sister" checkouts to the `symengine/` submodule)
- Move/extract (and rework for new folder structure) ./symengine/python-bindings/benchmarks/ to ./benchmarks/ (currently an empty folder)

These changes will allow the changeset in ./symengine/ compared to its master branch to be much smaller (which will increase its chances of being accepted as a PR for future upstreaming).

