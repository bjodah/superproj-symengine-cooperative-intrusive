# Report 03: LLVM Performance Gap Analysis

**Date:** 2026-06-08  
**Author:** Automated analysis via sequential subagents  
**Status:** Complete

## Executive Summary

The 2.06x performance gap between legacy-symengine (1.47 us) and nbsymengine-llvm
(3.02 us) on the `ion_speciation` benchmark is **not caused by LLVM JIT code quality**
— both use the identical `LLVMDoubleVisitor` from `symengine/llvm_double.h`. The gap
is entirely attributable to **Python-side overhead**: array conversion, output
construction, and the absence of a zero-validation calling convention in nanobind.

For the `heterogeneous_output` benchmark (827x gap), the bottleneck is
`_float_to_basic()` — a function that converts every float through
`fractions.Fraction` string parsing and SymEngine object creation, accounting for
**87.7% of total call time**.

## Hypotheses Tested

| # | Hypothesis | Verdict | Contribution to Gap |
|---|------------|---------|---------------------|
| H1 | Python dispatch overhead (nanobind vs Cython) | **Not confirmed** | nanobind wrapper is 1.9 us *faster* |
| H2 | Array conversion / NumPy overhead | **Confirmed** | 62.5% of total `__call__` time |
| H3 | Output layout restoration (`_float_to_basic`) | **Confirmed (massive)** | 98.9% of heterogeneous output time |
| H4 | LLVM code quality differences | **Rejected** | Identical LLVM codegen |
| H5 | Call interface (ndarray vs memoryview) | **Confirmed (minor)** | ~190 ns per call |
| H6 | CSE / expression optimization differences | **Rejected** | Identical defaults, negligible impact |

## Detailed Findings

### H1: Python Dispatch Overhead — NOT CONFIRMED

**Surprising finding:** nanobind's Python wrapper is **1.9 us faster** than legacy
Cython's wrapper. The legacy `__call__` does extensive shape validation, broadcasting
logic, and output reshaping that the simpler nanobind `Lambdify.__call__` avoids.

| Layer | nanobind (LLVM) | Legacy Cython |
|-------|----------------|---------------|
| Full `__call__` | 3.075 us | 4.588 us |
| Native `.call()` dispatch | 0.952 us | 0.521 us |
| Python wrapper overhead | 2.123 us | 4.067 us |

The legacy `Lambdify.__call__` is slower than nanobind's because it does more work
in Python (numpy array manipulation, shape checks, broadcasting). However, legacy
also provides `unsafe_real()` with Cython typed memoryviews, which bypasses all of
this — and the benchmark adapter uses `__call__`, not `unsafe_real()`.

**Conclusion:** The dispatch mechanism itself is not the bottleneck. The nanobind
wrapper is actually leaner.

### H2: Array Conversion Overhead — CONFIRMED (62.5%)

The `Lambdify.__call__` path for the LLVM backend does:

```python
inp_list = list(inp.flat)                    # 0.5 us (17.1%)
inp_arr = np.asarray(inp_list, float64)      # 0.5 us (15.4%)
out_arr = np.empty(n_flat, float64)          # 0.2 us  (5.9%)
self._native.call(inp_arr, out_arr)          # 0.9 us (29.2%)  ← actual C++ eval
result = list(out_arr)                        # 0.7 us (24.0%)
```

**Total: 3.0 us, of which 2.1 us (71%) is array conversion.**

The input roundtrip is particularly wasteful: the benchmark adapter passes a numpy
array, which `__call__` converts to a list (`list(inp.flat)`), then immediately
converts back to a numpy array (`np.asarray(inp_list)`). This 1.0 us roundtrip is
pure waste.

The output conversion (`list(out_arr)`) at 0.7 us creates a Python list from the
numpy output array — unnecessary when the caller could accept a numpy array directly.

**Estimated savings by eliminating conversions: 2.2 us (71%)**, reducing the LLVM
path from 3.0 us to ~0.9 us (matching legacy's 1.47 us).

### H3: Output Layout Restoration — CONFIRMED (massive, for heterogeneous)

For the heterogeneous output case, `_OutputLayout.restore()` accounts for **98.9%**
of total call time:

| Step | Time (us) | % of Total |
|------|-----------|------------|
| `native.call` (C++ LLVM eval) | 0.86 | 0.1% |
| `list(out_arr)` | 3.63 | 0.3% |
| **`layout.restore()`** | **1331.49** | **98.9%** |
| Python overhead | 9.79 | 0.7% |

The bottleneck within `restore()` is `_float_to_basic()`:

```python
def _float_to_basic(val):
    frac = Fraction(str(float(val)))      # float → string → Fraction
    return _core.div(                      # → SymEngine Div
        _core.integer(frac.numerator),     # → SymEngine Integer
        _core.integer(frac.denominator)    # → SymEngine Integer
    )
```

This creates **3 SymEngine objects per float** at ~6 us each. For the heterogeneous
benchmark (196 matrix entries), that's **1168 us** — 87.7% of total time.

**Root cause:** The `_float_to_basic()` function exists because `DenseMatrix.set()`
requires `Basic` objects, not raw floats. The legacy Cython `Lambdify` returns numpy
arrays directly, avoiding this entirely.

**Fix:** Use `_core.real_double(val)` or a C++ helper that accepts a flat float array
into a DenseMatrix, bypassing the Fraction/div/integer object creation.

### H4: LLVM Code Quality — REJECTED

Both legacy-symengine and nbsymengine-llvm use the **identical** `LLVMDoubleVisitor`
C++ class from `symengine/llvm_double.h` with the same `init()` and `call()` methods.
The LLVM JIT-compiled machine code is the same.

Benchmark confirmation:
- `native.call()` (pre-allocated arrays): **0.89 us** for ion_speciation
- This is the pure C++ LLVM eval time — identical to what legacy would measure

The LLVM JIT code quality is excellent. The per-output cost is only **59 ns** for 15
expressions, demonstrating effective JIT compilation.

### H5: Call Interface Difference — CONFIRMED (minor, ~190 ns)

The Cython `unsafe_real()` method uses typed memoryviews (`double[::1]`) — a
zero-overhead pointer dereference with no validation. Nanobind has no equivalent.

| Method | Median (ns) |
|--------|-------------|
| `legacy.unsafe_real(memview)` | 243 |
| `legacy.unsafe_eval` | 424 |
| `nb.call_vector(list)` | 433 |
| `nb.call(ndarray, ndarray)` | 770 |

The ndarray validation in `nb::ndarray` (dtype, ndim, contiguity, device checks)
adds ~338 ns vs `call_vector`. The typed memoryview advantage is ~190 ns vs
`call_vector`.

**Contribution: ~190 ns per call** — negligible compared to the 1.5 us gap.

### H6: CSE / Expression Optimization — REJECTED

Both legacy and nbsymengine use **identical defaults**: `cse=False`, `opt_level=3`.

| Config | Eval (us) | Speedup |
|--------|-----------|---------|
| `cse=False, opt=3` (default) | 3.95 | 1.000x |
| `cse=True, opt=3` | 3.90 | 1.013x |
| `cse=False, opt=0` | 4.16 | 0.950x |
| `cse=True, opt=0` | 3.93 | 1.005x |

Changing CSE or opt_level has negligible impact on eval performance (1-5%).

## Gap Decomposition: ion_speciation

The 1.55 us gap between legacy-symengine (1.47 us) and nbsymengine-llvm (3.02 us)
decomposes as:

| Component | Legacy (us) | nbsymengine-llvm (us) | Delta (us) |
|-----------|-------------|----------------------|------------|
| C++ LLVM eval | ~0.9 | 0.9 | 0 |
| Python `__call__` wrapper | ~0.3 | 2.1 | +1.8 |
| Ndarray validation | 0 | 0.34 | +0.34 |
| Array conversion (roundtrip) | 0 | 1.0 | +1.0 |
| Output list construction | 0 | 0.7 | +0.7 |
| **Total** | **1.47** | **3.02** | **+1.55** |

Legacy's speed comes from:
1. **Typed memoryview** (`unsafe_real`): direct pointer access, no validation (saves ~0.34 us)
2. **No array roundtrip**: accepts numpy arrays directly, no list conversion (saves ~1.0 us)
3. **Returns numpy array**: no `list(out_arr)` conversion (saves ~0.7 us)

## Gap Decomposition: heterogeneous_output

The 827x gap (1.91 us vs 1579 us) is almost entirely due to `_float_to_basic()`:

| Component | Legacy (us) | nbsymengine-llvm (us) | Delta (us) |
|-----------|-------------|----------------------|------------|
| C++ LLVM eval | ~0.9 | 0.86 | 0 |
| Python output construction | ~0.5 | 1578 | +1577 |
| — of which `_float_to_basic()` | 0 | 1168 | +1168 |
| **Total** | **1.91** | **1579** | **+1577** |

Legacy returns numpy arrays directly. nbsymengine constructs `DenseMatrix` objects
by converting every float through `Fraction` → `div(integer, integer)`.

## Recommendations

### Priority 1: Eliminate array conversion roundtrip (saves ~1.0 us)

In `Lambdify.__call__`, when the input is already a numpy float64 array, skip the
`list(inp.flat)` → `np.asarray()` roundtrip:

```python
if isinstance(inp, np.ndarray) and inp.dtype == np.float64 and inp.ndim == 1:
    inp_arr = np.ascontiguousarray(inp)  # reuse if already contiguous
else:
    inp_arr = np.asarray(inp_list, dtype=np.float64)
```

### Priority 2: Return numpy arrays instead of lists (saves ~0.7 us)

For the vector output case, return `out_arr` directly instead of `list(out_arr)`:

```python
if self._layout.kind == 'vector':
    out_arr = np.empty(self._n_flat, dtype=np.float64)
    self._native.call(inp_arr, out_arr)
    return out_arr  # not list(out_arr)
```

### Priority 3: Add `unsafe_real()` method (saves ~0.34 us)

Expose a raw-pointer path in the nanobind binding that bypasses ndarray validation:

```cpp
.def("call_raw", [](PyLLVMDouble &self, double *inp, double *out) {
    self.call(out, inp);
})
```

Python side:
```python
def unsafe_real(self, inp, out):
    self._native.call_raw(inp.ctypes.data, out.ctypes.data)
```

### Priority 4: Fix `_float_to_basic()` (saves ~1168 us for heterogeneous)

Replace the `Fraction`-based conversion with direct `RealDouble` construction:

```python
def _float_to_basic(val):
    return _core.real_double(float(val))
```

Or better, add a C++ helper that accepts a flat float array directly into a
DenseMatrix, avoiding Python-side object creation entirely.

### Expected Impact

| Optimization | ion_speciation | heterogeneous |
|--------------|----------------|---------------|
| P1: No array roundtrip | 3.02 → ~2.0 us | — |
| P2: Return ndarray | 2.0 → ~1.3 us | — |
| P3: unsafe_real() | 1.3 → ~1.0 us | — |
| P4: Fix _float_to_basic | — | 1579 → ~10 us |
| **All combined** | **~1.0 us** | **~10 us** |
| vs legacy-symengine | 1.0 vs 1.47 (1.47x faster!) | 10 vs 1.91 (5.2x slower) |

With P1-P3, nbsymengine-llvm would **surpass legacy-symengine** on the ion_speciation
benchmark. The remaining gap on heterogeneous output is in Python-side DenseMatrix
construction, which requires deeper architectural changes (C++ output builder).

## Appendix: Raw Benchmark Data

```
ion_speciation_lambdify (warmup=5, iter=100, repeats=7):
  sympy              : median=6.75 us, best=6.69 us
  nbsymengine (sympy): median=11.33 us, best=11.31 us
  nbsymengine-lambda : median=11.88 us, best=11.87 us
  nbsymengine-llvm   : median=3.02 us, best=3.01 us
  nbsymengine-legacy : median=12.03 us, best=12.01 us
  legacy-symengine   : median=1.47 us, best=1.46 us

heterogeneous_output_lambdify:
  sympy              : median=761.01 us, best=755.76 us
  nbsymengine-lambda : median=1821.60 us, best=1810.59 us
  nbsymengine-llvm   : median=1579.33 us, best=1565.39 us
  nbsymengine-legacy : median=1800.78 us, best=1786.61 us
  legacy-symengine   : median=1.91 us, best=1.91 us
```

## Appendix: Methodology

Six hypotheses were tested sequentially using dedicated subagents, each running
isolated micro-benchmarks on the same machine (AMD Ryzen 9 7950X, LLVM 21.1.8,
GCC 14.2.0, Python 3.13.5). Each subagent was given a specific hypothesis, wrote
and ran a benchmark script in `/tmp/`, and returned findings without modifying any
project files.
