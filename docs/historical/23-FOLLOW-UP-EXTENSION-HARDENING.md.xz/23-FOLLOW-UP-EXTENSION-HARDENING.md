# 23 - Follow-Up Extension Hardening

**Date:** 2026-06-17
**Status:** Proposed
**Audience:** Developer continuing the cross-runtime extension validation work

## Summary

Phase 22 is substantially implemented: PHP has parity ownership tests for the
highest-value Perl invariants, timeout-protected teardown tests, a direct
construction ban, a small test-justified operation surface, a core C++ detach
and replay regression test, and local FPM smoke coverage.

The remaining work is not more API growth. It is hardening automation and
documentation around the runtime lifecycle claims:

- add a true instrumented PHP ASAN lane
- decide whether Apache `mod_php` is in scope and validate it if yes
- refresh Perl documentation so it matches the shared design note
- keep the PHP/FPM harness useful as CI evidence rather than a one-off local
  probe

## Current Verified Baseline

These checks passed locally on 2026-06-17:

```bash
SYMENGINE_RCP_CHOICE=cooperative_intrusive \
SYMENGINE_VARIANT=debug \
SYMENGINE_SKIP_CLEAN=yes \
.ci/ci-01-build-and-test.sh \
  /tmp/se-php-review-build \
  /tmp/se-php-review-install
```

Result: 61/61 SymEngine CTests passed, including
`test_cooperative_intrusive_rcp`.

```bash
SYMENGINE_VARIANT=debug \
.ci/ci-06-build-and-test-php.sh \
  /tmp/se-php-review-build \
  /tmp/se-php-review-install \
  /tmp/se-php-review-ext
```

Result: all PHP PHPTs passed in the debug-helper-enabled lane.

```bash
symengine.php/tools/fpm-smoke.sh \
  /tmp/se-php-review-install \
  /tmp/se-php-review-ext/modules/symengine.so
```

Result: PHP-FPM 8.4.21 handled singleton, expression, and canonicalization
requests in the same worker and shut down cleanly.

## Workstream A: PHP ASAN Lane

### Goal

Make PHP ownership regressions fail under AddressSanitizer with SymEngine and
the PHP extension both compiled with compatible sanitizer flags.

### Requirements

- Build SymEngine with `-fsanitize=address`.
- Build `symengine.php` with matching `CXXFLAGS` and `LDFLAGS`.
- Run PHP with the ASAN runtime preloaded if the system PHP binary is not itself
  ASAN-built.
- Start with `ASAN_OPTIONS=symbolize=1:detect_leaks=0`.
- Run only ownership-focused PHPTs at first:
  - `025-canonical-identity-reuse.phpt`
  - `035-debug-helpers.phpt`
  - `045-expression-pins-operand.phpt`
  - `050-singleton-teardown.phpt`
  - `060-expression-teardown.phpt`
  - `065-loop-teardown.phpt`

### Implementation Notes

Do not call an `LD_PRELOAD`-only smoke test an ASAN lane. The extension and
SymEngine library must be instrumented.

If PHP runtime noise makes leak detection unusable, keep `detect_leaks=0` and
document the reason. Revisit leak detection only after adding suppressions.

### Acceptance Check

```bash
rm -rf /tmp/se-php-asan-build /tmp/se-php-asan-install /tmp/se-php-asan-ext
SYMENGINE_RCP_CHOICE=cooperative_intrusive \
SYMENGINE_VARIANT=asan \
.ci/ci-01-build-and-test.sh \
  /tmp/se-php-asan-build \
  /tmp/se-php-asan-install

SYMENGINE_VARIANT=asan \
.ci/ci-06-build-and-test-php.sh \
  /tmp/se-php-asan-build \
  /tmp/se-php-asan-install \
  /tmp/se-php-asan-ext
```

Expected result: focused PHPT ownership tests pass without ASAN reports.

## Workstream B: CI FPM Smoke

### Goal

Move the FPM validation from local evidence into repeatable automation where the
required packages are available.

### Requirements

- Install or provide `php-fpm` and `cgi-fcgi` in the CI image.
- Run `symengine.php/tools/fpm-smoke.sh` after the debug PHP extension build.
- Preserve `LD_LIBRARY_PATH` for the worker.
- Prefer the harness's temporary Unix socket over a fixed TCP port.
- Keep `pm = static` and `pm.max_children = 1`.
- Assert the worker PID is unchanged across requests.

### Acceptance Check

```bash
symengine.php/tools/fpm-smoke.sh \
  /tmp/inst-se-php \
  /tmp/bld-php-ext/modules/symengine.so
```

Expected result: singleton, expression, and canonical requests pass in the same
worker and FPM exits cleanly.

## Workstream C: Apache Module Decision

### Goal

Decide whether Apache `mod_php` support is in scope for this validation project.

### If In Scope

Add a separate Apache smoke harness. It should:

- run Apache with a temporary config and document root
- load the matching PHP module
- load the built `symengine.so`
- send repeated HTTP requests to singleton, expression, and canonical scripts
- stop Apache cleanly
- report exact Apache and PHP module versions

### If Out Of Scope

Document that the PHP extension currently claims CLI and FPM smoke coverage
only. Do not leave Apache as an implicit promise.

## Workstream D: Perl README Refresh

### Goal

Make `symengine.pl/README.md` match the current cooperative ownership design so
Perl remains a clear reference implementation.

### Required Topics

- raw-pointer holder model
- `SvREFCNT` as the external-owner anchor
- identity reuse through `self_external()`
- `use_count() == 0` in external-owned mode
- singleton reconciliation via `call_atexit`
- `PL_phase == PERL_PHASE_DESTRUCT` guard
- relationship to `docs/reports/22c-COOPERATIVE-INTRUSIVE-CROSS-RUNTIME.md`

### Acceptance Check

```bash
SYMENGINE_VARIANT=debug \
.ci/ci-05-build-and-test-perl.sh /tmp/se-perl-readme-check
```

Expected result: Perl tests still pass and the README no longer contradicts the
design note.

## Non-Goals

- Do not add broad PHP symbolic API surface.
- Do not change Perl code solely for visual symmetry with PHP.
- Do not move runtime-specific PHP or Perl shutdown code into SymEngine core.
- Do not claim sanitizer coverage from an uninstrumented extension build.

## Definition Of Done

- PHP ASAN either passes as a true instrumented lane or is documented with a
  concrete blocker.
- FPM smoke runs in CI or the CI image gap is explicitly documented.
- Apache module support is either validated or declared out of scope.
- Perl README is aligned with the shared cross-runtime design note.
