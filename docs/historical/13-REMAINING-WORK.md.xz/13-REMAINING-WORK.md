# 13 — Remaining Work: Bring `nbsymengine_compat` Implementation and Tests Up to Par

This plan replaces the earlier draft, which is now stale.

The compatibility shim has made real progress, but the remaining work is no longer “just 8 matrix failures”. The current baseline is broader: multiple wrapper-boundary bugs remain across matrices, number-theory helpers, printing state, series/expression compatibility, set constructors, and shutdown/leak behavior.

---

## 1. Baseline

### Current observed test status

A fresh run on **2026-06-12** of:

```bash
pytest -q nbsymengine_compat/tests
```

currently produces:

* **20 real test failures**
* expected skips / xfails from the converted legacy suite
* **nanobind leak warnings at process exit**

The 20 failures are grouped as follows:

1. **Matrices:** 8 failures
2. **Number theory container returns:** 9 failures
3. **Printing state / `init_printing`:** 1 failure
4. **Series / expression API gap:** 1 failure
5. **Set constructor coercion:** 1 failure

The previous draft only described the first group, so it is no longer an adequate implementation plan.

---

## 2. Critical Review of the Old Draft

The prior plan had three problems:

### A. It understates the failure surface

It assumes only `test_matrices.py` is failing. That is no longer true.

The currently failing converted tests span:

* [`test_matrices.py`](file:///work/nbsymengine_compat/tests/converted/test_matrices.py)
* [`test_ntheory.py`](file:///work/nbsymengine_compat/tests/converted/test_ntheory.py)
* [`test_printing.py`](file:///work/nbsymengine_compat/tests/converted/test_printing.py)
* [`test_series_expansion.py`](file:///work/nbsymengine_compat/tests/converted/test_series_expansion.py)
* [`test_sets.py`](file:///work/nbsymengine_compat/tests/converted/test_sets.py)

### B. It focuses on symptoms instead of shared root causes

Most remaining failures come from a small number of cross-cutting issues:

* wrapped objects passed back into raw `_core` APIs without unwrapping
* raw `_core` objects escaping compat APIs without recursive wrapping
* public constructors/factories calling `unwrap()` directly on user inputs that should first be sympified
* process-global compatibility state (`init_printing`) that is not toggled correctly

The plan should attack those root causes, not just patch individual tests.

### C. It omits leak/shutdown correctness

The compat suite currently ends with nanobind leak reports. That is a release blocker for this shim layer and needs to be part of the acceptance criteria, not treated as incidental noise.

---

## 3. Failure Inventory by Root Cause

### A. Matrix wrapper/raw boundary bugs

The old draft was directionally right about this group. The current failing tests still show the same family of mistakes:

* copying a `DenseMatrixWrapper` back into raw `_core.DenseMatrix(...)` still passes wrapped elements instead of raw elements
* scalar-on-the-left matrix multiplication still does not return `NotImplemented` early enough
* matrix division still only handles scalar divisors
* matrix predicate logic inspects wrapped values as if they were raw `_core` instances
* `is_hermitian` still calls `_core.conjugate()` on wrapped values

Current failing matrix tests:

* `test_set_item`
* `test_mul_scalar`
* `test_div`
* `test_is_zero_matrix`
* `test_is_real_matrix`
* `test_is_diagonal`
* `test_is_hermitian`
* `test_immutablematrix`

Files involved:

* [`_matrices.py`](file:///work/nbsymengine_compat/src/nbsymengine_compat/_matrices.py)
* [`_wrappers.py`](file:///work/nbsymengine_compat/src/nbsymengine_compat/_wrappers.py)

### B. Container-returning ntheory helpers leak raw `_core` values

Several compat helper functions return tuples/lists that still contain raw `_core.Integer` objects instead of compat-wrapped values or plain Python ints where legacy behavior expects them.

This causes failures that look superficially absurd, such as:

* `assert p == 1` failing even though both sides display as `1`
* tuple/list equality failing element-by-element for values that print identically

Current failing functions:

* `gcd_ext`
* `quotient_mod`
* `fibonacci2`
* `lucas2`
* `prime_factors`
* `primitive_root_list`
* `sqrt_mod(..., all_roots=True)`
* `nthroot_mod_list`
* `powermod_list`

File involved:

* [`_wrappers.py`](file:///work/nbsymengine_compat/src/nbsymengine_compat/_wrappers.py)

### C. Printing state is sticky and API-incomplete

`init_printing()` currently behaves like a one-way global enable switch, but the converted tests expect:

* `init_printing()` to enable LaTeX display
* `init_printing(True)` to enable it explicitly
* `init_printing(False)` to disable it again

Right now the state leaks across tests and causes:

* `test_init_printing` to fail because `_repr_latex_()` is already enabled before the test toggles it

Files involved:

* [`_printing.py`](file:///work/nbsymengine_compat/src/nbsymengine_compat/_printing.py)
* potentially [`conftest.py`](file:///work/nbsymengine_compat/conftest.py) for state reset

### D. Expression compatibility gap: missing `coeff`

The converted series test shows that series results need a compat-level `.coeff(...)` method.

Today:

* `series(...)` returns a wrapped object
* that wrapped object does not implement `coeff`
* the failure currently shows up on a series result, but the missing method is really part of the broader expression compatibility surface

Files involved:

* [`_wrappers.py`](file:///work/nbsymengine_compat/src/nbsymengine_compat/_wrappers.py)

### E. Set constructors are not sympifying scalar inputs consistently

`ImageSet(...)` currently calls `unwrap()` directly on constructor arguments. That works for already-wrapped expressions but fails for plain Python scalars that should be accepted by the legacy API.

Current failing case:

* `ImageSet(x, 1, Interval(0, 1))`

File involved:

* [`_wrappers.py`](file:///work/nbsymengine_compat/src/nbsymengine_compat/_wrappers.py)

### F. Leak warnings remain a top-level blocker

The current run ends with nanobind leak warnings for `_core.Basic`, `_core.Integer`, and related function/type objects.

Some of that may disappear automatically once raw `_core` objects stop escaping compat containers, but the leak reports should be treated as a first-class acceptance target rather than an afterthought.

---

## 4. Design Principles for the Fixes

### A. Normalize boundary handling instead of patching one call site at a time

The shim needs two consistent rules:

1. **Public compat inputs** should be:
   * sympified if they are Python scalars / Python-native values
   * unwrapped before crossing into `_core`

2. **Values returned from `_core`** should be:
   * wrapped recursively if they are `_core.Basic`, `_core.DenseMatrix`, or containers of those values

This argues for introducing or centralizing helpers such as:

* `wrap_nested(...)`
* `sympify_then_unwrap(...)`

rather than continuing to hand-code conversions function by function.

### B. Prefer wrapper-preserving compat behavior over raw `_core` passthrough

Whenever the compat layer exposes:

* constructors
* free functions
* sequence/tuple/list returns

it should prefer wrapped compat values unless legacy behavior clearly expects plain Python primitives.

### C. Keep test state deterministic

Global mutable compatibility settings like printing must be explicitly toggleable and should be reset between tests if needed.

---

## 5. Execution Plan

### Phase 1: Introduce shared boundary helpers and audit their use

Before fixing individual failures, create a small set of reusable helpers in the compat layer to prevent more drift.

Recommended work:

1. Add a recursive wrapper helper, likely in [`_wrappers.py`](file:///work/nbsymengine_compat/src/nbsymengine_compat/_wrappers.py) or [`_helpers.py`](file:///work/nbsymengine_compat/src/nbsymengine_compat/_helpers.py):
   * wraps `_core.Basic`
   * wraps `_core.DenseMatrix`
   * recursively wraps lists, tuples, dict values, and sets/frozensets when appropriate

2. Add a small helper for public API arguments:
   * `_sympify(...)`
   * then `unwrap(...)`

3. Apply those helpers first to the failing call sites, then audit nearby similar helpers while the code is open

This phase is important because it prevents the plan from devolving into 20 one-off patches.

### Phase 2: Fix matrix wrapper/raw crossings

Update [`_matrices.py`](file:///work/nbsymengine_compat/src/nbsymengine_compat/_matrices.py) and the matrix-related operator handling in [`_wrappers.py`](file:///work/nbsymengine_compat/src/nbsymengine_compat/_wrappers.py).

Required fixes:

1. **`DenseMatrixWrapper._create_raw(...)`:**
   * when copying from `DenseMatrixWrapper`, build `flat` from raw elements (`arg._raw.get(...)` or `unwrap(arg.get(...))`)
   * do the same for any similar copy path used by `ImmutableMatrix`

2. **`_wrap_binary_op(...)`:**
   * if `other` is a `DenseMatrixWrapper` or raw `_core.DenseMatrix`, return `NotImplemented` early for scalar-expression wrappers
   * let Python fall back to the matrix-side reflected operator

3. **`DenseMatrixWrapper.__truediv__(...)`:**
   * preserve scalar division
   * add matrix-division support, most likely via multiply-by-inverse behavior that matches legacy expectations

4. **Matrix predicates (`is_zero_matrix`, `is_real_matrix`, `is_diagonal`, `is_hermitian`):**
   * run predicate logic on raw values after unwrapping
   * return `True` / `False` / `None` in the same tri-valued style as the legacy layer

5. **`is_hermitian`:**
   * call `_core.conjugate(unwrap(...))`, not `_core.conjugate(wrapper)`

This should eliminate the currently failing matrix block rather than just the originally documented subset.

### Phase 3: Fix container-returning ntheory helpers

Audit every compat function in [`_wrappers.py`](file:///work/nbsymengine_compat/src/nbsymengine_compat/_wrappers.py) that returns:

* tuples
* lists
* dicts
* nested container structures

Apply recursive wrapping to the currently failing ones:

1. `gcd_ext`
2. `quotient_mod`
3. `fibonacci2`
4. `lucas2`
5. `prime_factors`
6. `primitive_root_list`
7. `sqrt_mod(..., all_roots=True)`
8. `nthroot_mod_list`
9. `powermod_list`

Also audit nearby helpers that are not failing yet but are structurally similar, for example:

* `prime_factor_multiplicities`
* `crt`
* any future `_core` helpers returning `std::vector<RCP<const Basic>>` or tuples of symbolic values

Goal:

* no raw `_core.Integer` or other `_core.Basic` values should escape the compat API inside Python containers unless explicitly intended

### Phase 4: Restore printing toggle semantics and isolate test state

Update [`_printing.py`](file:///work/nbsymengine_compat/src/nbsymengine_compat/_printing.py) so that:

1. `init_printing()` enables LaTeX display
2. `init_printing(True)` enables it
3. `init_printing(False)` disables it

Then decide how to avoid order-dependent test behavior:

Option A:
* keep `init_printing` state global, but add a small autouse fixture in [`conftest.py`](file:///work/nbsymengine_compat/conftest.py) that resets the flag before/after each test

Option B:
* rely only on explicit enable/disable calls in tests if that is enough once semantics are corrected

Option A is safer and more deterministic.

This phase should cover both:

* `Basic._repr_latex_()`
* `DenseMatrixWrapper._repr_latex_()`

### Phase 5: Restore missing expression-level compatibility methods

The immediate failing API gap is `coeff`, exposed by the series-expansion test.

Recommended approach:

1. Implement a compat-level `Basic.coeff(...)` method in [`_wrappers.py`](file:///work/nbsymengine_compat/src/nbsymengine_compat/_wrappers.py)
2. Use the SymPy bridge for the first implementation if native `_core` support is awkward
3. Return compat-wrapped results

Why this shape:

* the failure happens on a series result today
* but `coeff` is a general expression method, not a special-case matrix or series API
* putting it on `Basic` gives broader legacy compatibility and avoids inventing special treatment for one dynamic wrapper class

While touching this area, audit whether any other high-value expression methods are still missing but should now be added to the wrapper class rather than left in placeholder modules.

### Phase 6: Fix set-constructor coercion and audit raw factory aliases

Update `ImageSet` and related set constructors in [`_wrappers.py`](file:///work/nbsymengine_compat/src/nbsymengine_compat/_wrappers.py) so that public inputs are sympified before unwrapping.

Immediate fix:

* `ImageSet(x, 1, Interval(...))` should sympify `1` into a symbolic integer before calling `_core.imageset(...)`

Audit scope:

* `ConditionSet`
* `ImageSet`
* any other constructor still calling `unwrap(user_input)` directly on public scalar arguments

Also review the raw set-factory aliases at the bottom of `_wrappers.py`:

* `finiteset = _core.finiteset`
* `interval = _core.interval`
* `imageset = _core.imageset`
* etc.

Those raw aliases are risky in a compat layer because they bypass wrapper/sympify rules. If they are relied upon by tests or public surface expectations, replace them with thin compat-aware wrapper functions instead of exporting raw `_core` callables.

### Phase 7: Add leak-aware regression tests

The compat submodule currently has no dedicated leak/shutdown regression coverage analogous to the native `nbsymengine` tests.

Add at least one new subprocess-based test file, for example:

* `nbsymengine_compat/tests/test_shutdown_leaks.py`

It should:

1. import `symengine_py_compat`
2. materialize representative wrapped objects:
   * scalars
   * matrices
   * sets
   * boolean singletons
3. exit the subprocess
4. assert:
   * return code is 0
   * stderr does not contain `nanobind: leaked`
   * stderr does not contain `reference counting issue`

This is the only reliable way to turn the current leak warnings into an enforceable regression guard.

---

## 6. File-Level Work List

The expected implementation will primarily touch:

### Core implementation

* [`nbsymengine_compat/src/nbsymengine_compat/_wrappers.py`](file:///work/nbsymengine_compat/src/nbsymengine_compat/_wrappers.py)
* [`nbsymengine_compat/src/nbsymengine_compat/_matrices.py`](file:///work/nbsymengine_compat/src/nbsymengine_compat/_matrices.py)
* [`nbsymengine_compat/src/nbsymengine_compat/_printing.py`](file:///work/nbsymengine_compat/src/nbsymengine_compat/_printing.py)
* possibly [`nbsymengine_compat/src/nbsymengine_compat/_helpers.py`](file:///work/nbsymengine_compat/src/nbsymengine_compat/_helpers.py) for shared conversion helpers

### Test infrastructure

* [`nbsymengine_compat/conftest.py`](file:///work/nbsymengine_compat/conftest.py)
* new focused leak/shutdown test file under [`nbsymengine_compat/tests/`](file:///work/nbsymengine_compat/tests/)

### Existing tests expected to turn green

* [`tests/converted/test_matrices.py`](file:///work/nbsymengine_compat/tests/converted/test_matrices.py)
* [`tests/converted/test_ntheory.py`](file:///work/nbsymengine_compat/tests/converted/test_ntheory.py)
* [`tests/converted/test_printing.py`](file:///work/nbsymengine_compat/tests/converted/test_printing.py)
* [`tests/converted/test_series_expansion.py`](file:///work/nbsymengine_compat/tests/converted/test_series_expansion.py)
* [`tests/converted/test_sets.py`](file:///work/nbsymengine_compat/tests/converted/test_sets.py)

---

## 7. Verification Plan

### A. Targeted test runs during implementation

Run these while iterating:

```bash
pytest nbsymengine_compat/tests/converted/test_matrices.py
pytest nbsymengine_compat/tests/converted/test_ntheory.py
pytest nbsymengine_compat/tests/converted/test_printing.py
pytest nbsymengine_compat/tests/converted/test_series_expansion.py
pytest nbsymengine_compat/tests/converted/test_sets.py
```

### B. Focused compat smoke tests

Also keep these green:

```bash
pytest nbsymengine_compat/tests/test_no_monkeypatch.py
pytest nbsymengine_compat/tests/test_public_surface.py
pytest nbsymengine_compat/tests/test_legacy_shim.py
```

These guard the architectural goal: a compat layer that is isolated, legacy-shaped, and import-safe.

### C. Full compat suite

Once targeted fixes land:

```bash
pytest nbsymengine_compat/tests
```

Success criteria for this phase:

* no real failures in the currently-enabled compat suite
* existing xfails remain only for genuinely unimplemented legacy APIs, not for regressions introduced by the wrapper architecture

### D. Leak/shutdown verification

Run the new subprocess leak tests and ensure:

* exit code 0
* no `nanobind: leaked`
* no `reference counting issue`

---

## 8. Acceptance Criteria

This work is complete only when all of the following are true:

1. the 20 currently failing compat tests are green
2. the matrix wrapper boundary bugs are resolved without raw/compat type confusion
3. container-returning ntheory helpers no longer leak raw `_core` values into Python containers
4. `init_printing()` supports both enable and disable semantics and no longer leaks state across tests
5. `Basic.coeff(...)` is restored at the compat layer
6. `ImageSet(...)` and similar public constructors sympify scalar inputs correctly
7. the compat suite exits without nanobind leak warnings
8. the non-monkeypatch guarantee remains intact

---

## 9. Non-Goals

This plan does **not** aim to:

* remove the placeholder [`_monkeypatch.py`](file:///work/nbsymengine_compat/src/nbsymengine_compat/_monkeypatch.py) module unless it is directly in the way
* redesign the entire compat API surface
* eliminate all xfails in the converted legacy suite if those xfails still correspond to genuinely missing features outside the current regression scope

The focus here is getting the current wrapper-based compatibility layer correct, deterministic, and test-clean.
