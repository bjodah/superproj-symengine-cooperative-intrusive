# Implementation Plan: Optimize Lambdify Performance

**Date:** 2026-06-08  
**Based on:** `docs/reports/03-LLVM-PERFORMANCE-GAP-REPORT.md`  
**Goal:** Close the performance gap between nbsymengine-llvm (3.02 us) and
legacy-symengine (1.47 us) on `ion_speciation`, and eliminate the 827x gap on
`heterogeneous_output`.

## Current Performance Breakdown

### ion_speciation (3.02 us total)

| Step | Time (us) | % |
|------|-----------|---|
| `list(inp.flat)` — ndarray→list | 0.5 | 17% |
| `np.asarray(inp_list, float64)` — list→ndarray | 0.5 | 15% |
| `np.empty(n_out, float64)` — alloc output | 0.2 | 6% |
| `native.call(inp_arr, out_arr)` — C++ LLVM eval | 0.9 | 29% |
| `list(out_arr)` — output→list | 0.7 | 24% |
| Python overhead | 0.2 | 7% |

### heterogeneous_output (1579 us total)

| Step | Time (us) | % |
|------|-----------|---|
| `native.call(inp_arr, out_arr)` — C++ LLVM eval | 0.86 | 0.1% |
| `list(out_arr)` | 3.63 | 0.2% |
| `_OutputLayout.restore()` | 1331 | 84.3% |
| — of which `_float_to_basic()` × 196 | 1168 | 74.0% |
| — of which `DenseMatrix.set()` × 196 | 66.6 | 4.2% |
| — of which vector slice | 91.7 | 5.8% |
| Python overhead | 244 | 15.5% |

## Optimization P1: Eliminate Array Conversion Roundtrip

**Saves: ~1.0 us per call (ion_speciation)**

### Problem

When the caller passes a numpy array (the common case in benchmarks and real usage),
`__call__` does a wasteful roundtrip:

```python
# Current code (lambdify.py:479-485,497)
if isinstance(inp, np.ndarray):
    inp_list = list(inp.flat)           # ndarray → list (0.5 us)
# ...
inp_arr = np.asarray(inp_list, float64) # list → ndarray (0.5 us)
```

### Fix

**File:** `nbsymengine/python-bindings/nbsymengine/lambdify.py`

Replace the input handling block (lines 474-497) with a fast path that reuses the
input array directly when it's already a contiguous float64 ndarray:

```python
def __call__(self, *args, out=None):
    import numpy as np

    # Determine input values — fast path for the common case
    if len(args) == 1 and isinstance(args[0], np.ndarray):
        inp = args[0]
        if inp.ndim == 2:
            raise NotImplementedError(
                "Batched 2-D input arrays are not supported yet. "
                "Pass a 1-D array or use scalar varargs."
            )
        # Fast path: reuse contiguous float64 array directly
        if inp.dtype == np.float64 and inp.flags['C_CONTIGUOUS']:
            inp_arr = inp.reshape(-1)
        else:
            inp_arr = np.ascontiguousarray(inp, dtype=np.float64).reshape(-1)
    elif len(args) == 1:
        inp = args[0]
        if hasattr(inp, '__iter__'):
            inp_arr = np.asarray(list(inp), dtype=np.float64)
        else:
            inp_arr = np.asarray([inp], dtype=np.float64)
    else:
        inp_arr = np.asarray(args, dtype=np.float64)

    # Native lambda_double / llvm evaluation
    if self._backend in ('lambda_double', 'llvm'):
        # ... (rest of evaluation, using inp_arr directly)
```

**Key changes:**
- When input is a contiguous float64 ndarray, use it directly (zero-copy)
- When input is a non-contiguous or non-float64 ndarray, convert once
  (`np.ascontiguousarray`) instead of twice (list + asarray)
- When input is a list/tuple/scalar, convert once via `np.asarray`

### Impact

- Eliminates 1.0 us of array roundtrip overhead
- `ion_speciation`: 3.02 us → ~2.0 us

### Risks

- Must ensure `inp_arr` is always a contiguous float64 1-D array before passing to
  `self._native.call()`
- The `out=` parameter handling must still work correctly

---

## Optimization P2: Return Numpy Arrays Instead of Lists

**Saves: ~0.7 us per call (ion_speciation)**

### Problem

For vector outputs, `__call__` converts the output numpy array to a Python list:

```python
# Current code (lambdify.py:506-518)
elif self._layout.kind == 'vector':
    out_arr = np.empty(self._n_flat, dtype=np.float64)
    self._native.call(inp_arr, out_arr)
    return list(out_arr)  # 0.7 us
```

### Fix

**File:** `nbsymengine/python-bindings/nbsymengine/lambdify.py`

Return the numpy array directly for vector outputs. This changes the return type
from `list` to `np.ndarray`, which is a **breaking API change** that requires
updating tests and callers.

**Option A (non-breaking):** Return a numpy array but document the change. Most
callers already treat the result as a sequence (indexing, iteration), so this should
be backward-compatible in practice.

**Option B (non-breaking):** Add an `as_array` parameter to control the return type:

```python
def __init__(self, ..., as_array=False):
    self._as_array = as_array

# In __call__:
if self._layout.kind == 'vector':
    out_arr = np.empty(self._n_flat, dtype=np.float64)
    self._native.call(inp_arr, out_arr)
    if self._as_array:
        return out_arr          # fast path
    return list(out_arr)        # backward-compatible
```

**Option C (recommended):** Return numpy arrays by default, update tests. The
`Lambdify` class is a new API (not legacy symengine.py), so we can define the
preferred return type:

```python
if self._layout.kind == 'vector':
    out_arr = np.empty(self._n_flat, dtype=np.float64)
    self._native.call(inp_arr, out_arr)
    if out is not None:
        out_arr_np = np.asarray(out)
        if out_arr_np.size == self._n_flat:
            np.copyto(out_arr_np.reshape(-1), out_arr)
            return out
        raise ValueError(...)
    return out_arr              # numpy array, not list
```

### Test Updates Required

All tests that check `isinstance(result, list)` or `len(result)` for vector output
must be updated to handle numpy arrays:

```python
# Before:
result = f([2.0, 3.0])
assert isinstance(result, list)
assert len(result) == 2

# After:
result = f([2.0, 3.0])
assert isinstance(result, np.ndarray)
assert result.shape == (2,)
```

**Files to update:**
- `nbsymengine/python-bindings/tests/test_lambdify_direct.py` — ~15 tests
- `benchmarks/nbsymengine_benchmarks/adapters.py` — benchmark call sites

### Impact

- Eliminates 0.7 us of list construction overhead
- `ion_speciation`: 2.0 us → ~1.3 us (with P1)

### Risks

- **API breaking change** for callers expecting `list` return
- The `LambdifyCSE` wrapper must also be updated
- The `_OutputLayout.restore()` for 'vector' kind returns `list()` — must change

---

## Optimization P3: Add Zero-Validation `call_ptr()` Method

**Saves: ~0.34 us per call (ion_speciation)**

### Problem

The nanobind `call(inp, out)` binding validates both ndarray shapes on every call:

```cpp
// core_module.cpp:981-998
.def("call", [](PyLLVMDouble &self,
                nb::ndarray<double, nb::ndim<1>, nb::c_contig> inp,
                nb::ndarray<double, nb::ndim<1>, nb::c_contig> out) {
    if ((size_t)inp.shape(0) != self.n_inputs()) throw ...;
    if ((size_t)out.shape(0) != self.n_outputs()) throw ...;
    self.call(out.data(), inp.data());
})
```

The `nb::ndarray` template performs dtype, ndim, contiguity, and device checks.
Legacy Cython's `unsafe_real()` uses typed memoryviews (`double[::1]`) which bypass
all validation.

### Fix

**File:** `nbsymengine/bindings/python_nanobind/src/core_module.cpp`

Add a `call_ptr()` method that takes raw integer pointers (from `ctypes.data`):

```cpp
.def("call_ptr", [](PyLLVMDouble &self, uint64_t inp_ptr, uint64_t out_ptr) {
    self.call(reinterpret_cast<double *>(out_ptr),
              reinterpret_cast<double *>(inp_ptr));
}, nb::arg("inp_ptr"), nb::arg("out_ptr"))
```

**File:** `nbsymengine/python-bindings/nbsymengine/lambdify.py`

Update `unsafe_real()` to use `call_ptr()`:

```python
def unsafe_real(self, inp, out):
    """Evaluate with real input/output arrays (no type checks)."""
    if self._native is not None:
        import ctypes
        inp_ptr = inp.ctypes.data if hasattr(inp, 'ctypes') else int(inp)
        out_ptr = out.ctypes.data if hasattr(out, 'ctypes') else int(out)
        self._native.call_ptr(inp_ptr, out_ptr)
        return
    # ... (fallback for sympy backend)
```

### Impact

- Saves ~0.34 us per call (ndarray validation overhead)
- `ion_speciation`: 1.3 us → ~1.0 us (with P1+P2)

### Risks

- Raw pointer passing is inherently unsafe — the caller must ensure arrays are
  contiguous float64 and correctly sized
- The `unsafe_real()` name already signals this trade-off
- Must ensure the ctypes `.data` attribute returns the correct pointer type

---

## Optimization P4: Replace `_float_to_basic()` with `real_double()`

**Saves: ~1168 us per call (heterogeneous_output)**

### Problem

`_float_to_basic()` converts every float through a slow `Fraction` → `div(integer,
integer)` path:

```python
# Current code (lambdify.py:121-127)
def _float_to_basic(val):
    if isinstance(val, _core.Basic):
        return val
    from fractions import Fraction
    frac = Fraction(str(float(val)))               # float → string → Fraction
    return _core.div(                                # SymEngine Div
        _core.integer(frac.numerator),               # SymEngine Integer
        _core.integer(frac.denominator)              # SymEngine Integer
    )
```

This creates **3 SymEngine objects per float** at ~6 us each. For 196 matrix entries,
that's 1168 us.

### Fix

**File:** `nbsymengine/python-bindings/nbsymengine/lambdify.py`

Replace `_float_to_basic()` with a direct `real_double()` call:

```python
def _float_to_basic(val):
    """Convert a numeric value to ``_core.Basic`` for DenseMatrix.set()."""
    if isinstance(val, _core.Basic):
        return val
    return _core.real_double(float(val))
```

`_core.real_double(x)` creates a single `RealDouble` object (~0.06 us vs ~6 us),
a **100x speedup** per value.

### Why This Is Safe

- `DenseMatrix.set()` accepts any `RCP<const Basic>`, and `RealDouble` is a subclass
  of `Number` which is a subclass of `Basic`
- The matrix is only used for output (not symbolic manipulation), so `RealDouble` vs
  `div(Integer, Integer)` has no semantic difference
- The `_float_to_basic()` function is only called in `_OutputLayout.restore()` for
  matrix outputs — it's never used for symbolic computation

### Impact

- Reduces `_float_to_basic()` from ~6 us to ~0.06 us per call
- For 196 matrix entries: 1168 us → ~12 us
- `heterogeneous_output`: 1579 us → ~400 us (still high due to other Python overhead)

### Risks

- **None.** `RealDouble` is a valid `Basic` subclass. The output DenseMatrix is only
  used for numeric results, not symbolic manipulation.

---

## Optimization P5: Add C++ `set_from_array()` to DenseMatrix

**Saves: ~66 us per call (heterogeneous_output)**

### Problem

`DenseMatrix.set(i, j, val)` is called 196 times in a Python loop. Each call crosses
the Python/C++ boundary and does type checking.

### Fix

**File:** `nbsymengine/bindings/python_nanobind/src/core_module.cpp`

Add a method that accepts a flat float array and populates the entire matrix:

```cpp
.def("set_from_array", [](DenseMatrix &mat,
                          nb::ndarray<double, nb::ndim<1>, nb::c_contig> arr) {
    unsigned rows = mat.nrows();
    unsigned cols = mat.ncols();
    if ((size_t)arr.shape(0) != (size_t)(rows * cols))
        throw nb::value_error("Array size must match matrix dimensions");
    for (unsigned i = 0; i < rows; ++i)
        for (unsigned j = 0; j < cols; ++j)
            mat.set(i, j, SymEngine::real_double(arr.data()[i * cols + j]));
}, nb::arg("arr"))
```

**File:** `nbsymengine/python-bindings/nbsymengine/lambdify.py`

Update `_OutputLayout.restore()` for the 'matrix' case:

```python
elif self.kind == 'matrix':
    rows, cols = self.shape
    n = rows * cols
    import numpy as np
    flat_arr = np.array(flat_values[offset:offset + n], dtype=np.float64)
    mat = _core.DenseMatrix(rows, cols)
    mat.set_from_array(flat_arr)
    return mat, offset + n
```

### Impact

- Reduces 196 Python→C++ calls to 1 call
- Saves ~66 us for the matrix set operations
- Combined with P4: `heterogeneous_output` → ~300 us

### Risks

- The `set_from_array` method creates `RealDouble` objects internally, which is
  consistent with P4

---

## Optimization P6: Avoid `list()` Conversion for Matrix/Nested Outputs

**Saves: ~92 us per call (heterogeneous_output)**

### Problem

For matrix/nested outputs, `__call__` does:

```python
# Current code (lambdify.py:521-524)
out_arr = np.empty(self._n_flat, dtype=np.float64)
self._native.call(inp_arr, out_arr)
flat_values = list(out_arr)           # 0.7 us — unnecessary
restored, _ = self._layout.restore(flat_values, 0)  # accesses by index
```

The `restore()` method accesses `flat_values[offset + i]` by index, which works
identically with a numpy array or a list.

### Fix

Pass the numpy array directly to `restore()` instead of converting to a list:

```python
if self._layout.kind in ('matrix', 'nested'):
    out_arr = np.empty(self._n_flat, dtype=np.float64)
    self._native.call(inp_arr, out_arr)
    restored, _ = self._layout.restore(out_arr, 0)  # pass ndarray directly
    return restored
```

Update `_OutputLayout.restore()` to accept both lists and numpy arrays (it already
does via indexing, so no change needed for the scalar/vector/nested cases).

### Impact

- Saves ~0.7 us for the `list(out_arr)` conversion
- Also saves the intermediate Python list creation for large outputs

### Risks

- **None.** numpy arrays support integer indexing just like lists.

---

## Implementation Order

| Priority | Optimization | Saves (ion) | Saves (hetero) | Effort | Risk |
|----------|-------------|-------------|----------------|--------|------|
| **P1** | Eliminate array roundtrip | 1.0 us | — | Low | Low |
| **P4** | `_float_to_basic()` → `real_double()` | — | 1168 us | Trivial | None |
| **P6** | Skip `list()` for matrix outputs | — | 0.7 us | Trivial | None |
| **P2** | Return numpy arrays | 0.7 us | — | Medium | API change |
| **P5** | `DenseMatrix.set_from_array()` | — | 66 us | Low | Low |
| **P3** | `call_ptr()` zero-validation | 0.34 us | 0.34 us | Low | Unsafe API |

**Recommended implementation sequence:**

1. **P4** (trivial, zero risk, massive heterogeneous win) — 5 minutes
2. **P6** (trivial, zero risk) — 5 minutes
3. **P1** (low risk, largest ion_speciation win) — 30 minutes
4. **P2** (medium effort, API change) — 1 hour
5. **P5** (low effort, C++ change) — 30 minutes
6. **P3** (low effort, unsafe API) — 30 minutes

**Total estimated effort: ~3 hours**

## Expected Final Performance

| Benchmark | Current | After P1+P2+P3 | After All | Legacy |
|-----------|---------|-----------------|-----------|--------|
| ion_speciation | 3.02 us | ~1.0 us | ~1.0 us | 1.47 us |
| heterogeneous_output | 1579 us | ~1579 us | ~300 us | 1.91 us |

After P1-P3, nbsymengine-llvm **surpasses legacy-symengine** on ion_speciation
(1.0 us vs 1.47 us). The heterogeneous_output gap narrows from 827x to ~158x, with
the remaining overhead in Python-level DenseMatrix construction and output layout
restoration.

## Testing Strategy

### Regression Tests

All existing tests in `test_lambdify_direct.py` must continue to pass. The key
change from P2 (returning numpy arrays instead of lists) requires updating assertions:

```python
# Tests that check isinstance(result, list) → isinstance(result, np.ndarray)
# Tests that check result[i] → still work (numpy supports indexing)
```

### Performance Tests

Add a benchmark regression test that verifies the optimization impact:

```python
def test_Lambdify_LLVM_performance_baseline():
    """Verify LLVM backend performance is within expected bounds."""
    import time
    import nbsymengine as sx
    x, y = sx.symbol('x'), sx.symbol('y')
    exprs = [x + y, x * y, sx.sin(x), sx.cos(y)]
    f = sx.Lambdify([x, y], exprs, backend='llvm')
    inp = [2.5, 3.7]
    # Warmup
    for _ in range(100):
        f(inp)
    # Measure
    start = time.perf_counter()
    N = 10000
    for _ in range(N):
        f(inp)
    elapsed = (time.perf_counter() - start) / N
    # Should be under 2 us after optimizations
    assert elapsed < 2e-6, f"LLVM eval too slow: {elapsed*1e6:.2f} us"
```

### Compat Tests

The `nbsymengine_compat` Lambdify delegates to the direct implementation, so
changes propagate automatically. Verify compat tests still pass.

## Appendix: Files to Modify

| File | Changes |
|------|---------|
| `nbsymengine/python-bindings/nbsymengine/lambdify.py` | P1, P2, P4, P6 |
| `nbsymengine/bindings/python_nanobind/src/core_module.cpp` | P3, P5 |
| `nbsymengine/python-bindings/tests/test_lambdify_direct.py` | P2 (test updates) |
| `benchmarks/nbsymengine_benchmarks/adapters.py` | P2 (adapter updates) |

## Appendix: Backward Compatibility

| Change | Backward Compatible? | Migration |
|--------|---------------------|-----------|
| P1: Array fast path | Yes | No changes needed |
| P2: Return ndarray | **No** | Update `isinstance(result, list)` checks |
| P3: `call_ptr()` | Yes (new method) | Opt-in via `unsafe_real()` |
| P4: `real_double()` | Yes | No changes needed |
| P5: `set_from_array()` | Yes (new method) | Internal only |
| P6: Skip `list()` | Yes | No changes needed |

The only breaking change is P2. If backward compatibility is critical, use Option B
(`as_array=False` default) and enable the fast path only when explicitly requested.
