# 08 — Follow-up Review: commit `70fb28a` (review fixes for `dfe7e0d`)

**Commit:** `70fb28a7d03e1e599b173e772a43754ccb2f1b05` — *"fix: address code review
findings (C1, D1, B1, M1, M2, nits)"* (submodule `nbsymengine`).
**Scope:** verifies each fix from review `07` against the parent commit `dfe7e0d`,
and flags a **new regression introduced by the D1 fix**.

## Verdict

**Request one more change before merge.** Five of the six fixes (C1, B1, M1, M2,
the GENERATOR.md nit) are correct and verified. **The D1 fix, while wiring up
`excluded_names()` as requested, introduced a new silent regression: two
constructors are dropped from the litgen-generated bindings.** The fix is small
(anchor the generated exclusion patterns). The commit's "380 passed" run did not
catch it because no test constructs the affected types.

I reproduced the litgen output at both `70fb28a` and its parent `dfe7e0d` using the
pinned litgen and diffed the generated `symengine_pydef.cpp`.

---

## Per-finding verification

| Finding | Status | Evidence |
|---------|--------|----------|
| **C1** stub type fidelity | ✅ Fixed | `stub_lines` now honors `arg_types`; regenerated stubs show `factor(n: Basic, B1: float = 1.0)`, `factor_pollard_pm1_method(B: int = 10, retries: int = 5)`. Regression tests `TestStubTypeFidelity` added and pass. |
| **D1** single-source excludes | ⚠️ **Regression** | Wiring is present (`fn_excludes += gen_simple_functions.excluded_names(...)`) and 19 names removed from `generate.yaml`, but it drops 2 constructors — see NB1. |
| **B1** sdist `.inc` path | ✅ Fixed | `SYMENGINE_NB_SIMPLE_INC` now defined *after* the sdist branch (follows `SYMENGINE_NB_GENERATED_DIR`); custom command + dependency guarded on `if (TARGET symengine_nb_generate)`, so sdist builds use the pre-baked `.inc` and source checkouts regenerate. Consistent with how `symengine_pydef.cpp` is handled. |
| **M1** `_arrow_col` machinery | ✅ Fixed | Function deleted; binary continuation uses a fixed 19-space indent. Compiles; purely cosmetic. |
| **M2** coverage test keys on `py` | ✅ Fixed | Test now calls `gen_simple_functions.load()` and reads `entry["py"]`. |
| GENERATOR.md nit | ✅ Fixed | New "Simple functions (JSON → .inc)" section with the manual regen command. |

---

## NB1 — D1 over-excludes: two constructors silently dropped *(new regression, should fix before merge)*

### What happens

litgen applies `fn_exclude_by_name__regex` with **`re.search`** (unanchored
substring match — see `codemanip/code_utils.py:751`, `does_match_regex`). The
exclusion regex is the `|`-joined alternation of all `fn_exclude` entries.
`excluded_names()` returns the **bare** `cpp` names of all 57 table entries,
including very short ones (`tan`, `Eq`, `Ne`, `Ge`, `Gt`, `Le`, `Lt`, `cos`,
`log`, `abs`, …). Substrings then collide with unrelated class names, and because
litgen checks **constructors** by their class name, those constructors are excluded:

- exclude entry **`tan`** ⊂ "Cons**tan**t" → drops `Constant(const std::string&)`
- exclude entry **`Le`** ⊂ "**Le**viCivita" → drops `LeviCivita(const vec_basic&&)`

### Proof

Regenerating with the pinned litgen at both commits and diffing the constructor
bindings in `symengine_pydef.cpp`:

```
m.def count:  before(dfe7e0d)=96   after(70fb28a)=94
constructors present in BEFORE but not AFTER:
  SymEngine::Constant :: .def(nb::init<const std::string &>(), ...)
  LeviCivita          :: .def(nb::init<const vec_basic &&>(), ...)
free-function name sets: IDENTICAL (only the two ctors changed)
```

Verified that anchoring removes the collision: `re.search(r"^tan$", "Constant")`
and `re.search(r"^Le$", "LeviCivita")` are both `None`, while `^tan$`/`^Le$` still
match the intended free functions exactly.

### Impact

- `Constant("name")` can no longer be constructed from Python (named symbolic
  constants). Niche but a real public-API loss.
- `LeviCivita` becomes non-constructible from Python (its `levi_civita` free
  function is also excluded — it is in the coverage test's `WAIVED` set). Minor.
- **Systemic risk** is the bigger concern: every short name in the table is a
  landmine. Any future class or function whose name *contains* `Eq`, `Ne`, `Le`,
  `tan`, `cos`, `log`, `abs`, … will be silently dropped, with green tests.

### Fix

Anchor the generated patterns. In `gen_simple_functions.excluded_names()`:

```python
import re
def excluded_names(entries):
    return [rf"^{re.escape(e['cpp'])}$" for e in entries]
```

(The existing hand-written `generate.yaml` entries that rely on substring matching
— e.g. `rcp_static_cast_.*`, `serialize.*`, `is_zero` matching member methods —
are unaffected; only the table-driven additions are anchored.) Add a guard test
that asserts `Constant` and `LeviCivita` constructors survive — e.g. assert the
regenerated `symengine_pydef.cpp` still contains `nb::class_<SymEngine::Constant`
with an `nb::init<const std::string`, or a Python-level `Constant("x")` smoke test.

### Note: the exclusion is a defensive no-op anyway

Empirically, **current litgen emits none of these free functions in the first
place**, excluded or not. In the parent commit `sin`/`cos`/`tan` were *not* in any
exclude list, yet litgen produced **zero** `m.def("sin"...)` etc. (they take
`RCP<const Basic>` and are not turned into free-function bindings). So
`excluded_names()` provides no actual de-duplication for the Phase-1 set — it is
purely defensive. That is a fine reason to keep it (guards against future litgen/
header changes), but it means the *only* observable effect of D1 as written is the
regression. Anchoring makes it a true, harmless no-op-until-needed.

---

## Minor / non-blocking

- **`fn_excludes += …` mutates the loaded config list.** `module.get("fn_exclude", [])`
  returns the list object inside the parsed YAML `config`; `+=` mutates it in
  place. Harmless today (single `core` module, used once), but prefer
  `fn_excludes = [*module.get("fn_exclude", []), *gen_simple_functions.excluded_names(_SIMPLE_ENTRIES)]`
  to avoid mutating shared state.
- **`generate.yaml` comment accuracy.** The retained comment says the listed
  ntheory names "must stay listed" because they are not in `simple_functions.json`.
  Correct — but given the no-op observation above, consider noting that these are
  defensive (litgen does not currently emit them either).
- **B1 ties simple-funcs generation to litgen availability.** Guarding on
  `TARGET symengine_nb_generate` is a reasonable proxy for "source checkout that
  regenerates," and the only non-sdist path without that target is the existing
  `FATAL_ERROR` branch, so this is safe. Just be aware the coupling is incidental
  (the renderer itself needs no litgen).

---

## Work left to do

1. **Fix NB1** — anchor `excluded_names()` patterns (`^name$`) and add a guard test
   that the `Constant` / `LeviCivita` constructors (and, generally, the litgen
   `m.def` count) are preserved. **This is the one item that should land before
   merge.**
2. **Re-verify after the anchor fix** — regenerate and confirm `m.def` count returns
   to 96 and the two constructors reappear; rerun the full suite.
3. **Optional tidy** — de-mutate `fn_excludes`; refine the `generate.yaml` comment.
4. **Carry-over from review 07 (still open):** the full build + test run claimed in
   the commit message ("380 passed") was not independently reproduced here; only
   the litgen codegen step was. Treat the build/test confirmation as pending until
   reproduced in CI, especially after applying the NB1 fix.

## Optional next step (unchanged from review 07)

The 13 simple inverse/hyperbolic functions still in the coverage `WAIVED` set
(`cot`, `csc`, `sec`, `acot`, `asec`, `acsc`, `coth`, `asinh`, `acosh`, `atanh`,
`acoth`, `asech`, `acsch`) remain one-line JSON additions each — a good follow-up
once NB1 is resolved (and a real test of whether the anchored exclusions behave).
</content>
